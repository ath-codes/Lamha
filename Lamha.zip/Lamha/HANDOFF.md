# لمحة (Lamha) — تطبيق أخبار على طريقة نبض
- Kotlin + Jetpack Compose، بدون Room وبدون Retrofit (RSS مباشر عبر HttpURLConnection + XmlPullParser)
- المصادر: app/src/main/java/com/lamha/news/Sources.kt (تعديلها من هذا الملف فقط)
- البناء: GitHub Actions (.github/workflows/build.yml) ثم Artifact باسم Lamha-apk

## المراحل
1. [تمت كتابتها] الأساس: المصادر، التحليل، التخزين المؤقت، اختيار الاهتمامات، بطاقات الأخبار، فتح الرابط الأصلي
2. [التالية] التنبيهات الدورية (WorkManager) + شاشة تشخيص المصادر + خط عربي
3. صقل: مشاركة/حفظ، og:image للصور الناقصة، تحسينات الأداء
4. لاحقاً: ترجمة المصادر الأجنبية
