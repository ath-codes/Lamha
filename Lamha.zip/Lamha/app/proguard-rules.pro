# jsoup optionally references re2j which is not present; ignore the warning so the build does not fail
-dontwarn com.google.re2j.**
