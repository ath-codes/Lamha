package com.lamha.news

/** أدوات نص عربي مشتركة: توحيد الحروف، وقاموس كلمات دالة (Lex) يتجاوز "ال" والحروف الملتصقة */
object Arabic {
    private val DIACRITICS = Regex("[\\u064B-\\u065F\\u0670\\u0640]")
    private val NON_WORD = Regex("[^\\p{L}\\p{N}\\s]")
    private val SPACES = Regex("\\s+")
    val PREFIXES = listOf("وال", "بال", "لل", "ال", "و", "ب", "ل")

    fun norm(s: String): String = s
        .replace(DIACRITICS, "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ة', 'ه')
        .lowercase()

    /** نص موحّد بلا علامات ترقيم ومسافات مفردة */
    fun clean(raw: String): String = norm(raw).replace(NON_WORD, " ").replace(SPACES, " ").trim()
}

/**
 * قاموس كلمات (بدون "ال" التعريف) وعبارات. hits = عدد الدوال المختلفة الموجودة في النص.
 * الكلمة تُقارن كما هي، ثم بعد حذف بادئة ملتصقة (ال، وال، بال، لل، و، ب، ل)
 */
class Lex(words: List<String>, phrases: List<String> = emptyList()) {
    private val w: Set<String> = words.map { Arabic.norm(it) }.toSet()
    private val p: List<String> = phrases.map { Arabic.norm(it) }

    fun hits(text: String): Int {
        val t = Arabic.clean(text)
        val padded = " $t "
        var n = 0
        for (ph in p) if (padded.contains(" $ph ")) n++
        val seen = HashSet<String>()
        for (tok in t.split(' ')) {
            if (tok.length < 3) continue
            if (tok in w) {
                seen.add(tok)
                continue
            }
            for (pre in Arabic.PREFIXES) {
                if (tok.startsWith(pre) && tok.length - pre.length >= 3) {
                    val r = tok.substring(pre.length)
                    if (r in w) {
                        seen.add(r)
                        break
                    }
                }
            }
        }
        return n + seen.size
    }

    fun any(text: String): Boolean = hits(text) > 0
}
