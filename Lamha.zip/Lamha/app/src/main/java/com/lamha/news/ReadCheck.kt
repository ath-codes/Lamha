package com.lamha.news

import android.content.Context
import android.net.Uri
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/** نتيجة فحص قراءة خبر واحد من مصدر: النجاح، والنطاق/أول جزء من المسار، وعدد الحروف، وطريقة الاستخراج أو سبب الفشل */
class ReadItem(
    val source: String, val ok: Boolean, val where: String, val chars: Int, val note: String, val title: String,
    val deep: Reader.Deep? = null, val ms: Long = 0, val category: String = ""
)

/**
 * فحص وضع القراءة، يدوياً (الإعدادات) أو تلقائياً مرة كل يوم في الخلفية.
 * يُسجَّل لكل مصدر عدد الفحوص الفاشلة المتتالية؛ ولا تُعرض في الإعدادات إلا المصادر التي فشلت في فحصين متتاليين فأكثر
 * (فخبر واحد فاشل قد يكون فيديو أو صفحة عابرة)، فيعرف المستخدم بتغيّر موقع قبل أن يلاحظه
 */
object ReadCheck {
    private val LOCK = Any()
    private const val SHOW_AFTER = 2

    /** light = في الخلفية: رابط Google غير المفكوك يُتخطى (null) بدل أن يُحسب فشلاً للمصدر */
    suspend fun checkOne(ctx: Context, a: Article, light: Boolean = false, deep: Boolean = false): ReadItem? {
        val t0 = System.currentTimeMillis()
        val u = if (GoogleLink.isGoogle(a.link)) GoogleLink.resolve(ctx, a.link, light = light).url else a.link
        if (u == null) return if (light) null else ReadItem(a.source, false, "", 0, "تعذّر فك رابط Google", a.title, null, 0, a.category)
        val uri = try { Uri.parse(u) } catch (_: Exception) { null }
        val where = (uri?.host ?: "") + "/" + (uri?.pathSegments?.firstOrNull() ?: "")
        val r = Reader.diagnose(ctx, u, a.title)
        NetStats.add("diag", r.bytes.toLong())
        if (Reader.isSkipNote(r.note) && !deep) return null // حلقة فيديو: لا تُحسب فشلاً للمصدر
        val b = r.blocks
        val chars = if (b == null) 0 else b.filter { !it.heading }.sumOf { it.text.length }
        // الفحص العميق للفاشل فقط (غير الفيديو والوسوم): سبب الفشل بالتفصيل وهل تنقذه AMP
        val d = if (deep && b == null && !Reader.isSkipNote(r.note)) Reader.deepProbe(u, a.title) else null
        return ReadItem(a.source, b != null, where, chars, r.note, a.title, d, System.currentTimeMillis() - t0, a.category)
    }

    /** خبر واحد من كل مصدر (حتى 60)، أربعة بالتوازي */
    suspend fun checkAll(
        ctx: Context, articles: List<Article>, light: Boolean = false,
        deep: Boolean = false, perSource: Int = 1, maxSources: Int = 60, progress: ((Int, Int) -> Unit)? = null
    ): List<ReadItem> {
        // الفحص الشامل: خبران من كل مصدر، لنفرّق بين فشل عابر وفشل دائم
        val picks = articles.groupBy { it.category + "|" + it.source }.values.flatMap { it.take(perSource) }.take(maxSources * perSource)
        val out = ArrayList<ReadItem>()
        var done = 0
        for (chunk in picks.chunked(4)) {
            out.addAll(coroutineScope { chunk.map { a -> async(Dispatchers.IO) { checkOne(ctx, a, light, deep) } }.awaitAll() }.filterNotNull())
            done += chunk.size
            progress?.invoke(done, picks.size)
        }
        return out
    }

    fun line(i: ReadItem): String =
        if (i.ok) "✓ ${i.source} [${i.where}] ${i.chars} حرف | ${i.note}"
        else "✗ ${i.source}" + (if (i.where.isNotEmpty()) " [${i.where}]" else "") + " | ${i.note} | ${i.title.take(40)}"

    // ---------- السجل: readcheck.json = {"time":..., "s":{"المصدر":{"k":فاشل_متتالي,"o":نجح_سابقاً,"n":ملاحظة}}} ----------
    private fun file(ctx: Context) = File(ctx.filesDir, "readcheck.json")

    private fun read(ctx: Context): JSONObject =
        try { JSONObject(file(ctx).readText()) } catch (_: Exception) { JSONObject() }

    fun record(ctx: Context, items: List<ReadItem>) {
        synchronized(LOCK) {
            val root = read(ctx)
            val s = root.optJSONObject("s") ?: JSONObject()
            for (i in items) {
                val prev = s.optJSONObject(i.source)
                val streak = if (i.ok) 0 else (prev?.optInt("k", 0) ?: 0) + 1
                val wasOk = i.ok || (prev?.optBoolean("o", false) ?: false)
                s.put(i.source, JSONObject().put("k", streak).put("o", wasOk).put("n", i.note.take(120)))
            }
            root.put("s", s)
            root.put("time", System.currentTimeMillis())
            try { file(ctx).writeText(root.toString()) } catch (_: Exception) {}
        }
    }

    /** المصادر الفاشلة فحصين متتاليين فأكثر: أسطر جاهزة للعرض، الأطول فشلاً أولاً */
    fun failing(ctx: Context): List<String> = synchronized(LOCK) {
        val s = read(ctx).optJSONObject("s") ?: return@synchronized emptyList()
        val rows = ArrayList<Triple<Int, String, String>>()
        val ks = s.keys()
        while (ks.hasNext()) {
            val name = ks.next()
            val o = s.optJSONObject(name) ?: continue
            val k = o.optInt("k", 0)
            if (k >= SHOW_AFTER) rows.add(Triple(k, name, o.optString("n", "")))
        }
        rows.sortedByDescending { it.first }.map { "${it.second} (فشل ${it.first} مرات متتالية): ${it.third.take(90)}" }
    }

    fun lastTime(ctx: Context): Long = synchronized(LOCK) { read(ctx).optLong("time", 0L) }

    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<ReadCheckWorker>(24, TimeUnit.HOURS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .setRequiresBatteryNotLow(true)
                    .build()
            )
            .build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("readcheck", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

class ReadCheckWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        return try {
            val repo = Repo(applicationContext)
            if (repo.onboarded) {
                GoogleLink.warm(applicationContext)
                Quality.warm(applicationContext)
                val arts = repo.loadCache().filter { it.category in repo.interests }
                ReadCheck.record(applicationContext, ReadCheck.checkAll(applicationContext, arts, light = true))
            }
            Result.success()
        } catch (e: Exception) {
            Result.success()
        }
    }
}
