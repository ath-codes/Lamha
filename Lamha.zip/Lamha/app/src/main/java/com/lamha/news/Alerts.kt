package com.lamha.news

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.*
import java.util.concurrent.TimeUnit

class NewsWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        return try {
            val repo = Repo(applicationContext)
            if (!repo.onboarded) return Result.success()
            val before = repo.loadCache().map { it.link }.toHashSet()
            val after = repo.refresh(repo.interests)
            if (before.isEmpty()) return Result.success()
            val fresh = after.filter { it.link !in before && it.category in repo.interests }
            if (fresh.isNotEmpty()) Notifier.show(applicationContext, fresh)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

object Alerts {
    fun schedule(ctx: Context, minutes: Int) {
        val wm = WorkManager.getInstance(ctx)
        if (minutes <= 0) {
            wm.cancelUniqueWork("news")
            return
        }
        val req = PeriodicWorkRequestBuilder<NewsWorker>(minutes.toLong(), TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        wm.enqueueUniquePeriodicWork("news", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}

object Notifier {
    private const val GROUP = "lamha_news"
    private const val MAX_INDIVIDUAL = 3

    private fun open(ctx: Context, code: Int, link: String?): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (link != null) i.putExtra("link", link)
        // requestCode فريد لكل إشعار، وإلا تُعتبر الـ intents متساوية (الـ extras لا تُقارن) ويفتح الجميع نفس الخبر
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun show(ctx: Context, fresh: List<Article>) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("news", "أخبار جديدة", NotificationManager.IMPORTANCE_DEFAULT)
        )
        // الأخبار المتكررة من عدة مصادر تصبح إشعاراً واحداً
        val stories = Stories.build(fresh).sortedByDescending { it.lead.time }
        val shown = stories.take(MAX_INDIVIDUAL)

        shown.forEach { st ->
            val a = st.lead
            val title = if (st.sources.size > 1) "${a.source} +${st.sources.size - 1}" else a.source
            val b = android.app.Notification.Builder(ctx, "news")
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(a.title)
                .setStyle(android.app.Notification.BigTextStyle().bigText(
                    if (a.summary.isBlank()) a.title else a.title + "\n" + a.summary
                ))
                .setContentIntent(open(ctx, a.link.hashCode(), a.link))
                .setGroup(GROUP)
                .setAutoCancel(true)
            nm.notify(a.link.hashCode(), b.build())
        }

        if (stories.size > 1) {
            val st = android.app.Notification.InboxStyle()
            stories.take(5).forEach { st.addLine(it.lead.title) }
            val extra = stories.size - 5
            if (extra > 0) st.setSummaryText("+$extra")
            val b = android.app.Notification.Builder(ctx, "news")
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("${stories.size} أخبار جديدة")
                .setContentText(stories[0].lead.title)
                .setStyle(st)
                .setContentIntent(open(ctx, 1, null))
                .setGroup(GROUP)
                .setGroupSummary(true)
                .setAutoCancel(true)
            nm.notify(1, b.build())
        }
    }
}
