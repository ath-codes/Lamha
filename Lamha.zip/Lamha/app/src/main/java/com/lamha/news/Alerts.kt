package com.lamha.news

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.*
import java.util.concurrent.TimeUnit

// وكالات وأخبار عاجلة فقط تُرسل تنبيهاً بلغتها الأصلية (لتجنب الإزعاج)
val ALERT_FOREIGN = setOf("Reuters", "Associated Press", "BBC News", "Al Jazeera English", "Sky News")

class NewsWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        return try {
            val repo = Repo(applicationContext)
            if (!repo.onboarded) return Result.success()
            val before = repo.loadCache().map { it.link }.toHashSet()
            val after = repo.refresh(repo.interests)
            if (before.isEmpty()) return Result.success()
            val new = after.filter { it.link !in before && it.category in repo.interests }
            val foreign = if (repo.foreignOn && repo.alertForeign)
                new.filter { it.lang != "ar" && it.source in ALERT_FOREIGN }.take(3) else emptyList()
            val fresh = (new.filter { it.lang == "ar" } + foreign).sortedByDescending { it.time }
            if (fresh.isNotEmpty()) Notifier.show(applicationContext, fresh)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

object Alerts {
    fun schedule(ctx: Context, minutes: Int) {
        val wm = WorkManager.getInstance(ctx)
        if (minutes <= 0) {
            wm.cancelUniqueWork("news")
            return
        }
        val req = PeriodicWorkRequestBuilder<NewsWorker>(minutes.toLong(), TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        wm.enqueueUniquePeriodicWork("news", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}

object Notifier {
    fun show(ctx: Context, fresh: List<Article>) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("news", "أخبار جديدة", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("link", fresh[0].link),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val first = fresh[0]
        val b = android.app.Notification.Builder(ctx, "news")
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(open)
            .setAutoCancel(true)
        if (fresh.size == 1) {
            b.setContentTitle(first.source).setContentText(first.title)
            b.setStyle(android.app.Notification.BigTextStyle().bigText(first.title + "\n" + first.summary))
        } else {
            b.setContentTitle("${fresh.size} أخبار جديدة").setContentText(first.title)
            val st = android.app.Notification.InboxStyle()
            fresh.take(5).forEach { st.addLine(it.title) }
            b.setStyle(st)
        }
        nm.notify(1, b.build())
    }
}
