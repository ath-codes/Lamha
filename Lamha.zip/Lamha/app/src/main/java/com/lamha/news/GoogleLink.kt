package com.lamha.news

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.coroutines.resume

/** نتيجة فك رابط Google News: الرابط الأصلي (null إن فشل)، والطبقة التي نجحت (0 = من الذاكرة)، وملاحظات ما فشل */
class Resolved(val url: String?, val layer: Int, val notes: String)

/**
 * فك ترميز روابط أخبار Google (news.google.com/rss/articles/...) إلى رابط الناشر الأصلي، بثلاث طبقات تتدرج من الأسرع للأبطأ:
 * 1) فك base64 محلياً: يكفي للروابط القديمة (الرابط الأصلي مخبأ داخل المعرّف). بلا إنترنت
 * 2) طلبان إلى Google: صفحة المقال (تعطي توقيعاً وطابعاً زمنياً) ثم batchexecute (يعطي الرابط). أسلوب غير موثّق وقد يتغيّر
 * 3) WebView مخفي يفتح الرابط كما يفعل المتصفح ويلتقط أول عنوان خارج Google. أبطأ الطبقات لكنها لا تعتمد على شكل الطلبات
 * النتائج تُحفظ في glinks.json (آخر 2000 رابط) فلا يُفك رابط مرتين. الفشل يُتذكّر 10 دقائق فقط
 */
object GoogleLink {
    private const val UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private const val BATCH = "https://news.google.com/_/DotsSplashUi/data/batchexecute"
    private const val MAX_SAVED = 2000
    private const val FAIL_MS = 10 * 60_000L

    private val ID = Regex("/(?:rss/)?(?:articles|read)/([^/?#]+)")
    private val SIG = Regex("data-n-a-sg=\"([^\"]+)\"")
    private val TS = Regex("data-n-a-ts=\"([^\"]+)\"")
    private val PLAIN_URL = Regex("https?://[\\x21-\\x7e]+")

    private val LOCK = Any()
    private val mem = LinkedHashMap<String, String>() // المعرّف -> الرابط الأصلي، بترتيب الإضافة
    private val failedAt = HashMap<String, Long>()
    private var loaded = false

    fun isGoogle(u: String): Boolean = u.contains("news.google.com") && ID.containsMatchIn(u)

    fun idOf(u: String): String? = ID.find(u)?.groupValues?.get(1)

    private fun hostOf(u: String): String = try { URL(u).host ?: "" } catch (_: Exception) { "" }

    private fun isGoogleHost(u: String): Boolean {
        val h = hostOf(u)
        return h.contains("google.") || h.endsWith("gstatic.com") || h.endsWith("googleusercontent.com")
    }

    private fun ok(u: String?): Boolean = u != null && u.startsWith("http") && u.length > 12 && !isGoogleHost(u)

    // ---------- الذاكرة والملف ----------
    private fun ensureLoaded(ctx: Context) {
        synchronized(LOCK) {
            if (loaded) return
            loaded = true
            try {
                val o = JSONObject(File(ctx.filesDir, "glinks.json").readText())
                val ks = o.keys()
                while (ks.hasNext()) {
                    val k = ks.next()
                    mem[k] = o.getString(k)
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun remember(ctx: Context, id: String, url: String) {
        synchronized(LOCK) {
            mem.remove(id)
            mem[id] = url
            while (mem.size > MAX_SAVED) mem.remove(mem.keys.first())
            try {
                val o = JSONObject()
                for ((k, v) in mem) o.put(k, v)
                val f = File(ctx.filesDir, "glinks.json")
                val tmp = File(ctx.filesDir, "glinks.json.tmp")
                tmp.writeText(o.toString())
                if (!tmp.renameTo(f)) {
                    f.delete()
                    tmp.renameTo(f)
                }
            } catch (_: Exception) {
            }
            failedAt.remove(id)
        }
    }

    /** الرابط الأصلي إن سبق فكه، وإلا الرابط نفسه (لزر "الصفحة الأصلية" وفتح المتصفح) */
    fun cachedOrSelf(ctx: Context, link: String): String {
        val id = idOf(link) ?: return link
        ensureLoaded(ctx)
        return synchronized(LOCK) { mem[id] } ?: link
    }

    // ---------- الطبقة 1: فك محلي ----------
    /** الصيغة القديمة: بروتوبف يحوي الرابط نصاً صريحاً بين 08 13 22 و d2 01 00. الصيغة الجديدة تحوي معرّفاً آخر (AU_yqL) فترجع null */
    private fun layer1(id: String, notes: MutableList<String>): String? {
        val bytes = try {
            Base64.decode(id + "=".repeat((4 - id.length % 4) % 4), Base64.URL_SAFE)
        } catch (_: Exception) {
            notes.add("1: ليس base64")
            return null
        }
        val s = String(bytes, Charsets.ISO_8859_1)
        val m = PLAIN_URL.find(s)
        if (m != null && ok(m.value)) return m.value
        notes.add(if (s.contains("AU_yqL")) "1: صيغة جديدة (لا رابط صريح)" else "1: لا رابط داخل المعرّف")
        return null
    }

    // ---------- الطبقة 2: طلبا Google ----------
    private class Page(val url: String, val body: String)

    private fun get(url: String): Page {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 7000
            c.readTimeout = 9000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept-Language", "ar,en;q=0.8")
            c.setRequestProperty("Cookie", "CONSENT=YES+1") // يتجاوز صفحة الموافقة في أوروبا
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            val text = c.inputStream.bufferedReader().use { it.readText() }
            return Page(c.url.toString(), text)
        } finally {
            c.disconnect()
        }
    }

    private fun post(url: String, form: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 7000
            c.readTimeout = 9000
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8")
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Cookie", "CONSENT=YES+1")
            c.outputStream.use { it.write(form.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** الرد: )]}' ثم [["wrb.fr","Fbv4je","[\"garturlrep\",\"<الرابط>\",1]",...],...] */
    private fun parseBatch(text: String): String? {
        val i = text.indexOf("[[\"wrb.fr\"")
        if (i >= 0) {
            try {
                val arr = JSONTokener(text.substring(i)).nextValue() as? JSONArray
                val inner = arr?.getJSONArray(0)?.getString(2)
                val u = inner?.let { JSONArray(it).getString(1) }
                if (ok(u)) return u
            } catch (_: Exception) {
            }
        }
        // احتياطي: أول رابط بعد garturlrep بعد إزالة الهروب
        val j = text.indexOf("garturlrep")
        if (j >= 0) {
            val clean = text.substring(j).replace("\\", "").replace("u003d", "=").replace("u0026", "&")
            val m = Regex("https?://[^\"\\s,\\]]+").find(clean)
            if (m != null && ok(m.value)) return m.value
        }
        return null
    }

    private fun layer2(id: String, notes: MutableList<String>): String? {
        val page = try {
            get("https://news.google.com/rss/articles/$id")
        } catch (e: Exception) {
            notes.add("2: الصفحة ${e.message ?: e.javaClass.simpleName}")
            return null
        }
        if (ok(page.url)) return page.url // أعادت Google التوجيه مباشرة إلى الناشر
        val sig = SIG.find(page.body)?.groupValues?.get(1)
        val ts = TS.find(page.body)?.groupValues?.get(1)
        if (sig == null || ts == null) {
            notes.add("2: لا توقيع في الصفحة")
            return null
        }
        val tsJson = if (ts.all { it.isDigit() }) ts else JSONObject.quote(ts)
        val inner = "[\"garturlreq\",[[\"X\",\"X\",[\"X\",\"X\"],null,null,1,1,\"US:en\",null,1,null,null,null,null,null,0,1]," +
            "\"X\",\"X\",1,[1,1,1],1,1,null,0,0,null,0]," + JSONObject.quote(id) + "," + tsJson + "," + JSONObject.quote(sig) + "]"
        for ((n, variant) in listOf(false, true).withIndex()) {
            try {
                val item = JSONArray().put("Fbv4je").put(inner)
                if (variant) item.put(JSONObject.NULL).put("generic")
                val form = "f.req=" + URLEncoder.encode(JSONArray().put(JSONArray().put(item)).toString(), "UTF-8")
                val text = post(if (variant) "$BATCH?rpcids=Fbv4je&hl=en-US" else BATCH, form)
                val u = parseBatch(text)
                if (u != null) return u
                notes.add("2: رد غير مفهوم (${n + 1})")
            } catch (e: Exception) {
                notes.add("2: ${e.message ?: e.javaClass.simpleName} (${n + 1})")
            }
        }
        return null
    }

    // ---------- الطبقة 3: WebView مخفي ----------
    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun layer3(ctx: Context, link: String, notes: MutableList<String>): String? {
        val r = withTimeoutOrNull(14_000L) {
            withContext(Dispatchers.Main) {
                suspendCancellableCoroutine<String?> { cont ->
                    val wv = WebView(ctx.applicationContext)
                    var done = false
                    fun finish(res: String?) {
                        if (done) return
                        done = true
                        try { wv.stopLoading() } catch (_: Exception) {}
                        try { wv.destroy() } catch (_: Exception) {}
                        if (cont.isActive) cont.resume(res)
                    }
                    wv.settings.javaScriptEnabled = true
                    wv.settings.domStorageEnabled = true
                    wv.settings.blockNetworkImage = true
                    wv.settings.userAgentString = UA
                    wv.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                            val u = request.url.toString()
                            if (u.startsWith("http") && !isGoogleHost(u)) {
                                finish(u)
                                return true
                            }
                            return false
                        }

                        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                            if (url.startsWith("http") && !isGoogleHost(url)) finish(url)
                        }
                    }
                    cont.invokeOnCancellation {
                        // الإلغاء (انتهاء المهلة) قد يأتي من خيط آخر: التدمير على الخيط الرئيسي
                        wv.post { try { wv.destroy() } catch (_: Exception) {} }
                    }
                    wv.loadUrl(link)
                }
            }
        }
        if (r == null) notes.add("3: انتهت المهلة بلا رابط خارجي")
        return r
    }

    // ---------- الواجهة العامة ----------
    /** يفك الرابط بالطبقات بالترتيب. force = تجاهل الذاكرة (لشاشة الفحص) */
    suspend fun resolve(ctx: Context, link: String, force: Boolean = false): Resolved {
        val id = idOf(link) ?: return Resolved(null, 0, "ليس رابط Google News")
        ensureLoaded(ctx)
        if (!force) {
            synchronized(LOCK) { mem[id] }?.let { return Resolved(it, 0, "من الذاكرة") }
            val f = synchronized(LOCK) { failedAt[id] }
            if (f != null && System.currentTimeMillis() - f < FAIL_MS) return Resolved(null, 0, "فشل قبل قليل، تُعاد المحاولة لاحقاً")
        }
        val notes = ArrayList<String>()
        var url: String? = layer1(id, notes)
        var layer = if (url != null) 1 else 0
        if (url == null) {
            url = withContext(Dispatchers.IO) { layer2(id, notes) }
            if (url != null) layer = 2
        }
        if (url == null) {
            url = layer3(ctx, link, notes)
            if (url != null) layer = 3
        }
        if (url != null && ok(url)) {
            remember(ctx, id, url)
            return Resolved(url, layer, notes.joinToString("؛ "))
        }
        synchronized(LOCK) { failedAt[id] = System.currentTimeMillis() }
        return Resolved(null, 0, notes.joinToString("؛ "))
    }
}
