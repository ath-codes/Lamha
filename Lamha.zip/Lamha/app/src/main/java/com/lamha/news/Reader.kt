package com.lamha.news

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** فقرة من نص الخبر (heading = عنوان فرعي) */
class Block(val text: String, val heading: Boolean)

/** طلب قراءة: الخبر، وقائمة الروابط المرشحة لجلب نصه بالترتيب (روابط Google News مستبعدة لأنها لا تفتح مباشرة) */
class ReadReq(val article: Article, val urls: List<String>)

/** وضع القراءة: يجلب الصفحة ويستخرج نص الخبر فقط (بلا إعلانات ولا صور). يرجع null إن لم ينجح فنفتح الصفحة الأصلية */
object Reader {
    private const val UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private const val MAX_CHARS = 25_000
    private const val MIN_CHARS = 300

    // ذاكرة مؤقتة لآخر 8 أخبار قُرئت، فلا يُعاد جلبها عند فتحها مرة ثانية
    private val cache = object : LinkedHashMap<String, List<Block>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<Block>>) = size > 8
    }

    // أسطر قصيرة تبدأ بهذه العبارات تعتبر روابط جانبية لا نص خبر
    private val JUNK_PREFIX = listOf(
        "اقرأ أيضا", "اقرأ أيضاً", "اقرأ أيضًا", "إقرأ أيضا", "إقرأ أيضاً", "اقرأ المزيد", "للمزيد",
        "شاهد أيضا", "شاهد أيضاً", "شاهد أيضًا", "تابعونا", "تابعنا", "تابع ", "اشترك", "حقوق النشر",
        "جميع الحقوق", "مواضيع ذات صلة", "المزيد من"
    )

    suspend fun load(url: String, title: String): List<Block>? = withContext(Dispatchers.IO) {
        synchronized(cache) { cache[url] }?.let { return@withContext it }
        val r = try { fetch(url, title) } catch (_: Exception) { null }
        if (r != null) synchronized(cache) { cache[url] = r }
        r
    }

    private fun fetch(url: String, title: String): List<Block>? {
        val res = Jsoup.connect(Rss.https(url))
            .userAgent(UA)
            .header("Accept-Language", "ar,en;q=0.8")
            .timeout(9000)
            .maxBodySize(1_500_000)
            .followRedirects(true)
            .execute()
        if (res.url().host.contains("google.")) return null // صفحة وسيطة لا الخبر نفسه
        return extract(res.parse(), title)
    }

    private fun extract(doc: Document, title: String): List<Block>? {
        doc.select("script,style,noscript,nav,header,footer,aside,form,iframe,figure,figcaption,img,picture,video,audio,svg,button,select,input,template").remove()

        // نختار الحاوية التي فيها أكبر نص فقرات: كل فقرة تعطي نقاطها لأبيها، ونصفها لجدها
        val score = HashMap<Element, Int>()
        for (p in doc.select("p")) {
            val len = p.text().length
            if (len < 40) continue
            val parent = p.parent() ?: continue
            score[parent] = (score[parent] ?: 0) + len
            parent.parent()?.let { score[it] = (score[it] ?: 0) + len / 2 }
        }
        val best = score.maxByOrNull { it.value }?.key ?: return null

        // تنظيف داخل الحاوية فقط (حتى لا نحذف الحاوية نفسها): مقالات ذات صلة، مشاركة، تعليقات، إعلانات
        best.select(
            "[class*=related],[class*=share],[class*=social],[class*=comment],[class*=advert]," +
                "[class*=newsletter],[class*=sidebar],[class*=promo],[class*=subscribe]"
        ).remove()

        val out = ArrayList<Block>()
        var chars = 0
        var bodyChars = 0
        var last = ""
        for (e in best.select("p, h2, h3")) {
            val t = e.text().replace('\u00A0', ' ').trim()
            val heading = e.tagName() != "p"
            if (t == last || t == title) continue
            if (heading) {
                if (t.length !in 3..120) continue
            } else {
                if (t.length < 20) continue
                if (t.length < 120 && JUNK_PREFIX.any { t.startsWith(it) }) continue
            }
            out.add(Block(t, heading))
            last = t
            chars += t.length
            if (!heading) bodyChars += t.length
            if (chars > MAX_CHARS) break
        }
        // عنوان فرعي في آخر القائمة بلا فقرة بعده لا معنى له
        while (out.isNotEmpty() && out.last().heading) out.removeAt(out.size - 1)
        return if (bodyChars >= MIN_CHARS) out else null
    }
}
