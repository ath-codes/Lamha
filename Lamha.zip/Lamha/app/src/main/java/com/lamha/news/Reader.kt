package com.lamha.news

import android.annotation.SuppressLint
import android.content.Context
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import org.jsoup.Connection
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.parser.Parser
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/** فقرة من نص الخبر (heading = عنوان فرعي) */
class Block(val text: String, val heading: Boolean)

/**
 * طلب قراءة: الخبر المضغوط عليه، ثم نسخ الخبر نفسه من مصادر أخرى (للاستعارة منها إن تعذّر فتح نسخته).
 * كل مرشح يُجلب برابطه وعنوانه هو (روابط Google News مستبعدة لأنها لا تفتح مباشرة)، وما يُعرض يُنسب لصاحبه الحقيقي.
 */
class ReadReq(val article: Article, val candidates: List<Article>)

/** نتيجة محاولة قراءة: النص (null إن فشلت) وملاحظة تبيّن الطريقة التي نجحت أو سبب الفشل */
class ReadResult(val blocks: List<Block>?, val note: String, val bytes: Int = 0)

/** وضع القراءة: يجلب الصفحة ويستخرج نص الخبر فقط (بلا إعلانات ولا صور). يرجع null إن لم ينجح فنفتح الصفحة الأصلية */
object Reader {
    private const val UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private const val DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    private const val MAX_CHARS = 25_000
    private const val MIN_CHARS = 300
    private const val SHORT_CHARS = 100 // خبر قصير (عاجل): يُقبل فقط بعد فشل كل الطرق الأخرى

    /** سبب فشل آخر محاولة قراءة (يظهر في رسالة التعذّر وفي تقرير فحص القراءة) */
    @Volatile var lastNote: String = ""

    // ذاكرة مؤقتة لآخر 8 أخبار قُرئت، فلا يُعاد جلبها عند فتحها مرة ثانية
    private val cache = object : LinkedHashMap<String, List<Block>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<Block>>) = size > 8
    }

    // أسطر قصيرة تبدأ بهذه العبارات تعتبر روابط جانبية لا نص خبر
    private val JUNK_PREFIX = listOf(
        "اقرأ أيضا", "اقرأ أيضاً", "اقرأ أيضًا", "إقرأ أيضا", "إقرأ أيضاً", "اقرأ المزيد", "للمزيد",
        "شاهد أيضا", "شاهد أيضاً", "شاهد أيضًا", "تابعونا", "تابعنا", "تابع ", "اشترك", "حقوق النشر",
        "جميع الحقوق", "مواضيع ذات صلة", "المزيد من"
    )

    suspend fun load(ctx: Context, url: String, title: String): List<Block>? = withContext(Dispatchers.IO) {
        synchronized(cache) { cache[url] }?.let { lastNote = "من الذاكرة"; return@withContext it }
        // نسخة محفوظة على الجهاز (آخر 60 خبراً قُرئ، لثلاثة أيام): تفتح فوراً وبلا إنترنت
        diskGet(ctx, url)?.let { d ->
            synchronized(cache) { cache[url] = d }
            lastNote = "من النسخة المحفوظة"
            return@withContext d
        }
        val res = try { fetch(ctx, url, title) } catch (e: Exception) { ReadResult(null, "خطأ ${e.javaClass.simpleName}") }
        lastNote = res.note
        NetStats.add("read", res.bytes.toLong())
        val r = res.blocks
        if (r != null && isTemplateRepeat(ctx, url, title, r)) {
            bump("نفس النص تحت عناوين مختلفة")
            lastNote = "$HUB_NOTE (نفس النص تحت عناوين مختلفة)"
            Quality.markVideo(ctx, title)
            return@withContext null
        }
        if (r != null) {
            synchronized(cache) { cache[url] = r }
            diskPut(ctx, url, r)
        } else if (isSkipNote(res.note)) {
            Quality.markVideo(ctx, title) // حلقة فيديو: تختفي من القائمة
        }
        r
    }

    // ---------- نسخ النصوص المحفوظة على الجهاز ----------
    private const val DISK_MAX = 60
    private const val DISK_TTL_MS = 3 * 24 * 3_600_000L

    private fun diskFile(ctx: Context, url: String): File {
        val d = File(ctx.cacheDir, "readcache")
        d.mkdirs()
        val h = MessageDigest.getInstance("SHA-1").digest(url.toByteArray()).joinToString("") { "%02x".format(it.toInt() and 0xff) }
        return File(d, h.take(20) + ".json")
    }

    private fun diskGet(ctx: Context, url: String): List<Block>? {
        return try {
            val f = diskFile(ctx, url)
            if (!f.exists() || System.currentTimeMillis() - f.lastModified() > DISK_TTL_MS) return null
            val arr = JSONArray(f.readText())
            val out = ArrayList<Block>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Block(o.getString("x"), o.getBoolean("h")))
            }
            if (out.isEmpty()) return null
            // نسخة قديمة فيها شيفرة أو قائمة عناوين (قبل هذا الفحص): تُحذف ويُعاد الجلب
            val (ok, _, _) = sanitize(out)
            if (ok == null) { f.delete(); bump("نسخة محفوظة تالفة"); null } else ok
        } catch (_: Exception) { null }
    }

    private fun diskPut(ctx: Context, url: String, blocks: List<Block>) {
        try {
            val arr = JSONArray()
            for (b in blocks) arr.put(JSONObject().put("x", b.text).put("h", b.heading))
            val f = diskFile(ctx, url)
            f.writeText(arr.toString())
            val files = f.parentFile?.listFiles() ?: return
            if (files.size > DISK_MAX) files.sortedBy { it.lastModified() }.take(files.size - DISK_MAX).forEach { it.delete() }
        } catch (_: Exception) {}
    }

    // ---------- الجلب المسبق (واي فاي فقط): يملأ النسخ المحفوظة قبل أن تفتح الخبر ----------
    /** يرجع: 1 جُلب وحُفظ، 0 كان محفوظاً أو يحتاج متصفحاً فتُرك، -1 فشل. بلا WebView فلا يزاحم فتح الخبر */
    suspend fun prefetch(ctx: Context, url: String, title: String): Int = withContext(Dispatchers.IO) {
        if (diskGet(ctx, url) != null) return@withContext 0
        val host = GoogleLink.normalizeUrl(url)?.substringBefore('/')
        if (host != null && host in webHosts(ctx)) return@withContext 0
        val h = try { viaHttp(url, title) } catch (_: Exception) { return@withContext -1 }
        NetStats.add("prefetch", h.bytes.toLong())
        val b = h.blocks ?: return@withContext -1
        if (isTemplateRepeat(ctx, url, title, b)) return@withContext -1
        synchronized(cache) { cache[url] = b }
        diskPut(ctx, url, b)
        1
    }

    /** لفحص القراءة من الإعدادات: بلا ذاكرة مؤقتة، ويرجع سبب النجاح أو الفشل */
    suspend fun diagnose(ctx: Context, url: String, title: String): ReadResult = withContext(Dispatchers.IO) {
        try { fetch(ctx, url, title) } catch (e: Exception) { ReadResult(null, "خطأ ${e.javaClass.simpleName}") }
    }

    /** نتيجة الفحص العميق لخبر فشلت قراءته: text للتقرير، ampOk = نسخة AMP تعطي نصاً، looseOk = الاستخراج ينجح لو أُهمل شرط العنوان */
    class Deep(val text: String, val ampOk: Boolean, val looseOk: Boolean)

    private fun fetchDoc(u: String, uas: List<String>): Pair<String, Document?> {
        var status = ""
        for (ua in uas) {
            val r = try { connect(u, ua) } catch (e: Exception) { status = e.javaClass.simpleName; continue }
            val code = r.statusCode()
            status = "HTTP $code"
            if (code in 200..299) {
                val d = try { r.parse() } catch (e: Exception) { return ("تحليل: " + e.javaClass.simpleName) to null }
                NetStats.add("diag", try { d.outerHtml().toByteArray(Charsets.UTF_8).size.toLong() } catch (_: Exception) { 0L })
                return status to d
            }
        }
        return status to null
    }

    private fun ampCandidates(url: String): List<String> {
        val base = url.substringBefore('#')
        return if (base.contains('?')) listOf(base + "&amp=1") else listOf(base.trimEnd('/') + "/amp", base + "?amp=1")
    }

    /**
     * تشخيص عميق (للفحص الشامل فقط): لماذا فشل الخبر؟ حالة الاتصال، حجم الصفحة، درجة تطابق العنوان،
     * هل ينجح الاستخراج لو أُهمل شرط العنوان، وهل تعطي نسخة AMP نصاً. لا يُستعمل في القراءة العادية
     */
    suspend fun deepProbe(url: String, title: String): Deep = withContext(Dispatchers.IO) {
        val sb = StringBuilder()
        var looseOk = false
        var ampOk = false
        try {
            val (st, doc) = fetchDoc(url, listOf(UA, DESKTOP_UA))
            sb.append(st)
            if (doc != null) {
                val bytes = try { doc.outerHtml().toByteArray(Charsets.UTF_8).size } catch (_: Exception) { 0 }
                sb.append(" · ").append(NetStats.fmt(bytes.toLong()))
                val sc = titleScore(doc, title)
                sb.append(" · عنوان ").append(if (sc == null) "بلا دليل" else "${sc.first}/${sc.second}")
                val (b, how) = try { extract(doc, title) } catch (_: Exception) { null to "خطأ استخراج" }
                val n = b?.filter { !it.heading }?.sumOf { it.text.length } ?: 0
                looseOk = n >= MIN_CHARS
                sb.append(" · استخراج بلا شرط العنوان: ").append(n).append(" حرف (").append(how.take(40)).append(")")
            }
        } catch (e: Exception) {
            sb.append("خطأ ").append(e.javaClass.simpleName)
        }
        val amps = ArrayList<String>()
        for (au in ampCandidates(url)) {
            try {
                val (st, d) = fetchDoc(au, listOf(UA))
                if (d == null) { amps.add(au.takeLast(9) + " " + st); continue }
                val sc = titleScore(d, title)
                val titleOk = sc == null || sc.first * 3 >= sc.second
                val (b, _) = try { extract(d, title) } catch (_: Exception) { null to "" }
                val n = b?.filter { !it.heading }?.sumOf { it.text.length } ?: 0
                if (n >= MIN_CHARS && titleOk) { ampOk = true; amps.add(au.takeLast(9) + " ✓ " + n + " حرف"); break }
                amps.add(au.takeLast(9) + " ✗ " + n + " حرف" + if (!titleOk) " (عنوان لا يطابق)" else "")
            } catch (e: Exception) {
                amps.add(au.takeLast(9) + " " + e.javaClass.simpleName)
            }
        }
        sb.append(" · AMP: ").append(amps.joinToString("، "))
        Deep(sb.toString(), ampOk, looseOk)
    }

    private fun connect(url: String, ua: String): Connection.Response =
        Jsoup.connect(Rss.https(url))
            .userAgent(ua)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "ar,en;q=0.8")
            .referrer("https://www.google.com/")
            .timeout(9000)
            .maxBodySize(1_500_000)
            .followRedirects(true)
            .ignoreHttpErrors(true)
            .execute()

    /** نتيجة المحاولة العادية (بلا متصفح): blocked = الموقع رفض الطلب الآلي أو أعاد صفحة شبه فارغة (يحتاج متصفحاً) */
    // bytes: حجم HTML الصفحة بعد فك الضغط (تقريبي، لإحصاء الإنترنت)
    private class HttpTry(val blocks: List<Block>?, val note: String, val gone: Boolean, val blocked: Boolean, val bytes: Int = 0)

    private fun viaHttp(url: String, title: String): HttpTry {
        val notes = ArrayList<String>()
        var res: Connection.Response? = null
        var gone = false
        var blocked = false
        val uas = listOf(UA, DESKTOP_UA) // ترويسة الجوال أولاً، ثم سطح المكتب إن رُفض الطلب
        for (i in uas.indices) {
            val r = try { connect(url, uas[i]) } catch (e: Exception) { notes.add("جلب ${i + 1}: ${e.javaClass.simpleName}"); continue }
            val code = r.statusCode()
            if (code in 200..299) { res = r; break }
            notes.add("جلب ${i + 1}: HTTP $code")
            if (code == 401 || code == 403 || code == 406 || code == 429) blocked = true
            if (code == 404 || code == 410) { gone = true; break }
        }
        val got = res ?: return HttpTry(null, notes.joinToString("؛ "), gone, blocked)
        if (got.url().host.contains("google.")) return HttpTry(null, "انتهى عند صفحة Google", false, false)
        val doc = try { got.parse() } catch (e: Exception) { return HttpTry(null, prefixOf(notes) + "تحليل الصفحة: ${e.javaClass.simpleName}", false, false) }
        if (doc.text().length < 200) blocked = true // صفحة شبه فارغة: تُرسم بالجافاسكربت أو صفحة تحدٍّ
        val bytes = try { doc.outerHtml().toByteArray(Charsets.UTF_8).size } catch (_: Exception) { 0 } // قبل judge لأنه يحذف وسوماً
        val r = judge(doc, title)
        return HttpTry(r.blocks, prefixOf(notes) + r.note, false, blocked, bytes)
    }

    private suspend fun viaWeb(ctx: Context, url: String, title: String): ReadResult {
        val html = webHtml(ctx, url) ?: return ReadResult(null, "WebView: انتهت المهلة")
        if (html.isEmpty()) return ReadResult(null, "WebView: لم يرجع HTML")
        val r = judge(Jsoup.parse(html, url), title)
        return ReadResult(r.blocks, "WebView: " + r.note)
    }

    // ---------- مواقع تحتاج متصفحاً: تُحفظ فتبدأ بالمتصفح مباشرة بدل تجربتين فاشلتين أولاً ----------
    private var webHostsCache: MutableSet<String>? = null

    private fun webHosts(ctx: Context): MutableSet<String> = synchronized(this) {
        webHostsCache ?: ConcurrentHashMap.newKeySet<String>().also { set ->
            set.addAll(ctx.applicationContext.getSharedPreferences("lamha_reader", Context.MODE_PRIVATE).getStringSet("webHosts", emptySet()) ?: emptySet())
            webHostsCache = set
        }
    }

    private fun setWebHost(ctx: Context, host: String, on: Boolean) {
        synchronized(this) {
            val cur = webHosts(ctx)
            if (on) cur.add(host) else cur.remove(host)
            ctx.applicationContext.getSharedPreferences("lamha_reader", Context.MODE_PRIVATE)
                .edit().putStringSet("webHosts", HashSet(cur)).apply()
        }
    }

    /** المواقع المحفوظة أنها تحتاج متصفحاً (للتقرير) */
    fun savedWebHosts(ctx: Context): List<String> = webHosts(ctx).sorted()

    private suspend fun fetch(ctx: Context, url: String, title: String): ReadResult {
        val host = GoogleLink.normalizeUrl(url)?.substringBefore('/')
        val path = GoogleLink.normalizeUrl(url)?.substringAfter('/', "") ?: ""
        if (HUB_PATH.containsMatchIn("/" + path.substringBefore('?'))) { bump("رابط قسم أو وسم"); return ReadResult(null, HUB_NOTE) }
        if (host != null && isDead(ctx, host)) return ReadResult(null, "الموقع يرفض القراءة الآلية (HTTP 403 ثم مهلة المتصفح)")
        if (host != null && host in webHosts(ctx)) {
            val w = viaWeb(ctx, url, title)
            if (isSkipNote(w.note)) return w
            if (w.blocks != null) return ReadResult(w.blocks, "موقع محفوظ أنه يحتاج متصفحاً؛ " + w.note)
            // فشل المتصفح: نجرّب العادي، فإن نجح صار الموقع لا يحتاج متصفحاً
            val h = viaHttp(url, title)
            if (h.blocks != null) { setWebHost(ctx, host, false); return ReadResult(h.blocks, h.note, h.bytes) }
            return ReadResult(null, w.note + "؛ " + h.note, h.bytes)
        }
        val h = viaHttp(url, title)
        if (h.blocks != null) return ReadResult(h.blocks, h.note, h.bytes)
        if (h.gone || isSkipNote(h.note)) return ReadResult(null, h.note, h.bytes)
        // آخر محاولة: متصفح حقيقي مخفي (يتجاوز بعض الحمايات، ويرسم الصفحات التي تعتمد على الجافاسكربت)
        val w = viaWeb(ctx, url, title)
        if (w.blocks != null && h.blocked && host != null) setWebHost(ctx, host, true)
        if (w.blocks == null && h.blocked && host != null && w.note.contains("انتهت المهلة")) markDead(ctx, host)
        return ReadResult(w.blocks, h.note + "؛ " + w.note, h.bytes)
    }

    private fun prefixOf(notes: List<String>) = if (notes.isEmpty()) "" else notes.joinToString("؛ ") + "؛ "

    /** هل الصفحة هي الخبر المطلوب؟ ثم استخراج نصه. الملاحظة تصف الطريقة أو سبب الفشل */
    private fun judge(doc: Document, title: String): ReadResult {
        // قبل الاستخراج (يحذف وسوماً): صفحة أخرى (قالب مشترك، إعادة توجيه لقسم) تُرفض
        val sc = titleScore(doc, title)
        if (sc != null && sc.first * 3 < sc.second) {
            val pt = (doc.selectFirst("meta[property=og:title]")?.attr("content") ?: doc.title()).take(40)
            return ReadResult(null, "عنوان الصفحة لا يطابق الخبر (${sc.first}/${sc.second} كلمة): $pt")
        }
        val (blocks, how) = extract(doc, title)
        if (blocks != null && isVideoText(blocks)) return ReadResult(null, VIDEO_NOTE + " (نص الخبر ${restLen(blocks)} حرف)")
        val clean = blocks?.filter { b -> b.heading || WEAK_VIDEO.none { b.text.contains(it) } }
        val picked = if (clean.isNullOrEmpty()) blocks else clean
        if (picked == null) return ReadResult(null, how)
        val (ok, why, hub) = sanitize(picked)
        if (ok != null) return ReadResult(ok, how)
        if (why == null) return ReadResult(picked, how) // لا مشكلة في الجودة، فقط قصير: يقرّره المسار الأصلي
        bump(why.substringBefore(" ("))
        return ReadResult(null, if (hub) "$HUB_NOTE ($why)" else why)
    }

    /** ملاحظة تعني أن الصفحة حلقة فيديو لا خبر: تُحذف من القائمة ولا تُحسب فشلاً للمصدر */
    const val VIDEO_NOTE = "حلقة فيديو"
    private val STRONG_VIDEO = listOf("تستعرض هذه الحلقة", "تستعرض هذه النشرة")
    private val WEAK_VIDEO = listOf("لعرض هذا المحتوى من اليوتيوب", "تمنع تحميل مشغل الفيديو")

    /** فهرس حلقة (عبارة صريحة) فقط يُعدّ فيديو. رسالة مشغّل الفيديو وحدها لا تكفي: خبر فيه فيديو مضمّن يبقى نصه فيُقبل */
    private const val WEAK_MIN_REST = 250
    private fun isVideoText(blocks: List<Block>): Boolean {
        val texts = blocks.filter { !it.heading }.map { it.text }
        if (texts.any { t -> STRONG_VIDEO.any { t.contains(it) } }) return true
        val weak = texts.filter { t -> WEAK_VIDEO.any { t.contains(it) } }
        if (weak.isEmpty()) return false
        return restLen(blocks) < WEAK_MIN_REST
    }

    /** طول نص الخبر بعد حذف فقرات رسائل مشغّل الفيديو */
    private fun restLen(blocks: List<Block>): Int =
        blocks.filter { b -> !b.heading && WEAK_VIDEO.none { b.text.contains(it) } }.sumOf { it.text.length }

    /** صفحات أقسام ووسوم (ليست خبراً): تُحذف من القائمة ولا تُحسب فشلاً للمصدر */
    const val HUB_NOTE = "صفحة وسم أو قسم"
    // وسوم وكتّاب ومواضيع دائماً؛ وcategory وsection فقط إن كانت صفحة قائمة (بعدها مقطع واحد)، فلا نحذف خبراً مساره /category/اسم/عنوان-الخبر
    private val HUB_PATH = Regex("(?i)/(tags?|topics?|author|authors|taxonomy/term)(/|$|\\?)|/(category|categories|section|sections)/[^/?#]+/?($|\\?)")
    fun isSkipNote(n: String) = n.contains(VIDEO_NOTE) || n.contains(HUB_NOTE)

    /** رابط صفحة قسم أو وسم أو تصنيف (ليس خبراً). روابط Google لا مسار فيها فلا تُحكم هنا */
    fun isHubUrl(url: String): Boolean {
        if (GoogleLink.isGoogle(url)) return false
        val n = GoogleLink.normalizeUrl(url) ?: return false
        return HUB_PATH.containsMatchIn("/" + n.substringAfter('/', "").substringBefore('?'))
    }

    // ---------- عدّاد ما رُفض في وضع القراءة وسببه (للتقرير، لضبط القواعد لاحقاً) ----------
    private val rejects = ConcurrentHashMap<String, Int>()
    private fun bump(reason: String) { rejects.merge(reason, 1) { a, b -> a + b } }

    fun rejectReport(): String {
        if (rejects.isEmpty()) return "\nمرفوض في وضع القراءة منذ فتح التطبيق: لا شيء\n"
        val sb = StringBuilder("\nمرفوض في وضع القراءة منذ فتح التطبيق:\n")
        for ((r, n) in rejects.entries.sortedByDescending { it.value }) sb.append("• ").append(r).append(": ").append(n).append('\n')
        return sb.toString()
    }

    // ---------- فحص جودة النص المستخرج: شيفرة جافاسكربت، قوائم عناوين ----------
    // ملاحظة: بلا ':' أول المجموعة أو آخرها (مشكلة ICU في أندرويد)
    private val CODE_SIG = Regex(
        "window\\.[A-Za-z_]|\\bfunction\\s*\\(|\\b(var|let|const)\\s+[A-Za-z_$][\\w$]*\\s*=|document\\.(getElement|querySelector|write|cookie)|" +
            "<script|</?div|\\}\\s*\\)\\s*;|\\bnull\\s*\\)\\s*;|_config\\[|dataLayer|googletag|\\.push\\s*\\("
    )
    private val SENT_END = Regex("[.!?\\u061F\\u2026\\u201D\\u00BB\"]\\s*$")

    private fun normBlock(t: String) = t.lowercase().replace(Regex("\\s+"), " ").trim()

    /**
     * ينظّف الكتل ويرجع (الكتل أو null، سبب الرفض أو null، هل هي صفحة قائمة تُخفى من القائمة).
     * 1) كتلة فيها شيفرة تُحذف؛ فإن لم يبقَ نص كافٍ فالنتيجة فشل عادي (يُجرَّب المتصفح) لا إخفاء
     * 2) تكرار نفس الفقرة يُحذف
     * 3) قائمة عناوين: 5 كتل فأكثر، أطولها أقل من 200 حرف، و70% منها بلا علامة نهاية جملة = صفحة قسم
     */
    internal fun sanitize(blocks: List<Block>): Triple<List<Block>?, String?, Boolean> {
        var out = blocks
        val codeN = out.count { !it.heading && CODE_SIG.containsMatchIn(it.text) }
        if (codeN > 0) out = out.filter { it.heading || !CODE_SIG.containsMatchIn(it.text) }
        val seen = HashSet<String>()
        val dedup = ArrayList<Block>()
        var dups = 0
        for (b in out) {
            if (!seen.add(normBlock(b.text))) { dups++; continue }
            dedup.add(b)
        }
        out = dedup
        val body = out.filter { !it.heading }
        val chars = body.sumOf { it.text.length }
        if (body.size >= 5) {
            val longest = body.maxOf { it.text.length }
            val noEnd = body.count { !SENT_END.containsMatchIn(it.text.trim()) }
            if (longest < 200 && noEnd * 10 >= body.size * 7) return Triple(null, "قائمة عناوين (${body.size} سطراً بلا فقرات)", true)
        }
        if (dups >= 2 && chars < MIN_CHARS * 2) return Triple(null, "نص مكرر ($dups فقرات متكررة)", true)
        if (chars < SHORT_CHARS || (codeN > 0 && chars < MIN_CHARS)) {
            return Triple(null, if (codeN > 0) "نص صفحة فيه شيفرة ولا نص خبر كافٍ" else null, false)
        }
        return Triple(out, null, false)
    }

    // بصمة الصفحات القالبية: نفس أول فقرتين من نفس الموقع تحت عناوين مختلفة = صفحة قسم مشتركة، لا خبر (حتى لو لم يظهر في رابطها وسم)
    private fun fpKey(url: String, blocks: List<Block>): String? {
        val host = GoogleLink.normalizeUrl(url)?.substringBefore('/') ?: return null
        val head = blocks.filter { !it.heading }.take(2).joinToString("|") { normBlock(it.text) }
        if (head.length < 60) return null
        return host + "#" + head.hashCode()
    }

    /** يرجع true إن كانت الصفحة قالباً مشتركاً (رُصدت من قبل تحت عنوان آخر)؛ ويسجّل بصمتها وعنوانها */
    private fun isTemplateRepeat(ctx: Context, url: String, title: String, blocks: List<Block>): Boolean {
        val key = fpKey(url, blocks) ?: return false
        val p = ctx.applicationContext.getSharedPreferences("lamha_fp", Context.MODE_PRIVATE)
        val t = normBlock(title)
        val prev = p.getString(key, null)
        if (prev == null) {
            try {
                if (p.all.size > 300) p.edit().clear().apply()
                p.edit().putString(key, t).apply()
            } catch (_: Exception) {}
            return false
        }
        return prev != t
    }

    // مواقع ترفض القراءة الآلية (403 ثم انتهاء مهلة المتصفح): نتذكرها 12 ساعة فلا ننتظر 18 ثانية كل مرة
    private const val DEAD_TTL_MS = 12 * 3_600_000L
    private fun deadPrefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("lamha_reader", Context.MODE_PRIVATE)
    private fun isDead(ctx: Context, host: String) = System.currentTimeMillis() - deadPrefs(ctx).getLong("dead_$host", 0L) < DEAD_TTL_MS
    private fun markDead(ctx: Context, host: String) { deadPrefs(ctx).edit().putLong("dead_$host", System.currentTimeMillis()).apply() }

    private val webLock = Mutex() // WebView واحد في كل مرة

    private fun decodeJs(v: String?): String? =
        try { JSONTokener(v ?: "null").nextValue() as? String } catch (_: Exception) { null }

    /**
     * يفتح الرابط في WebView مخفي وينتظر حتى يظهر نص كافٍ في الصفحة (حتى 12 ثانية تقريباً، لتمرّ صفحات التحقق)
     * ثم يرجع HTML الصفحة بعد تنفيذ الجافاسكربت. null إن انتهت المهلة
     */
    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun webHtml(ctx: Context, url: String): String? = webLock.withLock {
        withTimeoutOrNull(18_000L) {
            withContext(Dispatchers.Main) {
                suspendCancellableCoroutine<String?> { cont ->
                    val wv = WebView(ctx.applicationContext)
                    var done = false
                    var polling = false
                    // Handler لا View.postDelayed: الـ WebView غير مثبّت في أي نافذة فتبقى أوامر post معلّقة ولا تُنفَّذ أبداً
                    val h = Handler(Looper.getMainLooper())
                    fun finish(res: String?) {
                        if (done) return
                        done = true
                        try { wv.stopLoading() } catch (_: Exception) {}
                        try { wv.destroy() } catch (_: Exception) {}
                        if (cont.isActive) cont.resume(res)
                    }
                    fun poll(tries: Int) {
                        if (done) return
                        wv.evaluateJavascript("(document.body ? document.body.innerText.length : 0)") { v ->
                            val len = v?.trim('"')?.toIntOrNull() ?: 0
                            if (len >= 1200 || tries >= 5) {
                                wv.evaluateJavascript("document.documentElement.outerHTML") { html -> finish(decodeJs(html) ?: "") }
                            } else {
                                h.postDelayed({ poll(tries + 1) }, 2000L)
                            }
                        }
                    }
                    wv.settings.javaScriptEnabled = true
                    wv.settings.domStorageEnabled = true
                    wv.settings.blockNetworkImage = true
                    wv.settings.userAgentString = UA
                    wv.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, u: String?) {
                            if (polling) return
                            polling = true
                            h.postDelayed({ poll(0) }, 1500L)
                        }
                    }
                    cont.invokeOnCancellation { h.post { try { wv.destroy() } catch (_: Exception) {} } }
                    wv.loadUrl(url)
                }
            }
        }
    }

    /**
     * عنوان الصفحة (og:title أو h1 أو title) يجب أن يشارك عنوان الخبر ثلث كلماته الدالة على الأقل.
     * الحد متساهل عمداً (عنوان الصفحة قد يختلف قليلاً عن عنوان الخلاصة)؛ المقصود رفض الصفحة التي لا علاقة لها بالخبر.
     * لا دليل (صفحة بلا عنوان) أو عنوان مطلوب قصير جداً: لا نرفض.
     */
    /** (الكلمات المشتركة، كلمات عنوان الخبر الدالة) لأفضل عنوان في الصفحة؛ null إن لا دليل (لا عنوان أو عنوان مطلوب قصير) */
    internal fun titleScore(doc: Document, title: String): Pair<Int, Int>? {
        val heads = listOfNotNull(
            doc.selectFirst("meta[property=og:title]")?.attr("content"),
            doc.selectFirst("h1")?.text(),
            doc.title()
        ).filter { it.isNotBlank() }
        val want = Stories.keyTokens(title)
        if (heads.isEmpty() || want.size < 2) return null
        val best = heads.maxOf { h ->
            val got = Stories.keyTokens(h)
            want.count { it in got }
        }
        return best to want.size
    }

    /**
     * نأخذ نص المقال من بيانات الصفحة المهيكلة (JSON-LD: articleBody) إن وجدت لأنه نظيف من الإعلانات،
     * ونقارنه بالاستخراج من وسوم الصفحة: إن كان أقصر منه كثيراً فهو مبتور (مقدمة فقط) فنفضّل الاستخراج من الوسوم.
     * إن فشل الاثنان تُجرَّب بدائل بالترتيب: حاوية المقال، JSON مضمّن في الصفحة (مواقع Next.js)، ثم خبر قصير (عاجل).
     * يرجع النص مع وصف للطريقة الناجحة أو سبب الفشل
     */
    private fun extract(doc: Document, title: String): Pair<List<Block>?, String> {
        // إحصاءات قبل أن يحذف fromHtml وسوم script (لتشخيص صفحات تُرسم بالجافاسكربت)
        val pCount = doc.select("p").size
        val scripts = doc.select("script").size
        val textLen = doc.text().length
        val ld = fromJsonLd(doc, title)
        val emb = if (ld == null) fromEmbedded(doc, title) else null
        val html = fromHtml(doc, title, MIN_CHARS)
        val first = when {
            ld == null -> html
            html == null -> ld
            bodyLen(ld) >= bodyLen(html) * 0.6 -> ld
            else -> html
        }
        if (first != null) return first to (if (first === ld) "JSON-LD" else "وسوم الصفحة")
        fromContainer(doc, title)?.let { return it to "حاوية المقال" }
        emb?.let { return it to "JSON مضمّن" }
        fromOwnText(doc, title)?.let { return it to "نص مباشر في حاوية" }
        fromLines(doc, title)?.let { return it to "أسطر الصفحة" }
        fromHtml(doc, title, SHORT_CHARS)?.let { return it to "خبر قصير" }
        fromLines(doc, title, 40, SHORT_CHARS + 20)?.let { return it to "أسطر قصيرة" }
        return null to "لا نص كافٍ (فقرات p=$pCount، سكربت=$scripts، نص الصفحة=$textLen حرف)"
    }

    private val CONTAINERS = "[itemprop=articleBody],article,[class*=article-body],[class*=articleBody],[class*=story-body]," +
        "[class*=entry-content],[class*=post-content],[class*=news-body],[class*=details-body],[class*=article-content]," +
        "[id*=article-body],[class*=content-body],[class*=article_body],[class*=news-content]"

    /** بديل: نص حاوية المقال كاملاً (حتى لو لم يكن في وسوم p)، نبدأ بأصغر حاوية فيها نص كافٍ لأنها الأدق */
    private fun fromContainer(doc: Document, title: String): List<Block>? {
        for (el in doc.select(CONTAINERS).sortedBy { it.text().length }) {
            el.select("[class*=related],[class*=share],[class*=social],[class*=comment],[class*=advert],[class*=sidebar]").remove()
            val b = bodyToBlocks(el.html(), title)
            if (b != null) return b
        }
        return null
    }

    /**
     * بديل: بعض المواقع تضع الخبر نصاً مباشراً داخل div تفصل بينه وسوم br بلا وسوم p. نأخذ العنصر الذي يحوي أكبر نص مباشر
     * (ownText: النص الذي ليس داخل عناصر أبنائه)، وهو في الغالب جسم الخبر
     */
    private fun fromOwnText(doc: Document, title: String): List<Block>? {
        val best = doc.select("div,section,article,main,td,span").maxByOrNull { it.ownText().length } ?: return null
        if (best.ownText().length < MIN_CHARS) return null
        best.select("[class*=related],[class*=share],[class*=social],[class*=comment],[class*=advert],[class*=sidebar]").remove()
        return bodyToBlocks(best.html(), title)
    }

    /**
     * آخر بديل: كل أسطر الصفحة الطويلة (60 حرفاً فأكثر) بعد حذف القوائم والإعلانات والمشاركة. القوائم والأزرار أسطرها قصيرة فتسقط،
     * فيبقى في الغالب جسم الخبر. أقل دقة من غيره فيُجرَّب أخيراً
     */
    private fun fromLines(doc: Document, title: String, minLine: Int = 60, minTotal: Int = MIN_CHARS): List<Block>? {
        val body = doc.body() ?: return null
        body.select("[class*=related],[class*=share],[class*=social],[class*=comment],[class*=advert],[class*=sidebar],[class*=menu],[class*=cookie]").remove()
        val txt = Parser.unescapeEntities(body.html().replace(BREAKS, "\n").replace(TAGS, ""), false).replace('\u00A0', ' ')
        val lines = txt.split("\n").map { it.trim().replace(SPACES, " ") }.filter { it.length >= minLine }
        return bodyToBlocks(lines.joinToString("\n"), title, minTotal)
    }

    private val SPACES = Regex("\\s+")

    private val BODY_KEYS = Regex("(?i)^(body|content|articleBody|text|html|bodyHtml|story)$")

    private fun collectBodies(v: Any?, key: String?, out: MutableList<String>, depth: Int) {
        if (depth > 14) return
        when (v) {
            is JSONObject -> for (k in v.keys()) collectBodies(v.opt(k), k, out, depth + 1)
            is JSONArray -> for (i in 0 until v.length()) collectBodies(v.opt(i), key, out, depth + 1)
            is String -> if (key != null && BODY_KEYS.matches(key) && v.length >= MIN_CHARS) out.add(v)
        }
    }

    /** بديل: صفحات Next.js وأشباهها تضع الخبر في JSON داخل script بدل وسوم p: نأخذ أطول نص تحت مفتاح body/content/text */
    private fun fromEmbedded(doc: Document, title: String): List<Block>? {
        for (s in doc.select("script#__NEXT_DATA__, script[type=application/json]")) {
            val raw = s.data().trim()
            if (raw.length < MIN_CHARS || raw.length > 1_200_000) continue
            val found = ArrayList<String>()
            try { collectBodies(JSONTokener(raw).nextValue(), null, found, 0) } catch (_: Exception) { continue }
            val best = found.maxByOrNull { it.length } ?: continue
            val b = bodyToBlocks(best, title)
            if (b != null) return b
        }
        return null
    }

    private fun bodyLen(b: List<Block>) = b.filter { !it.heading }.sumOf { it.text.length }

    private fun fromJsonLd(doc: Document, title: String): List<Block>? {
        for (s in doc.select("script[type=application/ld+json]")) {
            val raw = s.data().trim()
            if (raw.isEmpty()) continue
            val body = try { findBody(JSONTokener(raw).nextValue()) } catch (_: Exception) { null } ?: continue
            val blocks = bodyToBlocks(body, title)
            if (blocks != null) return blocks
        }
        return null
    }

    private fun findBody(v: Any?): String? {
        when (v) {
            is JSONObject -> {
                val b = v.optString("articleBody", "")
                if (b.length >= MIN_CHARS) return b
                for (k in v.keys()) {
                    if (k == "articleBody") continue
                    val x = v.opt(k)
                    if (x is JSONObject || x is JSONArray) findBody(x)?.let { return it }
                }
            }
            is JSONArray -> for (i in 0 until v.length()) findBody(v.opt(i))?.let { return it }
        }
        return null
    }

    private val TAGS = Regex("<[^>]+>")
    private val BREAKS = Regex("(?i)<br\\s*/?>|</p>|</div>|</h[1-6]>|</li>")
    private val SENTENCE_END = Regex("(?<=[.!?\\u061F])\\s+")

    private fun bodyToBlocks(raw: String, title: String, min: Int = MIN_CHARS): List<Block>? {
        var s = raw
        if (s.contains('<')) s = Parser.unescapeEntities(s.replace(BREAKS, "\n").replace(TAGS, ""), false)
        s = s.replace('\u00A0', ' ')
        var paras = s.split(Regex("\\s*\\n\\s*")).map { it.trim() }.filter { it.isNotEmpty() }
        // نص واحد متصل بلا فواصل: نقسمه إلى فقرات بحدود الجمل ليسهل قراءته
        if (paras.size <= 1 && s.length > 600) {
            val chunks = ArrayList<String>()
            val cur = StringBuilder()
            for (sen in s.trim().split(SENTENCE_END)) {
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(sen)
                if (cur.length >= 280) { chunks.add(cur.toString()); cur.setLength(0) }
            }
            if (cur.isNotEmpty()) chunks.add(cur.toString())
            paras = chunks
        }
        val out = ArrayList<Block>()
        var chars = 0
        for (t in paras) {
            if (t == title || t.length < 20) continue
            if (t.length < 120 && JUNK_PREFIX.any { t.startsWith(it) }) continue
            out.add(Block(t, false))
            chars += t.length
            if (chars > MAX_CHARS) break
        }
        return if (chars >= min) out else null
    }

    private fun fromHtml(doc: Document, title: String, min: Int): List<Block>? {
        doc.select("script,style,noscript,nav,header,footer,aside,iframe,figure,figcaption,img,picture,video,audio,svg,button,select,input,template").remove()

        // نختار الحاوية التي فيها أكبر نص فقرات: كل فقرة تعطي نقاطها لأبيها، ونصفها لجدها
        val score = HashMap<Element, Int>()
        for (p in doc.select("p")) {
            val len = p.text().length
            if (len < 40) continue
            val parent = p.parent() ?: continue
            score[parent] = (score[parent] ?: 0) + len
            parent.parent()?.let { score[it] = (score[it] ?: 0) + len / 2 }
        }
        val best = score.maxByOrNull { it.value }?.key ?: return null

        // تنظيف داخل الحاوية فقط (حتى لا نحذف الحاوية نفسها): مقالات ذات صلة، مشاركة، تعليقات، إعلانات
        best.select(
            "[class*=related],[class*=share],[class*=social],[class*=comment],[class*=advert]," +
                "[class*=newsletter],[class*=sidebar],[class*=promo],[class*=subscribe]"
        ).remove()

        val out = ArrayList<Block>()
        var chars = 0
        var bodyChars = 0
        var last = ""
        for (e in best.select("p, h2, h3")) {
            val t = e.text().replace('\u00A0', ' ').trim()
            val heading = e.tagName() != "p"
            if (t == last || t == title) continue
            if (heading) {
                if (t.length !in 3..120) continue
            } else {
                if (t.length < 20) continue
                if (t.length < 120 && JUNK_PREFIX.any { t.startsWith(it) }) continue
            }
            out.add(Block(t, heading))
            last = t
            chars += t.length
            if (!heading) bodyChars += t.length
            if (chars > MAX_CHARS) break
        }
        // عنوان فرعي في آخر القائمة بلا فقرة بعده لا معنى له
        while (out.isNotEmpty() && out.last().heading) out.removeAt(out.size - 1)
        return if (bodyChars >= min) out else null
    }
}
