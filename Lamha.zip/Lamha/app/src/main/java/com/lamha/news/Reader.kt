package com.lamha.news

import android.annotation.SuppressLint
import android.content.Context
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import org.jsoup.Connection
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.parser.Parser
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/** فقرة من نص الخبر (heading = عنوان فرعي) */
class Block(val text: String, val heading: Boolean)

/**
 * طلب قراءة: الخبر المضغوط عليه، ثم نسخ الخبر نفسه من مصادر أخرى (للاستعارة منها إن تعذّر فتح نسخته).
 * كل مرشح يُجلب برابطه وعنوانه هو (روابط Google News مستبعدة لأنها لا تفتح مباشرة)، وما يُعرض يُنسب لصاحبه الحقيقي.
 */
class ReadReq(val article: Article, val candidates: List<Article>)

/** نتيجة محاولة قراءة: النص (null إن فشلت) وملاحظة تبيّن الطريقة التي نجحت أو سبب الفشل */
class ReadResult(val blocks: List<Block>?, val note: String)

/** وضع القراءة: يجلب الصفحة ويستخرج نص الخبر فقط (بلا إعلانات ولا صور). يرجع null إن لم ينجح فنفتح الصفحة الأصلية */
object Reader {
    private const val UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private const val DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    private const val MAX_CHARS = 25_000
    private const val MIN_CHARS = 300
    private const val SHORT_CHARS = 100 // خبر قصير (عاجل): يُقبل فقط بعد فشل كل الطرق الأخرى

    /** سبب فشل آخر محاولة قراءة (يظهر في رسالة التعذّر وفي تقرير فحص القراءة) */
    @Volatile var lastNote: String = ""

    // ذاكرة مؤقتة لآخر 8 أخبار قُرئت، فلا يُعاد جلبها عند فتحها مرة ثانية
    private val cache = object : LinkedHashMap<String, List<Block>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<Block>>) = size > 8
    }

    // أسطر قصيرة تبدأ بهذه العبارات تعتبر روابط جانبية لا نص خبر
    private val JUNK_PREFIX = listOf(
        "اقرأ أيضا", "اقرأ أيضاً", "اقرأ أيضًا", "إقرأ أيضا", "إقرأ أيضاً", "اقرأ المزيد", "للمزيد",
        "شاهد أيضا", "شاهد أيضاً", "شاهد أيضًا", "تابعونا", "تابعنا", "تابع ", "اشترك", "حقوق النشر",
        "جميع الحقوق", "مواضيع ذات صلة", "المزيد من"
    )

    suspend fun load(ctx: Context, url: String, title: String): List<Block>? = withContext(Dispatchers.IO) {
        synchronized(cache) { cache[url] }?.let { return@withContext it }
        // نسخة محفوظة على الجهاز (آخر 60 خبراً قُرئ، لثلاثة أيام): تفتح فوراً وبلا إنترنت
        diskGet(ctx, url)?.let { d ->
            synchronized(cache) { cache[url] = d }
            lastNote = "من النسخة المحفوظة"
            return@withContext d
        }
        val res = try { fetch(ctx, url, title) } catch (e: Exception) { ReadResult(null, "خطأ ${e.javaClass.simpleName}") }
        lastNote = res.note
        val r = res.blocks
        if (r != null) {
            synchronized(cache) { cache[url] = r }
            diskPut(ctx, url, r)
        }
        r
    }

    // ---------- نسخ النصوص المحفوظة على الجهاز ----------
    private const val DISK_MAX = 60
    private const val DISK_TTL_MS = 3 * 24 * 3_600_000L

    private fun diskFile(ctx: Context, url: String): File {
        val d = File(ctx.cacheDir, "readcache")
        d.mkdirs()
        val h = MessageDigest.getInstance("SHA-1").digest(url.toByteArray()).joinToString("") { "%02x".format(it.toInt() and 0xff) }
        return File(d, h.take(20) + ".json")
    }

    private fun diskGet(ctx: Context, url: String): List<Block>? {
        return try {
            val f = diskFile(ctx, url)
            if (!f.exists() || System.currentTimeMillis() - f.lastModified() > DISK_TTL_MS) return null
            val arr = JSONArray(f.readText())
            val out = ArrayList<Block>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Block(o.getString("x"), o.getBoolean("h")))
            }
            if (out.isEmpty()) null else out
        } catch (_: Exception) { null }
    }

    private fun diskPut(ctx: Context, url: String, blocks: List<Block>) {
        try {
            val arr = JSONArray()
            for (b in blocks) arr.put(JSONObject().put("x", b.text).put("h", b.heading))
            val f = diskFile(ctx, url)
            f.writeText(arr.toString())
            val files = f.parentFile?.listFiles() ?: return
            if (files.size > DISK_MAX) files.sortedBy { it.lastModified() }.take(files.size - DISK_MAX).forEach { it.delete() }
        } catch (_: Exception) {}
    }

    /** لفحص القراءة من الإعدادات: بلا ذاكرة مؤقتة، ويرجع سبب النجاح أو الفشل */
    suspend fun diagnose(ctx: Context, url: String, title: String): ReadResult = withContext(Dispatchers.IO) {
        try { fetch(ctx, url, title) } catch (e: Exception) { ReadResult(null, "خطأ ${e.javaClass.simpleName}") }
    }

    private fun connect(url: String, ua: String): Connection.Response =
        Jsoup.connect(Rss.https(url))
            .userAgent(ua)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "ar,en;q=0.8")
            .referrer("https://www.google.com/")
            .timeout(9000)
            .maxBodySize(1_500_000)
            .followRedirects(true)
            .ignoreHttpErrors(true)
            .execute()

    /** نتيجة المحاولة العادية (بلا متصفح): blocked = الموقع رفض الطلب الآلي أو أعاد صفحة شبه فارغة (يحتاج متصفحاً) */
    private class HttpTry(val blocks: List<Block>?, val note: String, val gone: Boolean, val blocked: Boolean)

    private fun viaHttp(url: String, title: String): HttpTry {
        val notes = ArrayList<String>()
        var res: Connection.Response? = null
        var gone = false
        var blocked = false
        val uas = listOf(UA, DESKTOP_UA) // ترويسة الجوال أولاً، ثم سطح المكتب إن رُفض الطلب
        for (i in uas.indices) {
            val r = try { connect(url, uas[i]) } catch (e: Exception) { notes.add("جلب ${i + 1}: ${e.javaClass.simpleName}"); continue }
            val code = r.statusCode()
            if (code in 200..299) { res = r; break }
            notes.add("جلب ${i + 1}: HTTP $code")
            if (code == 401 || code == 403 || code == 406 || code == 429) blocked = true
            if (code == 404 || code == 410) { gone = true; break }
        }
        val got = res ?: return HttpTry(null, notes.joinToString("؛ "), gone, blocked)
        if (got.url().host.contains("google.")) return HttpTry(null, "انتهى عند صفحة Google", false, false)
        val doc = try { got.parse() } catch (e: Exception) { return HttpTry(null, prefixOf(notes) + "تحليل الصفحة: ${e.javaClass.simpleName}", false, false) }
        if (doc.text().length < 200) blocked = true // صفحة شبه فارغة: تُرسم بالجافاسكربت أو صفحة تحدٍّ
        val r = judge(doc, title)
        return HttpTry(r.blocks, prefixOf(notes) + r.note, false, blocked)
    }

    private suspend fun viaWeb(ctx: Context, url: String, title: String): ReadResult {
        val html = webHtml(ctx, url) ?: return ReadResult(null, "WebView: انتهت المهلة")
        if (html.isEmpty()) return ReadResult(null, "WebView: لم يرجع HTML")
        val r = judge(Jsoup.parse(html, url), title)
        return ReadResult(r.blocks, "WebView: " + r.note)
    }

    // ---------- مواقع تحتاج متصفحاً: تُحفظ فتبدأ بالمتصفح مباشرة بدل تجربتين فاشلتين أولاً ----------
    private var webHostsCache: MutableSet<String>? = null

    private fun webHosts(ctx: Context): MutableSet<String> = synchronized(this) {
        webHostsCache ?: ConcurrentHashMap.newKeySet<String>().also { set ->
            set.addAll(ctx.applicationContext.getSharedPreferences("lamha_reader", Context.MODE_PRIVATE).getStringSet("webHosts", emptySet()) ?: emptySet())
            webHostsCache = set
        }
    }

    private fun setWebHost(ctx: Context, host: String, on: Boolean) {
        synchronized(this) {
            val cur = webHosts(ctx)
            if (on) cur.add(host) else cur.remove(host)
            ctx.applicationContext.getSharedPreferences("lamha_reader", Context.MODE_PRIVATE)
                .edit().putStringSet("webHosts", HashSet(cur)).apply()
        }
    }

    /** المواقع المحفوظة أنها تحتاج متصفحاً (للتقرير) */
    fun savedWebHosts(ctx: Context): List<String> = webHosts(ctx).sorted()

    private suspend fun fetch(ctx: Context, url: String, title: String): ReadResult {
        val host = GoogleLink.normalizeUrl(url)?.substringBefore('/')
        if (host != null && host in webHosts(ctx)) {
            val w = viaWeb(ctx, url, title)
            if (w.blocks != null) return ReadResult(w.blocks, "موقع محفوظ أنه يحتاج متصفحاً؛ " + w.note)
            // فشل المتصفح: نجرّب العادي، فإن نجح صار الموقع لا يحتاج متصفحاً
            val h = viaHttp(url, title)
            if (h.blocks != null) { setWebHost(ctx, host, false); return ReadResult(h.blocks, h.note) }
            return ReadResult(null, w.note + "؛ " + h.note)
        }
        val h = viaHttp(url, title)
        if (h.blocks != null) return ReadResult(h.blocks, h.note)
        if (h.gone) return ReadResult(null, h.note)
        // آخر محاولة: متصفح حقيقي مخفي (يتجاوز بعض الحمايات، ويرسم الصفحات التي تعتمد على الجافاسكربت)
        val w = viaWeb(ctx, url, title)
        if (w.blocks != null && h.blocked && host != null) setWebHost(ctx, host, true)
        return ReadResult(w.blocks, h.note + "؛ " + w.note)
    }

    private fun prefixOf(notes: List<String>) = if (notes.isEmpty()) "" else notes.joinToString("؛ ") + "؛ "

    /** هل الصفحة هي الخبر المطلوب؟ ثم استخراج نصه. الملاحظة تصف الطريقة أو سبب الفشل */
    private fun judge(doc: Document, title: String): ReadResult {
        // قبل الاستخراج (يحذف وسوماً): صفحة أخرى (قالب مشترك، إعادة توجيه لقسم) تُرفض
        if (!matchesTitle(doc, title)) {
            val pt = (doc.selectFirst("meta[property=og:title]")?.attr("content") ?: doc.title()).take(40)
            return ReadResult(null, "عنوان الصفحة لا يطابق الخبر: $pt")
        }
        val (blocks, how) = extract(doc, title)
        return ReadResult(blocks, how)
    }

    private val webLock = Mutex() // WebView واحد في كل مرة

    private fun decodeJs(v: String?): String? =
        try { JSONTokener(v ?: "null").nextValue() as? String } catch (_: Exception) { null }

    /**
     * يفتح الرابط في WebView مخفي وينتظر حتى يظهر نص كافٍ في الصفحة (حتى 12 ثانية تقريباً، لتمرّ صفحات التحقق)
     * ثم يرجع HTML الصفحة بعد تنفيذ الجافاسكربت. null إن انتهت المهلة
     */
    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun webHtml(ctx: Context, url: String): String? = webLock.withLock {
        withTimeoutOrNull(18_000L) {
            withContext(Dispatchers.Main) {
                suspendCancellableCoroutine<String?> { cont ->
                    val wv = WebView(ctx.applicationContext)
                    var done = false
                    var polling = false
                    // Handler لا View.postDelayed: الـ WebView غير مثبّت في أي نافذة فتبقى أوامر post معلّقة ولا تُنفَّذ أبداً
                    val h = Handler(Looper.getMainLooper())
                    fun finish(res: String?) {
                        if (done) return
                        done = true
                        try { wv.stopLoading() } catch (_: Exception) {}
                        try { wv.destroy() } catch (_: Exception) {}
                        if (cont.isActive) cont.resume(res)
                    }
                    fun poll(tries: Int) {
                        if (done) return
                        wv.evaluateJavascript("(document.body ? document.body.innerText.length : 0)") { v ->
                            val len = v?.trim('"')?.toIntOrNull() ?: 0
                            if (len >= 1200 || tries >= 5) {
                                wv.evaluateJavascript("document.documentElement.outerHTML") { html -> finish(decodeJs(html) ?: "") }
                            } else {
                                h.postDelayed({ poll(tries + 1) }, 2000L)
                            }
                        }
                    }
                    wv.settings.javaScriptEnabled = true
                    wv.settings.domStorageEnabled = true
                    wv.settings.blockNetworkImage = true
                    wv.settings.userAgentString = UA
                    wv.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, u: String?) {
                            if (polling) return
                            polling = true
                            h.postDelayed({ poll(0) }, 1500L)
                        }
                    }
                    cont.invokeOnCancellation { h.post { try { wv.destroy() } catch (_: Exception) {} } }
                    wv.loadUrl(url)
                }
            }
        }
    }

    /**
     * عنوان الصفحة (og:title أو h1 أو title) يجب أن يشارك عنوان الخبر ثلث كلماته الدالة على الأقل.
     * الحد متساهل عمداً (عنوان الصفحة قد يختلف قليلاً عن عنوان الخلاصة)؛ المقصود رفض الصفحة التي لا علاقة لها بالخبر.
     * لا دليل (صفحة بلا عنوان) أو عنوان مطلوب قصير جداً: لا نرفض.
     */
    private fun matchesTitle(doc: Document, title: String): Boolean {
        val heads = listOfNotNull(
            doc.selectFirst("meta[property=og:title]")?.attr("content"),
            doc.selectFirst("h1")?.text(),
            doc.title()
        ).filter { it.isNotBlank() }
        val want = Stories.keyTokens(title)
        if (heads.isEmpty() || want.size < 2) return true
        return heads.any { h ->
            val got = Stories.keyTokens(h)
            want.count { it in got } * 3 >= want.size
        }
    }

    /**
     * نأخذ نص المقال من بيانات الصفحة المهيكلة (JSON-LD: articleBody) إن وجدت لأنه نظيف من الإعلانات،
     * ونقارنه بالاستخراج من وسوم الصفحة: إن كان أقصر منه كثيراً فهو مبتور (مقدمة فقط) فنفضّل الاستخراج من الوسوم.
     * إن فشل الاثنان تُجرَّب بدائل بالترتيب: حاوية المقال، JSON مضمّن في الصفحة (مواقع Next.js)، ثم خبر قصير (عاجل).
     * يرجع النص مع وصف للطريقة الناجحة أو سبب الفشل
     */
    private fun extract(doc: Document, title: String): Pair<List<Block>?, String> {
        // إحصاءات قبل أن يحذف fromHtml وسوم script (لتشخيص صفحات تُرسم بالجافاسكربت)
        val pCount = doc.select("p").size
        val scripts = doc.select("script").size
        val textLen = doc.text().length
        val ld = fromJsonLd(doc, title)
        val emb = if (ld == null) fromEmbedded(doc, title) else null
        val html = fromHtml(doc, title, MIN_CHARS)
        val first = when {
            ld == null -> html
            html == null -> ld
            bodyLen(ld) >= bodyLen(html) * 0.6 -> ld
            else -> html
        }
        if (first != null) return first to (if (first === ld) "JSON-LD" else "وسوم الصفحة")
        fromContainer(doc, title)?.let { return it to "حاوية المقال" }
        emb?.let { return it to "JSON مضمّن" }
        fromOwnText(doc, title)?.let { return it to "نص مباشر في حاوية" }
        fromLines(doc, title)?.let { return it to "أسطر الصفحة" }
        fromHtml(doc, title, SHORT_CHARS)?.let { return it to "خبر قصير" }
        fromLines(doc, title, 40, SHORT_CHARS + 20)?.let { return it to "أسطر قصيرة" }
        return null to "لا نص كافٍ (فقرات p=$pCount، سكربت=$scripts، نص الصفحة=$textLen حرف)"
    }

    private val CONTAINERS = "[itemprop=articleBody],article,[class*=article-body],[class*=articleBody],[class*=story-body]," +
        "[class*=entry-content],[class*=post-content],[class*=news-body],[class*=details-body],[class*=article-content]," +
        "[id*=article-body],[class*=content-body],[class*=article_body],[class*=news-content]"

    /** بديل: نص حاوية المقال كاملاً (حتى لو لم يكن في وسوم p)، نبدأ بأصغر حاوية فيها نص كافٍ لأنها الأدق */
    private fun fromContainer(doc: Document, title: String): List<Block>? {
        for (el in doc.select(CONTAINERS).sortedBy { it.text().length }) {
            el.select("[class*=related],[class*=share],[class*=social],[class*=comment],[class*=advert],[class*=sidebar]").remove()
            val b = bodyToBlocks(el.html(), title)
            if (b != null) return b
        }
        return null
    }

    /**
     * بديل: بعض المواقع تضع الخبر نصاً مباشراً داخل div تفصل بينه وسوم br بلا وسوم p. نأخذ العنصر الذي يحوي أكبر نص مباشر
     * (ownText: النص الذي ليس داخل عناصر أبنائه)، وهو في الغالب جسم الخبر
     */
    private fun fromOwnText(doc: Document, title: String): List<Block>? {
        val best = doc.select("div,section,article,main,td,span").maxByOrNull { it.ownText().length } ?: return null
        if (best.ownText().length < MIN_CHARS) return null
        best.select("[class*=related],[class*=share],[class*=social],[class*=comment],[class*=advert],[class*=sidebar]").remove()
        return bodyToBlocks(best.html(), title)
    }

    /**
     * آخر بديل: كل أسطر الصفحة الطويلة (60 حرفاً فأكثر) بعد حذف القوائم والإعلانات والمشاركة. القوائم والأزرار أسطرها قصيرة فتسقط،
     * فيبقى في الغالب جسم الخبر. أقل دقة من غيره فيُجرَّب أخيراً
     */
    private fun fromLines(doc: Document, title: String, minLine: Int = 60, minTotal: Int = MIN_CHARS): List<Block>? {
        val body = doc.body() ?: return null
        body.select("[class*=related],[class*=share],[class*=social],[class*=comment],[class*=advert],[class*=sidebar],[class*=menu],[class*=cookie]").remove()
        val txt = Parser.unescapeEntities(body.html().replace(BREAKS, "\n").replace(TAGS, ""), false).replace('\u00A0', ' ')
        val lines = txt.split("\n").map { it.trim().replace(SPACES, " ") }.filter { it.length >= minLine }
        return bodyToBlocks(lines.joinToString("\n"), title, minTotal)
    }

    private val SPACES = Regex("\\s+")

    private val BODY_KEYS = Regex("(?i)^(body|content|articleBody|text|html|bodyHtml|story)$")

    private fun collectBodies(v: Any?, key: String?, out: MutableList<String>, depth: Int) {
        if (depth > 14) return
        when (v) {
            is JSONObject -> for (k in v.keys()) collectBodies(v.opt(k), k, out, depth + 1)
            is JSONArray -> for (i in 0 until v.length()) collectBodies(v.opt(i), key, out, depth + 1)
            is String -> if (key != null && BODY_KEYS.matches(key) && v.length >= MIN_CHARS) out.add(v)
        }
    }

    /** بديل: صفحات Next.js وأشباهها تضع الخبر في JSON داخل script بدل وسوم p: نأخذ أطول نص تحت مفتاح body/content/text */
    private fun fromEmbedded(doc: Document, title: String): List<Block>? {
        for (s in doc.select("script#__NEXT_DATA__, script[type=application/json]")) {
            val raw = s.data().trim()
            if (raw.length < MIN_CHARS || raw.length > 1_200_000) continue
            val found = ArrayList<String>()
            try { collectBodies(JSONTokener(raw).nextValue(), null, found, 0) } catch (_: Exception) { continue }
            val best = found.maxByOrNull { it.length } ?: continue
            val b = bodyToBlocks(best, title)
            if (b != null) return b
        }
        return null
    }

    private fun bodyLen(b: List<Block>) = b.filter { !it.heading }.sumOf { it.text.length }

    private fun fromJsonLd(doc: Document, title: String): List<Block>? {
        for (s in doc.select("script[type=application/ld+json]")) {
            val raw = s.data().trim()
            if (raw.isEmpty()) continue
            val body = try { findBody(JSONTokener(raw).nextValue()) } catch (_: Exception) { null } ?: continue
            val blocks = bodyToBlocks(body, title)
            if (blocks != null) return blocks
        }
        return null
    }

    private fun findBody(v: Any?): String? {
        when (v) {
            is JSONObject -> {
                val b = v.optString("articleBody", "")
                if (b.length >= MIN_CHARS) return b
                for (k in v.keys()) {
                    if (k == "articleBody") continue
                    val x = v.opt(k)
                    if (x is JSONObject || x is JSONArray) findBody(x)?.let { return it }
                }
            }
            is JSONArray -> for (i in 0 until v.length()) findBody(v.opt(i))?.let { return it }
        }
        return null
    }

    private val TAGS = Regex("<[^>]+>")
    private val BREAKS = Regex("(?i)<br\\s*/?>|</p>|</div>|</h[1-6]>|</li>")
    private val SENTENCE_END = Regex("(?<=[.!?\\u061F])\\s+")

    private fun bodyToBlocks(raw: String, title: String, min: Int = MIN_CHARS): List<Block>? {
        var s = raw
        if (s.contains('<')) s = Parser.unescapeEntities(s.replace(BREAKS, "\n").replace(TAGS, ""), false)
        s = s.replace('\u00A0', ' ')
        var paras = s.split(Regex("\\s*\\n\\s*")).map { it.trim() }.filter { it.isNotEmpty() }
        // نص واحد متصل بلا فواصل: نقسمه إلى فقرات بحدود الجمل ليسهل قراءته
        if (paras.size <= 1 && s.length > 600) {
            val chunks = ArrayList<String>()
            val cur = StringBuilder()
            for (sen in s.trim().split(SENTENCE_END)) {
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(sen)
                if (cur.length >= 280) { chunks.add(cur.toString()); cur.setLength(0) }
            }
            if (cur.isNotEmpty()) chunks.add(cur.toString())
            paras = chunks
        }
        val out = ArrayList<Block>()
        var chars = 0
        for (t in paras) {
            if (t == title || t.length < 20) continue
            if (t.length < 120 && JUNK_PREFIX.any { t.startsWith(it) }) continue
            out.add(Block(t, false))
            chars += t.length
            if (chars > MAX_CHARS) break
        }
        return if (chars >= min) out else null
    }

    private fun fromHtml(doc: Document, title: String, min: Int): List<Block>? {
        doc.select("script,style,noscript,nav,header,footer,aside,iframe,figure,figcaption,img,picture,video,audio,svg,button,select,input,template").remove()

        // نختار الحاوية التي فيها أكبر نص فقرات: كل فقرة تعطي نقاطها لأبيها، ونصفها لجدها
        val score = HashMap<Element, Int>()
        for (p in doc.select("p")) {
            val len = p.text().length
            if (len < 40) continue
            val parent = p.parent() ?: continue
            score[parent] = (score[parent] ?: 0) + len
            parent.parent()?.let { score[it] = (score[it] ?: 0) + len / 2 }
        }
        val best = score.maxByOrNull { it.value }?.key ?: return null

        // تنظيف داخل الحاوية فقط (حتى لا نحذف الحاوية نفسها): مقالات ذات صلة، مشاركة، تعليقات، إعلانات
        best.select(
            "[class*=related],[class*=share],[class*=social],[class*=comment],[class*=advert]," +
                "[class*=newsletter],[class*=sidebar],[class*=promo],[class*=subscribe]"
        ).remove()

        val out = ArrayList<Block>()
        var chars = 0
        var bodyChars = 0
        var last = ""
        for (e in best.select("p, h2, h3")) {
            val t = e.text().replace('\u00A0', ' ').trim()
            val heading = e.tagName() != "p"
            if (t == last || t == title) continue
            if (heading) {
                if (t.length !in 3..120) continue
            } else {
                if (t.length < 20) continue
                if (t.length < 120 && JUNK_PREFIX.any { t.startsWith(it) }) continue
            }
            out.add(Block(t, heading))
            last = t
            chars += t.length
            if (!heading) bodyChars += t.length
            if (chars > MAX_CHARS) break
        }
        // عنوان فرعي في آخر القائمة بلا فقرة بعده لا معنى له
        while (out.isNotEmpty() && out.last().heading) out.removeAt(out.size - 1)
        return if (bodyChars >= min) out else null
    }
}
