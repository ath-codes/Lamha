package com.lamha.news

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.parser.Parser
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/** فقرة من نص الخبر (heading = عنوان فرعي) */
class Block(val text: String, val heading: Boolean)

/**
 * طلب قراءة: الخبر المضغوط عليه، ثم نسخ الخبر نفسه من مصادر أخرى (للاستعارة منها إن تعذّر فتح نسخته).
 * كل مرشح يُجلب برابطه وعنوانه هو (روابط Google News مستبعدة لأنها لا تفتح مباشرة)، وما يُعرض يُنسب لصاحبه الحقيقي.
 */
class ReadReq(val article: Article, val candidates: List<Article>)

/** وضع القراءة: يجلب الصفحة ويستخرج نص الخبر فقط (بلا إعلانات ولا صور). يرجع null إن لم ينجح فنفتح الصفحة الأصلية */
object Reader {
    private const val UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
    private const val MAX_CHARS = 25_000
    private const val MIN_CHARS = 300

    // ذاكرة مؤقتة لآخر 8 أخبار قُرئت، فلا يُعاد جلبها عند فتحها مرة ثانية
    private val cache = object : LinkedHashMap<String, List<Block>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<Block>>) = size > 8
    }

    // أسطر قصيرة تبدأ بهذه العبارات تعتبر روابط جانبية لا نص خبر
    private val JUNK_PREFIX = listOf(
        "اقرأ أيضا", "اقرأ أيضاً", "اقرأ أيضًا", "إقرأ أيضا", "إقرأ أيضاً", "اقرأ المزيد", "للمزيد",
        "شاهد أيضا", "شاهد أيضاً", "شاهد أيضًا", "تابعونا", "تابعنا", "تابع ", "اشترك", "حقوق النشر",
        "جميع الحقوق", "مواضيع ذات صلة", "المزيد من"
    )

    suspend fun load(url: String, title: String): List<Block>? = withContext(Dispatchers.IO) {
        synchronized(cache) { cache[url] }?.let { return@withContext it }
        val r = try { fetch(url, title) } catch (_: Exception) { null }
        if (r != null) synchronized(cache) { cache[url] = r }
        r
    }

    private fun fetch(url: String, title: String): List<Block>? {
        val res = Jsoup.connect(Rss.https(url))
            .userAgent(UA)
            .header("Accept-Language", "ar,en;q=0.8")
            .timeout(9000)
            .maxBodySize(1_500_000)
            .followRedirects(true)
            .execute()
        if (res.url().host.contains("google.")) return null // صفحة وسيطة لا الخبر نفسه
        val doc = res.parse()
        // قبل الاستخراج (يحذف وسوماً): هل الصفحة هي الخبر الذي طلبناه فعلاً؟ صفحة أخرى (قالب مشترك، إعادة توجيه لقسم) تُرفض
        if (!matchesTitle(doc, title)) return null
        return extract(doc, title)
    }

    /**
     * عنوان الصفحة (og:title أو h1 أو title) يجب أن يشارك عنوان الخبر ثلث كلماته الدالة على الأقل.
     * الحد متساهل عمداً (عنوان الصفحة قد يختلف قليلاً عن عنوان الخلاصة)؛ المقصود رفض الصفحة التي لا علاقة لها بالخبر.
     * لا دليل (صفحة بلا عنوان) أو عنوان مطلوب قصير جداً: لا نرفض.
     */
    private fun matchesTitle(doc: Document, title: String): Boolean {
        val heads = listOfNotNull(
            doc.selectFirst("meta[property=og:title]")?.attr("content"),
            doc.selectFirst("h1")?.text(),
            doc.title()
        ).filter { it.isNotBlank() }
        val want = Stories.keyTokens(title)
        if (heads.isEmpty() || want.size < 2) return true
        return heads.any { h ->
            val got = Stories.keyTokens(h)
            want.count { it in got } * 3 >= want.size
        }
    }

    /**
     * نأخذ نص المقال من بيانات الصفحة المهيكلة (JSON-LD: articleBody) إن وجدت لأنه نظيف من الإعلانات،
     * ونقارنه بالاستخراج من وسوم الصفحة: إن كان أقصر منه كثيراً فهو مبتور (مقدمة فقط) فنفضّل الاستخراج من الوسوم
     */
    private fun extract(doc: Document, title: String): List<Block>? {
        val ld = fromJsonLd(doc, title) // قبل أن يحذف fromHtml وسوم script
        val html = fromHtml(doc, title)
        return when {
            ld == null -> html
            html == null -> ld
            bodyLen(ld) >= bodyLen(html) * 0.6 -> ld
            else -> html
        }
    }

    private fun bodyLen(b: List<Block>) = b.filter { !it.heading }.sumOf { it.text.length }

    private fun fromJsonLd(doc: Document, title: String): List<Block>? {
        for (s in doc.select("script[type=application/ld+json]")) {
            val raw = s.data().trim()
            if (raw.isEmpty()) continue
            val body = try { findBody(JSONTokener(raw).nextValue()) } catch (_: Exception) { null } ?: continue
            val blocks = bodyToBlocks(body, title)
            if (blocks != null) return blocks
        }
        return null
    }

    private fun findBody(v: Any?): String? {
        when (v) {
            is JSONObject -> {
                val b = v.optString("articleBody", "")
                if (b.length >= MIN_CHARS) return b
                for (k in v.keys()) {
                    if (k == "articleBody") continue
                    val x = v.opt(k)
                    if (x is JSONObject || x is JSONArray) findBody(x)?.let { return it }
                }
            }
            is JSONArray -> for (i in 0 until v.length()) findBody(v.opt(i))?.let { return it }
        }
        return null
    }

    private val TAGS = Regex("<[^>]+>")
    private val BREAKS = Regex("(?i)<br\\s*/?>|</p>|</div>|</h[1-6]>|</li>")
    private val SENTENCE_END = Regex("(?<=[.!?\\u061F])\\s+")

    private fun bodyToBlocks(raw: String, title: String): List<Block>? {
        var s = raw
        if (s.contains('<')) s = Parser.unescapeEntities(s.replace(BREAKS, "\n").replace(TAGS, ""), false)
        s = s.replace('\u00A0', ' ')
        var paras = s.split(Regex("\\s*\\n\\s*")).map { it.trim() }.filter { it.isNotEmpty() }
        // نص واحد متصل بلا فواصل: نقسمه إلى فقرات بحدود الجمل ليسهل قراءته
        if (paras.size <= 1 && s.length > 600) {
            val chunks = ArrayList<String>()
            val cur = StringBuilder()
            for (sen in s.trim().split(SENTENCE_END)) {
                if (cur.isNotEmpty()) cur.append(' ')
                cur.append(sen)
                if (cur.length >= 280) { chunks.add(cur.toString()); cur.setLength(0) }
            }
            if (cur.isNotEmpty()) chunks.add(cur.toString())
            paras = chunks
        }
        val out = ArrayList<Block>()
        var chars = 0
        for (t in paras) {
            if (t == title || t.length < 20) continue
            if (t.length < 120 && JUNK_PREFIX.any { t.startsWith(it) }) continue
            out.add(Block(t, false))
            chars += t.length
            if (chars > MAX_CHARS) break
        }
        return if (chars >= MIN_CHARS) out else null
    }

    private fun fromHtml(doc: Document, title: String): List<Block>? {
        doc.select("script,style,noscript,nav,header,footer,aside,form,iframe,figure,figcaption,img,picture,video,audio,svg,button,select,input,template").remove()

        // نختار الحاوية التي فيها أكبر نص فقرات: كل فقرة تعطي نقاطها لأبيها، ونصفها لجدها
        val score = HashMap<Element, Int>()
        for (p in doc.select("p")) {
            val len = p.text().length
            if (len < 40) continue
            val parent = p.parent() ?: continue
            score[parent] = (score[parent] ?: 0) + len
            parent.parent()?.let { score[it] = (score[it] ?: 0) + len / 2 }
        }
        val best = score.maxByOrNull { it.value }?.key ?: return null

        // تنظيف داخل الحاوية فقط (حتى لا نحذف الحاوية نفسها): مقالات ذات صلة، مشاركة، تعليقات، إعلانات
        best.select(
            "[class*=related],[class*=share],[class*=social],[class*=comment],[class*=advert]," +
                "[class*=newsletter],[class*=sidebar],[class*=promo],[class*=subscribe]"
        ).remove()

        val out = ArrayList<Block>()
        var chars = 0
        var bodyChars = 0
        var last = ""
        for (e in best.select("p, h2, h3")) {
            val t = e.text().replace('\u00A0', ' ').trim()
            val heading = e.tagName() != "p"
            if (t == last || t == title) continue
            if (heading) {
                if (t.length !in 3..120) continue
            } else {
                if (t.length < 20) continue
                if (t.length < 120 && JUNK_PREFIX.any { t.startsWith(it) }) continue
            }
            out.add(Block(t, heading))
            last = t
            chars += t.length
            if (!heading) bodyChars += t.length
            if (chars > MAX_CHARS) break
        }
        // عنوان فرعي في آخر القائمة بلا فقرة بعده لا معنى له
        while (out.isNotEmpty() && out.last().heading) out.removeAt(out.size - 1)
        return if (bodyChars >= MIN_CHARS) out else null
    }
}
