package com.lamha.news

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handle(intent)
        setContent { LamhaApp(vm) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val l = i?.getStringExtra("link") ?: return
        i.removeExtra("link")
        vm.openLink(l)
    }

    override fun onStart() {
        super.onStart()
        vm.refreshIfStale()
    }

    override fun onStop() {
        super.onStop()
        vm.markClosed()
    }
}

class MainVM(private val app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    var interests by mutableStateOf(repo.interests)
    var onboarded by mutableStateOf(repo.onboarded)
    var articles by mutableStateOf<List<Article>>(emptyList()) // يُحمَّل من الكاش في الخلفية
    var loading by mutableStateOf(repo.onboarded) // true حتى يجهز الكاش فلا تظهر شاشة فارغة
    var failed by mutableStateOf(false)
    var alertMin by mutableStateOf(repo.alertMin)
    var disabled by mutableStateOf(repo.disabled)
    var perPage by mutableStateOf(repo.perPage)
    var health by mutableStateOf<Map<String, Health>>(emptyMap())
    var sortMode by mutableStateOf(repo.sortMode)
    var testing by mutableStateOf(false)
    var focusLink by mutableStateOf<String?>(null)
    var hiddenLinks by mutableStateOf(repo.hidden)          // روابط الأخبار المخفية بالسحب
    var lastHidden by mutableStateOf<List<String>?>(null)   // آخر إخفاء (لزر التراجع)
    var saved by mutableStateOf<List<Article>>(emptyList()) // الأخبار المحفوظة
    var newLinks by mutableStateOf<Set<String>>(emptySet()) // أخبار جديدة لم تُشاهد بعد (نقطة "جديد")
    var badgeOn by mutableStateOf(false)                    // إظهار شارة "N أخبار جديدة"
    var usd by mutableStateOf(repo.loadUsd())
    var retain by mutableStateOf(repo.retainDays)           // مدة بقاء الأخبار بالأيام
    var lastUpdate by mutableLongStateOf(repo.lastRefresh)  // وقت آخر تحديث ناجح
    var reading by mutableStateOf<ReadReq?>(null)          // الخبر المفتوح في وضع القراءة
    var viewing by mutableStateOf<StoryView?>(null)        // القصة المفتوحة في شاشة "الصورة الكاملة"

    init {
        val wasOnboarded = onboarded
        if (wasOnboarded) Alerts.schedule(app, alertMin)
        viewModelScope.launch { saved = withContext(Dispatchers.IO) { repo.loadSaved() } }
        viewModelScope.launch {
            val cached = withContext(Dispatchers.IO) {
                cleanLegacyFiles()
                repo.loadCache()
            }
            if (articles.isEmpty()) articles = cached
            // ما نُشر بعد آخر خروج من التطبيق (ومنه ما جلبه العامل الخلفي) يُعتبر جديداً
            val lc = repo.lastClose
            if (lc > 0L) {
                val nl = cached.filter { it.time > lc }.map { it.link }
                if (nl.isNotEmpty()) {
                    newLinks = nl.toSet()
                    badgeOn = true
                }
            }
            if (wasOnboarded) {
                loading = false
                refreshUsd()
                if (articles.isEmpty() || System.currentTimeMillis() - repo.lastRefresh > 10 * 60_000L) refresh()
            }
        }
    }

    // يحذف ملفات إصدارات سابقة (الترجمات المخزنة ونماذج الترجمة التي نُزّلت)
    private fun cleanLegacyFiles() {
        try {
            app.filesDir.listFiles()?.filter {
                it.name.startsWith("translations") || it.name.startsWith("com.google.mlkit")
            }?.forEach { it.deleteRecursively() }
        } catch (_: Exception) {
        }
    }

    fun refreshIfStale() {
        lastUpdate = repo.lastRefresh // قد يكون العامل الخلفي حدّث
        if (!onboarded) return
        refreshUsd() // يتجاهل الطلب داخلياً إن مرّت أقل من ساعة
        if (System.currentTimeMillis() - repo.lastRefresh > 10 * 60_000L) refresh()
    }

    private fun refreshUsd() {
        viewModelScope.launch { repo.refreshUsd()?.let { usd = it } }
    }

    fun markClosed() {
        repo.lastClose = System.currentTimeMillis()
    }

    fun refresh() {
        if (loading) return
        viewModelScope.launch {
            loading = true
            val before = articles.map { it.link }.toHashSet()
            val prevRefresh = repo.lastRefresh
            val r = repo.refresh(interests)
            lastUpdate = repo.lastRefresh
            failed = r.none { it.category in interests }
            if (before.isNotEmpty()) {
                // جديد فعلاً: لم يكن في الكاش ونُشر بعد آخر تحديث (فلا تُحسب الأخبار القديمة التي ظهرت لأول مرة)
                val fresh = r.filter { it.link !in before && it.time > prevRefresh - 30 * 60_000L }.map { it.link }
                if (fresh.isNotEmpty()) {
                    newLinks = newLinks + fresh
                    badgeOn = true
                }
            }
            articles = r
            // لا نحتفظ بروابط مخفية لم تعد في الكاش
            val keep = r.map { it.link }.toHashSet()
            val h = hiddenLinks.filter { it in keep }.toSet()
            if (h.size != hiddenLinks.size) {
                hiddenLinks = h
                repo.hidden = h
            }
            loading = false
        }
        refreshUsd()
    }

    // إخفاء قصة كاملة (كل نسخها من المصادر). تبقى مخفية حتى بعد التحديث
    fun hide(st: Story) {
        val links = st.items.map { it.link }
        hiddenLinks = hiddenLinks + links
        repo.hidden = hiddenLinks
        lastHidden = links
    }

    fun undoHide() {
        val l = lastHidden ?: return
        hiddenLinks = hiddenLinks - l.toSet()
        repo.hidden = hiddenLinks
        lastHidden = null
    }

    fun restoreHidden() {
        hiddenLinks = emptySet()
        repo.hidden = emptySet()
        lastHidden = null
    }

    fun toggleSave(a: Article) {
        val list = if (saved.any { it.link == a.link }) saved.filter { it.link != a.link } else listOf(a) + saved
        saved = list
        viewModelScope.launch(Dispatchers.IO) { repo.saveSaved(list) }
    }

    // يفتح وضع القراءة. الروابط المرشحة: كل نسخ الخبر من المصادر المختلفة، عدا روابط Google News (لا تفتح مباشرة)
    fun openReader(a: Article, alts: List<Article>) {
        val urls = (listOf(a) + alts).map { it.link }.distinct().filter { !it.contains("news.google.com") }
        reading = ReadReq(a, urls)
    }

    fun markSeen(links: Collection<String>) {
        if (newLinks.isEmpty()) return
        val n = newLinks - links.toSet()
        if (n.size != newLinks.size) newLinks = n
    }

    fun save(s: Set<String>) {
        val first = !onboarded
        interests = s; repo.interests = s
        onboarded = true; repo.onboarded = true
        if (first) Alerts.schedule(app, alertMin)
        refresh()
    }

    fun setAlert(min: Int) {
        alertMin = min; repo.alertMin = min
        Alerts.schedule(app, min)
    }

    fun openLink(l: String) {
        viewModelScope.launch {
            val c = withContext(Dispatchers.IO) { repo.loadCache() } // قد يكون العامل الخلفي حدّث الكاش
            if (c.isNotEmpty()) articles = c
            focusLink = l
        }
    }

    fun changeRetain(n: Int) {
        retain = n; repo.retainDays = n
        val limit = System.currentTimeMillis() - n * 24L * 3600_000L
        articles = articles.filter { it.time >= limit }
    }

    fun changePerPage(n: Int) {
        perPage = n; repo.perPage = n
    }

    fun changeSort(n: Int) {
        sortMode = n; repo.sortMode = n
    }

    fun toggle(s: Source) {
        val k = s.key()
        disabled = if (k in disabled) disabled - k else disabled + k
        repo.disabled = disabled
    }

    fun testSources() {
        if (testing) return
        viewModelScope.launch {
            testing = true
            health = repo.test(SOURCES.filter { it.category in interests })
            testing = false
        }
    }
}

// يبحث عن خطوط .ttf داخل assets/fonts؛ إن لم يجدها يستخدم خط النظام
fun loadFont(ctx: Context): FontFamily {
    return try {
        val am = ctx.assets
        val files = (am.list("fonts") ?: emptyArray()).filter { it.endsWith(".ttf", true) || it.endsWith(".otf", true) }
        if (files.isEmpty()) return FontFamily.Default
        val reg = files.firstOrNull { it.contains("regular", true) } ?: files.first()
        val bold = files.firstOrNull { it.contains("bold", true) } ?: reg
        FontFamily(
            Font("fonts/$reg", am, FontWeight.Normal),
            Font("fonts/$bold", am, FontWeight.Bold)
        )
    } catch (e: Exception) {
        FontFamily.Default
    }
}

fun Typography.withFont(f: FontFamily) = Typography(
    displayLarge = displayLarge.copy(fontFamily = f), displayMedium = displayMedium.copy(fontFamily = f),
    displaySmall = displaySmall.copy(fontFamily = f), headlineLarge = headlineLarge.copy(fontFamily = f),
    headlineMedium = headlineMedium.copy(fontFamily = f), headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f), titleMedium = titleMedium.copy(fontFamily = f),
    titleSmall = titleSmall.copy(fontFamily = f), bodyLarge = bodyLarge.copy(fontFamily = f),
    bodyMedium = bodyMedium.copy(fontFamily = f), bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f), labelMedium = labelMedium.copy(fontFamily = f),
    labelSmall = labelSmall.copy(fontFamily = f)
)

@Composable
fun LamhaTheme(dark: Boolean, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val family = remember { loadFont(ctx) }
    val cs = if (dark) darkColorScheme(
        primary = Color(0xFF34D3A5), onPrimary = Color(0xFF04271D),
        background = Color(0xFF0D0F12), surface = Color(0xFF16191E),
        onBackground = Color(0xFFECEFF1), onSurface = Color(0xFFECEFF1),
        surfaceVariant = Color(0xFF1F242B), onSurfaceVariant = Color(0xFF9AA4AF)
    ) else lightColorScheme(
        primary = Color(0xFF0E7C66), onPrimary = Color.White,
        background = Color(0xFFF6F7F4), surface = Color.White,
        onBackground = Color(0xFF111418), onSurface = Color(0xFF111418),
        surfaceVariant = Color(0xFFE6E9E4), onSurfaceVariant = Color(0xFF5B6570)
    )
    MaterialTheme(colorScheme = cs, typography = Typography().withFont(family), content = content)
}

@Composable
fun LamhaApp(vm: MainVM = viewModel()) {
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(vm.onboarded) {
        if (vm.onboarded && Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LamhaTheme(isSystemInDarkTheme()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                var screen by remember { mutableIntStateOf(0) } // 0 أخبار، 1 إعدادات، 2 اهتمامات، 3 محفوظات
                Box(Modifier.fillMaxSize()) {
                when {
                    !vm.onboarded -> Onboarding(vm.interests, false, { vm.save(it) }, {})
                    screen == 2 -> {
                        BackHandler { screen = 1 }
                        Onboarding(vm.interests, true, { vm.save(it); screen = 1 }, { screen = 1 })
                    }
                    screen == 1 -> SettingsScreen(vm, { screen = 0 }, { screen = 2 })
                    screen == 3 -> SavedScreen(vm) { screen = 0 }
                    else -> Feed(vm, { screen = 1 }, { screen = 3 })
                }
                // وضع القراءة يظهر فوق الشاشة الحالية، فيبقى موضعك في القائمة كما هو عند الرجوع
                val sv = vm.viewing
                if (sv != null) key(sv.story.lead.link) { StoryScreen(vm, sv) { vm.viewing = null } }
                val rq = vm.reading
                if (rq != null) key(rq.article.link) { ReaderScreen(rq) { vm.reading = null } }
                }
            }
        }
    }
}

@Composable
fun Onboarding(initial: Set<String>, isEdit: Boolean, onDone: (Set<String>) -> Unit, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var sel by remember { mutableStateOf(initial) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp)) {
        Text(if (isEdit) "اهتماماتك" else "ما الذي يهمّك؟", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "اختر موضوعاً واحداً على الأقل، ويمكنك التغيير لاحقاً",
            color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(Modifier.height(24.dp))
        LazyVerticalGrid(
            GridCells.Fixed(2), Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(CATEGORIES) { c ->
                val on = c.id in sel
                val shape = RoundedCornerShape(20.dp)
                Box(
                    Modifier.height(110.dp).clip(shape)
                        .background(if (on) cs.primary.copy(alpha = 0.16f) else cs.surface)
                        .border(2.dp, if (on) cs.primary else Color.Transparent, shape)
                        .clickable { sel = if (on) sel - c.id else sel + c.id },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(c.emoji, fontSize = 32.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(c.label, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onDone(sel) }, enabled = sel.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)
        ) { Text(if (isEdit) "حفظ" else "ابدأ", fontSize = 16.sp) }
        if (isEdit) TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
    }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) cs.primary else cs.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 14.sp, color = if (selected) cs.onPrimary else cs.onSurface, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun IconText(text: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, fontSize = 20.sp)
    }
}

@Composable
fun SettingsScreen(vm: MainVM, onBack: () -> Unit, onInterests: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    BackHandler(onBack = onBack)
    // إحصائية فعلية: عدد أخبار كل مصدر المحفوظة الآن ونسبتها من الإجمالي
    val active = remember(vm.articles, vm.interests, vm.disabled) {
        vm.articles.filter { it.category in vm.interests && (it.category + "|" + it.source) !in vm.disabled }
    }
    val counts = remember(active) { active.groupingBy { it.category + "|" + it.source }.eachCount() }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconText("→", onBack)
            Spacer(Modifier.width(8.dp))
            Text("الإعدادات", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface)
                        .clickable(onClick = onInterests).padding(16.dp)
                ) { Text("تعديل الاهتمامات  ‹", fontWeight = FontWeight.SemiBold) }
            }
            item {
                Text("التنبيهات الدورية", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "إيقاف", 30 to "كل 30 دقيقة", 60 to "كل ساعة", 180 to "كل 3 ساعات").forEach { (m, label) ->
                        Pill(label, vm.alertMin == m) { vm.setAlert(m) }
                    }
                }
                Text(
                    "قد يؤخر أندرويد التنبيهات قليلاً لتوفير البطارية",
                    color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
            item {
                Text("حجم البطاقات", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "كبير", 2 to "متوسط", 3 to "مضغوط").forEach { (n, label) ->
                        Pill(label, vm.perPage == n) { vm.changePerPage(n) }
                    }
                }
            }
            item {
                Text("ترتيب الأخبار", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "الأحدث", 1 to "الأهم").forEach { (n, label) ->
                        Pill(label, vm.sortMode == n) { vm.changeSort(n) }
                    }
                }
                Text(
                    "الأهم: الخبر الذي غطّته مصادر أكثر يتقدم، مع مراعاة الحداثة",
                    color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
            item {
                Text("مدة بقاء الأخبار", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "يوم", 2 to "يومان", 3 to "3 أيام").forEach { (n, label) ->
                        Pill(label, vm.retain == n) { vm.changeRetain(n) }
                    }
                }
                Text(
                    "الأخبار الأقدم تُحذف تلقائياً، والمحفوظات تبقى دائماً",
                    color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
            item {
                Text("الأخبار الممسوحة", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                if (vm.hiddenLinks.isEmpty()) {
                    Text("لا توجد أخبار ممسوحة. اضغط مطولاً على أي خبر واختر مسح", color = cs.onSurfaceVariant, fontSize = 12.sp)
                } else {
                    Pill("استرجاع الأخبار الممسوحة", false) { vm.restoreHidden() }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("المصادر", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(onClick = { vm.testSources() }, enabled = !vm.testing, shape = RoundedCornerShape(12.dp)) {
                        Text(if (vm.testing) "جارٍ الفحص…" else "فحص المصادر")
                    }
                }
            }
            items(SOURCES.filter { it.category in vm.interests }) { s ->
                val k = s.key()
                val cat = CATEGORIES.firstOrNull { it.id == s.category }?.label ?: ""
                val h = vm.health[k]
                val status = when {
                    h == null -> ""
                    h.count > 0 -> "  ✓ ${h.count} خبر" + if (h.viaFallback) " (عبر البديل)" else ""
                    else -> "  ✗ لا يعمل"
                }
                val n = counts[k] ?: 0
                val pct = if (active.isNotEmpty()) (n * 100 + active.size / 2) / active.size else 0
                val stat = if (k in vm.disabled) "" else "  •  في التطبيق: $n ($pct%)"
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface).padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(s.name, fontWeight = FontWeight.SemiBold)
                        Text(cat + status + stat, fontSize = 12.sp, color = if (h != null && h.count <= 0) Color(0xFFE5484D) else cs.onSurfaceVariant)
                    }
                    Switch(checked = k !in vm.disabled, onCheckedChange = { vm.toggle(s) })
                }
            }
            item {
                val ctxF = LocalContext.current
                val fontFile = remember {
                    try {
                        ctxF.assets.list("fonts")?.firstOrNull { it.endsWith(".ttf", true) || it.endsWith(".otf", true) }
                    } catch (_: Exception) { null }
                }
                Text(
                    "الخط: " + (fontFile?.substringBeforeLast('.')?.substringBefore('-') ?: "خط النظام (لم يُعثر على ملفات الخط)"),
                    color = cs.onSurfaceVariant, fontSize = 11.sp,
                    modifier = Modifier.padding(top = 10.dp).fillMaxWidth(), textAlign = TextAlign.Center
                )
                Text(
                    "سعر الدولار: Rates By Exchange Rate API",
                    color = cs.onSurfaceVariant, fontSize = 11.sp,
                    modifier = Modifier.padding(top = 4.dp).fillMaxWidth(), textAlign = TextAlign.Center
                )
            }
        }
    }
}

/** شريط سعر الدولار بالجنيه. السهم مقارنة بسعر اليوم السابق، ويظهر بعد أول يوم من التشغيل */
@Composable
fun UsdBar(u: Usd) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(cs.primary.copy(alpha = 0.16f))
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("الدولار", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.width(10.dp))
            Text(String.format(Locale.US, "%.2f", u.rate) + " جنيه", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = cs.primary)
            if (u.prev > 0.0) {
                val pct = (u.rate - u.prev) / u.prev * 100.0
                val arrow = if (abs(pct) < 0.005) "▬" else if (pct > 0) "▲" else "▼"
                Spacer(Modifier.width(10.dp))
                Text(arrow + " " + String.format(Locale.US, "%.2f", abs(pct)) + "%", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
        }
        Text(
            ago(u.fetched),
            color = cs.onSurfaceVariant, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
fun Feed(vm: MainVM, onSettings: () -> Unit, onSaved: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var filter by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) } // 0 الكل، 1 مصر، 2 العالم
    val hidden = vm.hiddenLinks
    val list = remember(vm.articles, vm.interests, vm.disabled, filter, tab, vm.sortMode, hidden) {
        val base = vm.articles.filter {
            it.category in vm.interests && (filter == null || it.category == filter) &&
                (it.category + "|" + it.source) !in vm.disabled && Quality.keep(it)
        }
        // نبني القصص أولاً ثم نستبعد التي أُخفي أي من نسخها، فلا تعود إذا غطّتها جهة أخرى لاحقاً
        Stories.order(
            Stories.build(base).filter { st ->
                st.items.none { it.link in hidden } && (tab == 0 || (tab == 1) == st.egypt)
            },
            vm.sortMode == 1
        )
    }
    val savedLinks = remember(vm.saved) { vm.saved.map { it.link }.toHashSet() }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Pill("الكل", filter == null) { filter = null } }
                items(CATEGORIES.filter { it.id in vm.interests }) { c ->
                    Pill("${c.emoji} ${c.label}", filter == c.id) { filter = c.id }
                }
            }
            IconText("🔖", onSaved)
            RefreshButton(vm.lastUpdate, vm.loading) { vm.refresh() }
            IconText("⚙", onSettings)
        }
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("الكل", tab == 0) { tab = 0 }
            Pill("مصر", tab == 1) { tab = 1 }
            Pill("العالم", tab == 2) { tab = 2 }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                list.isEmpty() && vm.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                list.isEmpty() -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (vm.failed) "تعذّر جلب الأخبار، تحقق من الاتصال" else if (tab != 0) "لا توجد أخبار في هذا التبويب بعد" else "لا توجد أخبار بعد", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { vm.refresh() }) { Text("إعادة المحاولة") }
                }
                else -> key(filter, tab) {
                    val ls = rememberLazyListState()
                    val scope = rememberCoroutineScope()
                    LazyColumn(
                        state = ls,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // عنصر علوي ثابت: يجعل الأخبار الجديدة تظهر مباشرة إن كنت في الأعلى، وتبقى مكانك إن كنت تقرأ في الأسفل
                        item(key = "top") {
                            val u = vm.usd
                            if (u != null) UsdBar(u) else Spacer(Modifier.height(0.dp))
                        }
                        items(list, key = { it.lead.link }) { st ->
                            val full: (() -> Unit)? =
                                if (st.sources.size > 1) ({ vm.viewing = StoryView(st, Stories.related(st, list)) }) else null
                            NewsItem(
                                st.lead, vm.perPage, st.sources,
                                isNew = st.items.any { it.link in vm.newLinks },
                                saved = st.lead.link in savedLinks,
                                onSave = { vm.toggleSave(st.lead) },
                                onHide = { vm.hide(st) },
                                onRead = { vm.openReader(st.lead, st.items) },
                                breaking = st.breaking,
                                onFull = full
                            )
                        }
                        item { Spacer(Modifier.navigationBarsPadding()) }
                    }
                    // الخبر الذي بقي ظاهراً ثانيتين يُعتبر مقروءاً فتختفي نقطة "جديد"
                    LaunchedEffect(ls, list) {
                        snapshotFlow { ls.layoutInfo.visibleItemsInfo.map { it.key } }
                            .collectLatest { keys ->
                                delay(2000)
                                val vis: Set<Any> = keys.toHashSet()
                                val seen = list.filter { it.lead.link in vis }.flatMap { st -> st.items.map { it.link } }
                                if (seen.isNotEmpty()) vm.markSeen(seen)
                            }
                    }
                    LaunchedEffect(vm.focusLink, list) {
                        val l = vm.focusLink
                        if (l != null) {
                            val idx = list.indexOfFirst { st -> st.items.any { it.link == l } }
                            if (idx >= 0) {
                                ls.scrollToItem(idx + 1) // +1 للعنصر العلوي
                                vm.focusLink = null
                            } else if (filter != null || tab != 0) { filter = null; tab = 0 }
                            else vm.focusLink = null
                        }
                    }
                    // زر عائم للعودة للأعلى عند التمرير الطويل
                    val showTop by remember { derivedStateOf { ls.firstVisibleItemIndex > 6 } }
                    if (showTop) {
                        Box(
                            Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(16.dp).size(46.dp)
                                .clip(CircleShape).background(cs.primary)
                                .clickable { scope.launch { ls.animateScrollToItem(0) } },
                            contentAlignment = Alignment.Center
                        ) { Text("↑", color = cs.onPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                    }
                    // نعدّ فقط الأخبار الجديدة التي فوق موضعك الحالي، فيطابق الرقم ما ستجده عند الصعود
                    val aboveNew by remember(list) {
                        derivedStateOf {
                            val f = ls.firstVisibleItemIndex // 0 = العنصر العلوي (الدولار)
                            list.take((f - 1).coerceAtLeast(0)).count { st -> st.items.any { it.link in vm.newLinks } }
                        }
                    }
                    if (vm.badgeOn && aboveNew > 0) {
                        Box(
                            Modifier.align(Alignment.TopCenter).padding(top = 8.dp)
                                .clip(RoundedCornerShape(50)).background(cs.primary)
                                .clickable {
                                    vm.badgeOn = false
                                    scope.launch { ls.animateScrollToItem(0) }
                                }
                                .padding(horizontal = 16.dp, vertical = 9.dp)
                        ) {
                            Text(aboveNew.toString(), color = cs.onPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
            if (vm.loading && list.isNotEmpty()) {
                LinearProgressIndicator(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(2.dp))
            }
            val last = vm.lastHidden
            if (last != null) {
                LaunchedEffect(last) {
                    delay(5000)
                    if (vm.lastHidden === last) vm.lastHidden = null
                }
                Row(
                    Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp)
                        .clip(RoundedCornerShape(14.dp)).background(cs.inverseSurface)
                        .padding(start = 16.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("تم مسح الخبر", color = cs.inverseOnSurface, fontSize = 14.sp)
                    Spacer(Modifier.width(12.dp))
                    TextButton(onClick = { vm.undoHide() }) { Text("تراجع", color = cs.inversePrimary, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
fun SavedScreen(vm: MainVM, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconText("→", onBack)
            Spacer(Modifier.width(8.dp))
            Text("المحفوظات", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        if (vm.saved.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    "لا توجد أخبار محفوظة بعد\nاضغط مطولاً على أي خبر واختر حفظ ليظهر هنا",
                    color = cs.onSurfaceVariant, textAlign = TextAlign.Center, lineHeight = 26.sp
                )
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(vm.saved, key = { it.link }) { a ->
                    NewsItem(a, vm.perPage, emptyList(), isNew = false, saved = true, onSave = { vm.toggleSave(a) }, onRead = { vm.openReader(a, emptyList()) })
                }
            }
        }
    }
}

fun agoShort(t: Long, now: Long): String {
    val m = ((now - t) / 60000).coerceAtLeast(0)
    return when {
        m < 1 -> "الآن"
        m < 60 -> "منذ $m د"
        m < 1440 -> "منذ ${m / 60} س"
        else -> "منذ ${m / 1440} يوم"
    }
}

/** زر التحديث، وتحته وقت آخر تحديث ناجح (يتجدد كل نصف دقيقة) */
@Composable
fun RefreshButton(last: Long, loading: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            tick = System.currentTimeMillis()
        }
    }
    val label = when {
        loading -> "…"
        last <= 0L -> ""
        else -> agoShort(last, tick)
    }
    Column(
        Modifier.width(54.dp).height(44.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("↻", fontSize = 19.sp)
        if (label.isNotEmpty()) Text(label, fontSize = 9.sp, color = cs.onSurfaceVariant, maxLines = 1)
    }
}

/** قائمة الضغطة المطوّلة: بطاقة مدوّرة فيها عنوان الخبر وصفوف بأيقونات ملوّنة، و"مسح" بالأحمر */
@Composable
fun NewsMenu(a: Article, saved: Boolean, onSave: (() -> Unit)?, onHide: (() -> Unit)?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                Modifier.padding(horizontal = 28.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp)).background(cs.surface).padding(vertical = 10.dp)
            ) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                    Text(a.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        a.title, color = cs.onSurface, fontSize = 15.sp, lineHeight = 22.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }
                Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(1.dp).background(cs.onSurface.copy(alpha = 0.08f)))
                Spacer(Modifier.height(6.dp))
                if (onSave != null) {
                    MenuRow("🔖", if (saved) "إزالة من المحفوظات" else "حفظ الخبر", cs.primary) { onDismiss(); onSave() }
                }
                MenuRow("📤", "مشاركة", cs.primary) {
                    onDismiss()
                    try {
                        val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                            .putExtra(Intent.EXTRA_TEXT, a.title + "\n" + a.link)
                        ctx.startActivity(Intent.createChooser(send, null))
                    } catch (_: Exception) {
                    }
                }
                if (onHide != null) {
                    Box(Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth().height(1.dp).background(cs.onSurface.copy(alpha = 0.08f)))
                    MenuRow("🗑", "مسح الخبر", Color(0xFFE5484D), destructive = true) { onDismiss(); onHide() }
                }
            }
        }
    }
}

@Composable
fun MenuRow(icon: String, label: String, tint: Color, destructive: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(tint.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
            Text(icon, fontSize = 18.sp)
        }
        Spacer(Modifier.width(14.dp))
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = if (destructive) tint else cs.onSurface)
    }
}

/** وضع القراءة: نص الخبر فقط. إن تعذّر استخراج النص تُفتح الصفحة الأصلية في المتصفح تلقائياً */
@Composable
fun ReaderScreen(req: ReadReq, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    BackHandler(onBack = onClose)
    val a = req.article
    var blocks by remember { mutableStateOf<List<Block>?>(null) }
    LaunchedEffect(a.link) {
        var got: List<Block>? = null
        for (u in req.urls) {
            got = Reader.load(u, a.title)
            if (got != null) break
        }
        if (got != null) {
            blocks = got
        } else {
            Toast.makeText(ctx, "تعذّر وضع القراءة، فُتحت الصفحة الأصلية", Toast.LENGTH_SHORT).show()
            try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.link))) } catch (_: Exception) {}
            onClose()
        }
    }
    Surface(Modifier.fillMaxSize(), color = cs.background) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconText("→", onClose)
                Spacer(Modifier.weight(1f))
                Text(
                    "الصفحة الأصلية ↗", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp))
                        .clickable { try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.link))) } catch (_: Exception) {} }
                        .padding(horizontal = 8.dp, vertical = 8.dp)
                )
            }
            val b = blocks
            if (b == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Column {
                            Row {
                                Text(a.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("  •  ${ago(a.time)}", color = cs.onSurfaceVariant, fontSize = 13.sp)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(a.title, fontSize = 24.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    items(b) { blk ->
                        if (blk.heading) Text(blk.text, fontSize = 19.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold)
                        else Text(blk.text, fontSize = 17.sp, lineHeight = 30.sp)
                    }
                }
            }
        }
    }
}

fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "الآن"
        m < 60 -> "منذ $m د"
        m < 1440 -> "منذ ${m / 60} س"
        else -> "منذ ${m / 1440} يوم"
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NewsItem(
    a: Article, size: Int, sources: List<String> = emptyList(),
    isNew: Boolean = false, saved: Boolean = false, onSave: (() -> Unit)? = null, onHide: (() -> Unit)? = null, onRead: (() -> Unit)? = null,
    breaking: Boolean = false, onFull: (() -> Unit)? = null
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val cat = CATEGORIES.firstOrNull { it.id == a.category }
    val tSize = when (size) { 1 -> 24.sp; 2 -> 20.sp; else -> 17.sp }
    val tLine = when (size) { 1 -> 34.sp; 2 -> 29.sp; else -> 25.sp }
    val tMax = when (size) { 1 -> 6; 2 -> 4; else -> 3 }
    val sSize = when (size) { 1 -> 16.sp; 2 -> 15.sp; else -> 13.5.sp }
    val sLine = when (size) { 1 -> 26.sp; 2 -> 22.sp; else -> 20.sp }
    val sMax = when (size) { 1 -> 8; 2 -> 4; else -> 2 }
    var menu by remember { mutableStateOf(false) }
    // ضغطة مطوّلة على البطاقة تفتح قائمة: حفظ، مشاركة، مسح. بلا وميض عند الضغط (indication = null)
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surface)
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null,
                onClick = {}, onLongClick = { menu = true }
            )
            .padding(16.dp)
    ) {
        if (menu) NewsMenu(a, saved, onSave, onHide) { menu = false }
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (isNew) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(cs.primary))
                Spacer(Modifier.width(6.dp))
            }
            if (breaking) {
                Text(
                    "عاجل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                    modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFFE5484D))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
                Spacer(Modifier.width(6.dp))
            }
            Text(a.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            Text("  •  ${ago(a.time)}", color = cs.onSurfaceVariant, fontSize = 12.5.sp)
            Spacer(Modifier.weight(1f))
            if (cat != null) Text(cat.emoji, fontSize = 15.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            a.title, fontSize = tSize, lineHeight = tLine, fontWeight = FontWeight.Bold,
            maxLines = tMax, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth()
        )
        if (a.summary.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                a.summary, fontSize = sSize, lineHeight = sLine, color = cs.onSurfaceVariant,
                maxLines = sMax, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth()
            )
        }
        if (sources.size > 1) {
            Spacer(Modifier.height(8.dp))
            Text(
                Stories.coverText(sources.size) + ": " + sources.joinToString("، "),
                color = cs.onSurfaceVariant, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "قراءة الخبر ↗", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.clip(RoundedCornerShape(10.dp))
                    .clickable {
                        if (onRead != null) onRead()
                        else try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.link))) } catch (_: Exception) {}
                    }
                    .padding(horizontal = 4.dp, vertical = 6.dp)
            )
            if (onFull != null) {
                Spacer(Modifier.width(10.dp))
                Text(
                    "الصورة الكاملة · ${sources.size}", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onFull() }
                        .padding(horizontal = 4.dp, vertical = 6.dp)
                )
            }
        }
    }
}


/** الصورة الكاملة: ما نشرته كل جهة عن الخبر مرتباً من الأقدم للأحدث (كيف تطوّر)، ثم أخبار ذات صلة كخلفية */
@Composable
fun StoryScreen(vm: MainVM, sv: StoryView, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    BackHandler(onBack = onClose)
    val st = sv.story
    val timeline = remember(st) { st.items.sortedBy { it.time } }
    Surface(Modifier.fillMaxSize(), color = cs.background) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconText("→", onClose)
                Spacer(Modifier.width(4.dp))
                Text("الصورة الكاملة", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Column {
                        Text(st.lead.title, fontSize = 22.sp, lineHeight = 33.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            Stories.coverText(st.sources.size) + "  •  أول ظهور " + ago(timeline.first().time) +
                                "  •  آخر تحديث " + ago(timeline.last().time),
                            color = cs.onSurfaceVariant, fontSize = 12.5.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Text("كيف تناولته المصادر", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
                items(timeline, key = { it.link }) { a ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface)
                            .clickable { vm.openReader(a, st.items) }.padding(14.dp)
                    ) {
                        Row {
                            Text(a.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            Text("  •  ${ago(a.time)}", color = cs.onSurfaceVariant, fontSize = 12.5.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(a.title, fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Bold)
                        if (a.summary.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                a.summary, fontSize = 13.5.sp, lineHeight = 20.sp, color = cs.onSurfaceVariant,
                                maxLines = 4, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                if (sv.related.isNotEmpty()) {
                    item {
                        Text(
                            "خلفية وأخبار ذات صلة", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                            modifier = Modifier.padding(top = 10.dp)
                        )
                    }
                    items(sv.related, key = { "r" + it.lead.link }) { r ->
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface)
                                .clickable { vm.openReader(r.lead, r.items) }.padding(14.dp)
                        ) {
                            Row {
                                Text(r.lead.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                                Text("  •  ${ago(r.lead.time)}", color = cs.onSurfaceVariant, fontSize = 12.5.sp)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(r.lead.title, fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
