package com.lamha.news

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LamhaApp() }
    }
}

class MainVM(private val app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    var interests by mutableStateOf(repo.interests)
    var onboarded by mutableStateOf(repo.onboarded)
    var articles by mutableStateOf(repo.loadCache())
    var loading by mutableStateOf(false)
    var failed by mutableStateOf(false)
    var alertMin by mutableStateOf(repo.alertMin)
    var disabled by mutableStateOf(repo.disabled)
    var perPage by mutableStateOf(repo.perPage)
    var health by mutableStateOf<Map<String, Int>>(emptyMap())
    var testing by mutableStateOf(false)

    init {
        if (onboarded) {
            Alerts.schedule(app, alertMin)
            if (articles.isEmpty() || System.currentTimeMillis() - repo.lastRefresh > 10 * 60_000L) refresh()
        }
    }

    fun refresh() {
        if (loading) return
        viewModelScope.launch {
            loading = true
            val r = repo.refresh(interests)
            failed = r.none { it.category in interests }
            articles = r
            loading = false
        }
    }

    fun save(s: Set<String>) {
        val first = !onboarded
        interests = s; repo.interests = s
        onboarded = true; repo.onboarded = true
        if (first) Alerts.schedule(app, alertMin)
        refresh()
    }

    fun setAlert(min: Int) {
        alertMin = min; repo.alertMin = min
        Alerts.schedule(app, min)
    }

    fun changePerPage(n: Int) {
        perPage = n; repo.perPage = n
    }

    fun toggle(s: Source) {
        val k = s.key()
        disabled = if (k in disabled) disabled - k else disabled + k
        repo.disabled = disabled
    }

    fun testSources() {
        if (testing) return
        viewModelScope.launch {
            testing = true
            health = repo.test(SOURCES.filter { it.category in interests })
            testing = false
        }
    }
}

@Composable
fun LamhaTheme(dark: Boolean, content: @Composable () -> Unit) {
    val cs = if (dark) darkColorScheme(
        primary = Color(0xFF34D3A5), onPrimary = Color(0xFF04271D),
        background = Color(0xFF0D0F12), surface = Color(0xFF16191E),
        onBackground = Color(0xFFECEFF1), onSurface = Color(0xFFECEFF1),
        surfaceVariant = Color(0xFF1F242B), onSurfaceVariant = Color(0xFF9AA4AF)
    ) else lightColorScheme(
        primary = Color(0xFF0E7C66), onPrimary = Color.White,
        background = Color(0xFFF6F7F4), surface = Color.White,
        onBackground = Color(0xFF111418), onSurface = Color(0xFF111418),
        surfaceVariant = Color(0xFFE6E9E4), onSurfaceVariant = Color(0xFF5B6570)
    )
    MaterialTheme(colorScheme = cs, content = content)
}

@Composable
fun LamhaApp(vm: MainVM = viewModel()) {
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(vm.onboarded) {
        if (vm.onboarded && Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LamhaTheme(isSystemInDarkTheme()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                var screen by remember { mutableIntStateOf(0) } // 0 أخبار، 1 إعدادات، 2 اهتمامات
                when {
                    !vm.onboarded -> Onboarding(vm.interests, false, { vm.save(it) }, {})
                    screen == 2 -> {
                        BackHandler { screen = 1 }
                        Onboarding(vm.interests, true, { vm.save(it); screen = 1 }, { screen = 1 })
                    }
                    screen == 1 -> SettingsScreen(vm, { screen = 0 }, { screen = 2 })
                    else -> Feed(vm) { screen = 1 }
                }
            }
        }
    }
}

@Composable
fun Onboarding(initial: Set<String>, isEdit: Boolean, onDone: (Set<String>) -> Unit, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var sel by remember { mutableStateOf(initial) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp)) {
        Text(if (isEdit) "اهتماماتك" else "ما الذي يهمّك؟", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "اختر موضوعاً واحداً على الأقل، ويمكنك التغيير لاحقاً",
            color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(Modifier.height(24.dp))
        LazyVerticalGrid(
            GridCells.Fixed(2), Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(CATEGORIES) { c ->
                val on = c.id in sel
                val shape = RoundedCornerShape(20.dp)
                Box(
                    Modifier.height(110.dp).clip(shape)
                        .background(if (on) cs.primary.copy(alpha = 0.16f) else cs.surface)
                        .border(2.dp, if (on) cs.primary else Color.Transparent, shape)
                        .clickable { sel = if (on) sel - c.id else sel + c.id },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(c.emoji, fontSize = 32.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(c.label, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onDone(sel) }, enabled = sel.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)
        ) { Text(if (isEdit) "حفظ" else "ابدأ", fontSize = 16.sp) }
        if (isEdit) TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
    }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) cs.primary else cs.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 14.sp, color = if (selected) cs.onPrimary else cs.onSurface, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun IconText(text: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, fontSize = 20.sp)
    }
}

@Composable
fun SettingsScreen(vm: MainVM, onBack: () -> Unit, onInterests: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconText("→", onBack)
            Spacer(Modifier.width(8.dp))
            Text("الإعدادات", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface)
                        .clickable(onClick = onInterests).padding(16.dp)
                ) { Text("تعديل الاهتمامات  ‹", fontWeight = FontWeight.SemiBold) }
            }
            item {
                Text("التنبيهات الدورية", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "إيقاف", 30 to "كل 30 دقيقة", 60 to "كل ساعة", 180 to "كل 3 ساعات").forEach { (m, label) ->
                        Pill(label, vm.alertMin == m) { vm.setAlert(m) }
                    }
                }
                Text(
                    "قد يؤخر أندرويد التنبيهات قليلاً لتوفير البطارية",
                    color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
            item {
                Text("عدد الأخبار في الصفحة", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "خبر واحد", 2 to "خبران", 3 to "3 أخبار").forEach { (n, label) ->
                        Pill(label, vm.perPage == n) { vm.changePerPage(n) }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("المصادر", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(onClick = { vm.testSources() }, enabled = !vm.testing, shape = RoundedCornerShape(12.dp)) {
                        Text(if (vm.testing) "جارٍ الفحص…" else "فحص المصادر")
                    }
                }
            }
            items(SOURCES.filter { it.category in vm.interests }) { s ->
                val k = s.key()
                val cat = CATEGORIES.firstOrNull { it.id == s.category }?.label ?: ""
                val h = vm.health[k]
                val status = when {
                    h == null -> ""
                    h > 0 -> "  ✓ $h خبر"
                    else -> "  ✗ لا يعمل"
                }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface).padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(s.name, fontWeight = FontWeight.SemiBold)
                        Text(cat + status, fontSize = 12.sp, color = if (h != null && h <= 0) Color(0xFFE5484D) else cs.onSurfaceVariant)
                    }
                    Switch(checked = k !in vm.disabled, onCheckedChange = { vm.toggle(s) })
                }
            }
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun Feed(vm: MainVM, onSettings: () -> Unit) {
    var filter by remember { mutableStateOf<String?>(null) }
    val list = remember(vm.articles, vm.interests, vm.disabled, filter) {
        vm.articles.filter {
            it.category in vm.interests && (filter == null || it.category == filter) &&
                (it.category + "|" + it.source) !in vm.disabled
        }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Pill("الكل", filter == null) { filter = null } }
                items(CATEGORIES.filter { it.id in vm.interests }) { c ->
                    Pill("${c.emoji} ${c.label}", filter == c.id) { filter = c.id }
                }
            }
            IconText("↻") { vm.refresh() }
            IconText("⚙", onSettings)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                list.isEmpty() && vm.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                list.isEmpty() -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (vm.failed) "تعذّر جلب الأخبار، تحقق من الاتصال" else "لا توجد أخبار بعد", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { vm.refresh() }) { Text("إعادة المحاولة") }
                }
                else -> key(filter, vm.perPage) {
                    val n = vm.perPage
                    val pages = remember(list, n) { list.chunked(n) }
                    val ps = rememberPagerState { pages.size }
                    VerticalPager(ps, Modifier.fillMaxSize()) { i ->
                        if (n == 1) NewsCard(pages[i][0], i, list.size, Modifier.fillMaxSize())
                        else NewsPage(pages[i], n, Modifier.fillMaxSize())
                    }
                }
            }
            if (vm.loading && list.isNotEmpty()) {
                LinearProgressIndicator(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(2.dp))
            }
        }
    }
}

fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "الآن"
        m < 60 -> "منذ $m د"
        m < 1440 -> "منذ ${m / 60} س"
        else -> "منذ ${m / 1440} يوم"
    }
}

@Composable
fun NewsCard(a: Article, index: Int, total: Int, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val cat = CATEGORIES.firstOrNull { it.id == a.category }
    Column(modifier.padding(horizontal = 22.dp).padding(top = 8.dp, bottom = 16.dp).navigationBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (cat != null) {
                Text(
                    "${cat.emoji} ${cat.label}", color = cs.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(cs.primary.copy(alpha = 0.14f))
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }
            Spacer(Modifier.weight(1f))
            Text("${index + 1} / $total", color = cs.onSurfaceVariant, fontSize = 12.sp)
        }
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(a.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("  •  ${ago(a.time)}", color = cs.onSurfaceVariant, fontSize = 14.sp)
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.weight(1f)) {
            Text(a.title, fontSize = 25.sp, lineHeight = 37.sp, fontWeight = FontWeight.Bold, maxLines = 6, overflow = TextOverflow.Ellipsis)
            if (a.summary.isNotBlank()) {
                Spacer(Modifier.height(16.dp))
                Text(a.summary, fontSize = 16.sp, lineHeight = 27.sp, color = cs.onSurfaceVariant, maxLines = 7, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.link))) } catch (_: Exception) {}
            },
            modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)
        ) { Text("فتح الخبر الأصلي  ↗", fontSize = 16.sp) }
    }
}

@Composable
fun NewsPage(items: List<Article>, n: Int, modifier: Modifier = Modifier) {
    Column(
        modifier.padding(horizontal = 14.dp).padding(top = 4.dp, bottom = 12.dp).navigationBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        repeat(n) { i ->
            if (i < items.size) CompactCard(items[i], n, Modifier.weight(1f).fillMaxWidth())
            else Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
fun CompactCard(a: Article, n: Int, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val cat = CATEGORIES.firstOrNull { it.id == a.category }
    val big = n == 2
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(cs.surface).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(a.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            Text("  •  ${ago(a.time)}", color = cs.onSurfaceVariant, fontSize = 12.5.sp)
            Spacer(Modifier.weight(1f))
            if (cat != null) Text(cat.emoji, fontSize = 15.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            a.title, fontSize = if (big) 21.sp else 18.sp, lineHeight = if (big) 30.sp else 26.sp,
            fontWeight = FontWeight.Bold, maxLines = if (big) 4 else 3, overflow = TextOverflow.Ellipsis
        )
        if (a.summary.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                a.summary, fontSize = if (big) 15.sp else 13.5.sp, lineHeight = if (big) 23.sp else 20.sp,
                color = cs.onSurfaceVariant, maxLines = if (big) 4 else 2, overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.weight(1f))
        Text(
            "فتح الخبر الأصلي ↗", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            modifier = Modifier.clip(RoundedCornerShape(10.dp))
                .clickable {
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.link))) } catch (_: Exception) {}
                }
                .padding(horizontal = 4.dp, vertical = 6.dp)
        )
    }
}
