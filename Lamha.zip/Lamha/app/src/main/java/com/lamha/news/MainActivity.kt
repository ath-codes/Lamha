package com.lamha.news

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handle(intent)
        setContent { LamhaApp(vm) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val l = i?.getStringExtra("link") ?: return
        i.removeExtra("link")
        vm.openLink(l)
    }

    override fun onStart() {
        super.onStart()
        vm.refreshIfStale()
    }

    override fun onStop() {
        super.onStop()
        vm.markClosed()
    }
}

class MainVM(private val app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    var interests by mutableStateOf(repo.interests)
    var onboarded by mutableStateOf(repo.onboarded)
    var articles by mutableStateOf<List<Article>>(emptyList()) // يُحمَّل من الكاش في الخلفية
    var loading by mutableStateOf(repo.onboarded) // true حتى يجهز الكاش فلا تظهر شاشة فارغة
    var failed by mutableStateOf(false)
    var alertMin by mutableStateOf(repo.alertMin)
    var disabled by mutableStateOf(repo.disabled)
    var perPage by mutableStateOf(repo.perPage)
    var health by mutableStateOf<Map<String, Health>>(emptyMap())
    var custom by mutableStateOf(repo.custom)               // مصادر أضافها المستخدم
    val allSources: List<Source> get() = SOURCES + custom
    var adding by mutableStateOf(false)
    var addMsg by mutableStateOf("")
    var sortMode by mutableStateOf(repo.sortMode)
    var testing by mutableStateOf(false)
    var focusLink by mutableStateOf<String?>(null)
    var newLinks by mutableStateOf<Set<String>>(emptySet()) // أخبار جديدة لم تُشاهد بعد (نقطة "جديد")
    var badgeOn by mutableStateOf(false)                    // إظهار شارة "N أخبار جديدة"
    var usd by mutableStateOf(repo.loadUsd())
    var retain by mutableStateOf(repo.retainDays)           // مدة بقاء الأخبار بالأيام
    var lastUpdate by mutableLongStateOf(repo.lastRefresh)  // وقت آخر تحديث ناجح
    var reading by mutableStateOf<ReadReq?>(null)          // الخبر المفتوح في وضع القراءة
    var viewing by mutableStateOf<StoryView?>(null)        // القصة المفتوحة في شاشة "الصورة الكاملة"

    init {
        val wasOnboarded = onboarded
        if (wasOnboarded) Alerts.schedule(app, alertMin)
        repo.hidden = emptySet() // ميزة المسح أُلغيت: يعود أي خبر كان ممسوحاً
        viewModelScope.launch {
            val cached = withContext(Dispatchers.IO) {
                cleanLegacyFiles()
                repo.loadCache()
            }
            if (articles.isEmpty()) articles = cached
            // ما نُشر بعد آخر خروج من التطبيق (ومنه ما جلبه العامل الخلفي) يُعتبر جديداً
            val lc = repo.lastClose
            if (lc > 0L) {
                val nl = cached.filter { it.time > lc }.map { it.link }
                if (nl.isNotEmpty()) {
                    newLinks = nl.toSet()
                    badgeOn = true
                }
            }
            if (wasOnboarded) {
                loading = false
                refreshUsd()
                if (articles.isEmpty() || System.currentTimeMillis() - repo.lastRefresh > 10 * 60_000L) refresh()
            }
        }
    }

    // يحذف ملفات إصدارات سابقة (الترجمات المخزنة ونماذج الترجمة التي نُزّلت)
    private fun cleanLegacyFiles() {
        try {
            app.filesDir.listFiles()?.filter {
                it.name.startsWith("translations") || it.name.startsWith("com.google.mlkit")
            }?.forEach { it.deleteRecursively() }
        } catch (_: Exception) {
        }
    }

    fun refreshIfStale() {
        lastUpdate = repo.lastRefresh // قد يكون العامل الخلفي حدّث
        if (!onboarded) return
        refreshUsd() // يتجاهل الطلب داخلياً إن مرّت أقل من ساعة
        if (System.currentTimeMillis() - repo.lastRefresh > 10 * 60_000L) refresh()
    }

    private fun refreshUsd() {
        viewModelScope.launch { repo.refreshUsd()?.let { usd = it } }
    }

    fun markClosed() {
        repo.lastClose = System.currentTimeMillis()
    }

    fun refresh() {
        if (loading) return
        viewModelScope.launch {
            loading = true
            val before = articles.map { it.link }.toHashSet()
            val prevRefresh = repo.lastRefresh
            val r = repo.refresh(interests)
            lastUpdate = repo.lastRefresh
            failed = r.none { it.category in interests }
            if (before.isNotEmpty()) {
                // جديد فعلاً: لم يكن في الكاش ونُشر بعد آخر تحديث (فلا تُحسب الأخبار القديمة التي ظهرت لأول مرة)
                val fresh = r.filter { it.link !in before && it.time > prevRefresh - 30 * 60_000L }.map { it.link }
                if (fresh.isNotEmpty()) {
                    newLinks = newLinks + fresh
                    badgeOn = true
                }
            }
            articles = r
            loading = false
        }
        refreshUsd()
    }

    // يفتح وضع القراءة. الروابط المرشحة: كل نسخ الخبر من المصادر المختلفة، عدا روابط Google News (لا تفتح مباشرة)
    fun openReader(a: Article, alts: List<Article>) {
        val urls = (listOf(a) + alts).map { it.link }.distinct().filter { !it.contains("news.google.com") }
        reading = ReadReq(a, urls)
    }

    fun markSeen(links: Collection<String>) {
        if (newLinks.isEmpty()) return
        val n = newLinks - links.toSet()
        if (n.size != newLinks.size) newLinks = n
    }

    fun save(s: Set<String>) {
        val first = !onboarded
        interests = s; repo.interests = s
        onboarded = true; repo.onboarded = true
        if (first) Alerts.schedule(app, alertMin)
        refresh()
    }

    fun setAlert(min: Int) {
        alertMin = min; repo.alertMin = min
        Alerts.schedule(app, min)
    }

    fun openLink(l: String) {
        viewModelScope.launch {
            val c = withContext(Dispatchers.IO) { repo.loadCache() } // قد يكون العامل الخلفي حدّث الكاش
            if (c.isNotEmpty()) articles = c
            focusLink = l
        }
    }

    fun changeRetain(n: Int) {
        retain = n; repo.retainDays = n
        val now = System.currentTimeMillis()
        articles = articles.filter { now - it.time < keepDays(it.category, n) * 24L * 3600_000L }
    }

    fun changePerPage(n: Int) {
        perPage = n; repo.perPage = n
    }

    fun changeSort(n: Int) {
        sortMode = n; repo.sortMode = n
    }

    fun toggle(s: Source) {
        val k = s.key()
        disabled = if (k in disabled) disabled - k else disabled + k
        repo.disabled = disabled
    }

    fun testSources() {
        if (testing) return
        viewModelScope.launch {
            testing = true
            health = repo.test(allSources.filter { it.category in interests })
            testing = false
        }
    }

    // يفحص رابط الخلاصة، ولا يضيفه إلا إن أعطى أخباراً. يفعّل تصنيفه إن كان مغلقاً ثم يحدّث
    fun addSource(url: String, nameIn: String, cat: String, onAdded: () -> Unit) {
        if (adding) return
        val u = url.trim()
        if (!u.startsWith("http://") && !u.startsWith("https://")) { addMsg = "الرابط يجب أن يبدأ بـ https://"; return }
        val name = nameIn.trim().ifEmpty { android.net.Uri.parse(u).host?.removePrefix("www.") ?: u }
        if (allSources.any { it.key() == "$cat|$name" }) { addMsg = "يوجد مصدر بهذا الاسم في هذا التصنيف، غيّر الاسم"; return }
        if (allSources.any { it.url == u && it.category == cat }) { addMsg = "هذا الرابط مضاف مسبقاً"; return }
        val src = Source(name, u, cat, focused = true)
        viewModelScope.launch {
            adding = true
            addMsg = "جارٍ الفحص…"
            val h = repo.test(listOf(src))[src.key()]
            if (h != null && h.count > 0) {
                custom = custom + src
                repo.custom = custom
                if (cat !in interests) { interests = interests + cat; repo.interests = interests }
                addMsg = "أُضيف «$name»: ${h.count} خبر"
                onAdded()
                refresh()
            } else {
                addMsg = "لم يُضف: لا يعطي أخباراً" + if (!h?.notes.isNullOrBlank()) " (${h?.notes})" else ""
            }
            adding = false
        }
    }

    fun removeSource(s: Source) {
        custom = custom.filter { it.key() != s.key() }
        repo.custom = custom
        disabled = disabled - s.key()
        repo.disabled = disabled
        articles = articles.filter { !(it.category == s.category && it.source == s.name) }
        health = health - s.key()
    }
}

// يبحث عن خطوط .ttf داخل assets/fonts؛ إن لم يجدها يستخدم خط النظام
fun loadFont(ctx: Context): FontFamily {
    return try {
        val am = ctx.assets
        val files = (am.list("fonts") ?: emptyArray()).filter { it.endsWith(".ttf", true) || it.endsWith(".otf", true) }
        if (files.isEmpty()) return FontFamily.Default
        val reg = files.firstOrNull { it.contains("regular", true) } ?: files.first()
        val bold = files.firstOrNull { it.contains("bold", true) } ?: reg
        FontFamily(
            Font("fonts/$reg", am, FontWeight.Normal),
            Font("fonts/$bold", am, FontWeight.Bold)
        )
    } catch (e: Exception) {
        FontFamily.Default
    }
}

fun Typography.withFont(f: FontFamily) = Typography(
    displayLarge = displayLarge.copy(fontFamily = f), displayMedium = displayMedium.copy(fontFamily = f),
    displaySmall = displaySmall.copy(fontFamily = f), headlineLarge = headlineLarge.copy(fontFamily = f),
    headlineMedium = headlineMedium.copy(fontFamily = f), headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f), titleMedium = titleMedium.copy(fontFamily = f),
    titleSmall = titleSmall.copy(fontFamily = f), bodyLarge = bodyLarge.copy(fontFamily = f),
    bodyMedium = bodyMedium.copy(fontFamily = f), bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f), labelMedium = labelMedium.copy(fontFamily = f),
    labelSmall = labelSmall.copy(fontFamily = f)
)

@Composable
fun LamhaTheme(dark: Boolean, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val family = remember { loadFont(ctx) }
    val cs = if (dark) darkColorScheme(
        primary = Color(0xFF34D3A5), onPrimary = Color(0xFF04271D),
        background = Color(0xFF0D0F12), surface = Color(0xFF16191E),
        onBackground = Color(0xFFECEFF1), onSurface = Color(0xFFECEFF1),
        surfaceVariant = Color(0xFF1F242B), onSurfaceVariant = Color(0xFF9AA4AF)
    ) else lightColorScheme(
        primary = Color(0xFF0E7C66), onPrimary = Color.White,
        background = Color(0xFFF6F7F4), surface = Color.White,
        onBackground = Color(0xFF111418), onSurface = Color(0xFF111418),
        surfaceVariant = Color(0xFFE6E9E4), onSurfaceVariant = Color(0xFF5B6570)
    )
    MaterialTheme(colorScheme = cs, typography = Typography().withFont(family), content = content)
}

@Composable
fun LamhaApp(vm: MainVM = viewModel()) {
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(vm.onboarded) {
        if (vm.onboarded && Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LamhaTheme(isSystemInDarkTheme()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                var screen by remember { mutableIntStateOf(0) } // 0 أخبار، 1 إعدادات، 2 اهتمامات
                Box(Modifier.fillMaxSize()) {
                when {
                    !vm.onboarded -> Onboarding(vm.interests, false, { vm.save(it) }, {})
                    screen == 2 -> {
                        BackHandler { screen = 1 }
                        Onboarding(vm.interests, true, { vm.save(it); screen = 1 }, { screen = 1 })
                    }
                    screen == 1 -> SettingsScreen(vm, { screen = 0 }, { screen = 2 })
                    else -> Feed(vm, { screen = 1 })
                }
                // وضع القراءة يظهر فوق الشاشة الحالية، فيبقى موضعك في القائمة كما هو عند الرجوع
                val sv = vm.viewing
                if (sv != null) key(sv.story.lead.link) { StoryScreen(vm, sv) { vm.viewing = null } }
                val rq = vm.reading
                if (rq != null) key(rq.article.link) { ReaderScreen(rq) { vm.reading = null } }
                }
            }
        }
    }
}

@Composable
fun Onboarding(initial: Set<String>, isEdit: Boolean, onDone: (Set<String>) -> Unit, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var sel by remember { mutableStateOf(initial) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp)) {
        Text(if (isEdit) "اهتماماتك" else "ما الذي يهمّك؟", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "اختر موضوعاً واحداً على الأقل، ويمكنك التغيير لاحقاً",
            color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(Modifier.height(24.dp))
        LazyVerticalGrid(
            GridCells.Fixed(2), Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(CATEGORIES) { c ->
                val on = c.id in sel
                val shape = RoundedCornerShape(20.dp)
                Box(
                    Modifier.height(110.dp).clip(shape)
                        .background(if (on) cs.primary.copy(alpha = 0.16f) else cs.surface)
                        .border(2.dp, if (on) cs.primary else Color.Transparent, shape)
                        .clickable { sel = if (on) sel - c.id else sel + c.id },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(c.emoji, fontSize = 32.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(c.label, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onDone(sel) }, enabled = sel.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)
        ) { Text(if (isEdit) "حفظ" else "ابدأ", fontSize = 16.sp) }
        if (isEdit) TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
    }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) cs.primary else cs.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 14.sp, color = if (selected) cs.onPrimary else cs.onSurface, fontWeight = FontWeight.Medium)
    }
}

/** تبويب خفيف: المحدد كبسولة ممتلئة، وغير المحدد نص رمادي بلا خلفية */
@Composable
fun TabChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) cs.primary else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 6.dp)
    ) {
        Text(
            text, fontSize = 14.sp, maxLines = 1,
            color = if (selected) cs.onPrimary else cs.onSurfaceVariant,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
        )
    }
}

@Composable
fun IconText(text: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, fontSize = 20.sp)
    }
}

@Composable
fun SettingsScreen(vm: MainVM, onBack: () -> Unit, onInterests: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    BackHandler(onBack = onBack)
    // إحصائية فعلية: عدد أخبار كل مصدر المحفوظة الآن ونسبتها من الإجمالي
    val active = remember(vm.articles, vm.interests, vm.disabled) {
        vm.articles.filter { it.category in vm.interests && (it.category + "|" + it.source) !in vm.disabled }
    }
    val counts = remember(active) { active.groupingBy { it.category + "|" + it.source }.eachCount() }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconText("→", onBack)
            Spacer(Modifier.width(8.dp))
            Text("الإعدادات", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface)
                        .clickable(onClick = onInterests).padding(16.dp)
                ) { Text("تعديل الاهتمامات  ‹", fontWeight = FontWeight.SemiBold) }
            }
            item {
                Text("التنبيهات الدورية", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "إيقاف", 30 to "كل 30 دقيقة", 60 to "كل ساعة", 180 to "كل 3 ساعات").forEach { (m, label) ->
                        Pill(label, vm.alertMin == m) { vm.setAlert(m) }
                    }
                }
                Text(
                    "قد يؤخر أندرويد التنبيهات قليلاً لتوفير البطارية",
                    color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
            item {
                Text("حجم البطاقات", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "كبير", 2 to "متوسط", 3 to "مضغوط").forEach { (n, label) ->
                        Pill(label, vm.perPage == n) { vm.changePerPage(n) }
                    }
                }
            }
            item {
                Text("ترتيب الأخبار", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "الأحدث", 1 to "الأهم").forEach { (n, label) ->
                        Pill(label, vm.sortMode == n) { vm.changeSort(n) }
                    }
                }
                Text(
                    "الأهم: الخبر الذي غطّته مصادر أكثر يتقدم، مع مراعاة الحداثة",
                    color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
            item {
                Text("مدة بقاء الأخبار", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "يوم", 2 to "يومان", 3 to "3 أيام").forEach { (n, label) ->
                        Pill(label, vm.retain == n) { vm.changeRetain(n) }
                    }
                }
                Text(
                    "الأخبار الأقدم تُحذف تلقائياً (التحليلات تبقى 7 أيام دائماً)",
                    color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
            item {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("المصادر", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(onClick = { vm.testSources() }, enabled = !vm.testing, shape = RoundedCornerShape(12.dp)) {
                        Text(if (vm.testing) "جارٍ الفحص…" else "فحص المصادر")
                    }
                    if (vm.health.isNotEmpty() && !vm.testing) {
                        Spacer(Modifier.width(8.dp))
                        val ctxR = LocalContext.current
                        OutlinedButton(
                            onClick = { copyReport(ctxR, sourcesReport(vm.allSources, vm.health, vm.interests)) },
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("نسخ التقرير") }
                    }
                }
            }
            item {
                if (vm.health.isNotEmpty() && !vm.testing) {
                    val tested = vm.allSources.filter { it.category in vm.interests && vm.health[it.key()] != null }
                    val ok = tested.count { (vm.health[it.key()]?.count ?: 0) > 0 }
                    Text(
                        "يعمل $ok من ${tested.size} مصدراً" + if (ok < tested.size) "، وما تعطّل يظهر أدناه" else "",
                        color = cs.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                } else {
                    Text(
                        "اضغط «فحص المصادر» لمعرفة ما يعمل منها. تظهر هنا فقط المصادر المعطّلة أو التي تعطلت أو التي أضفتها أنت",
                        color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            item {
                var url by remember { mutableStateOf("") }
                var nm by remember { mutableStateOf("") }
                var cat by remember { mutableStateOf("analysis") }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface).padding(16.dp)) {
                    Text("إضافة مصدر", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        OutlinedTextField(
                            value = url, onValueChange = { url = it }, singleLine = true,
                            label = { Text("رابط الخلاصة (RSS)") }, modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = nm, onValueChange = { nm = it }, singleLine = true,
                        label = { Text("الاسم (اختياري)") }, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(CATEGORIES) { c -> Pill("${c.emoji} ${c.label}", cat == c.id) { cat = c.id } }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { vm.addSource(url, nm, cat) { url = ""; nm = "" } },
                        enabled = !vm.adding && url.isNotBlank(), shape = RoundedCornerShape(12.dp)
                    ) { Text(if (vm.adding) "جارٍ الفحص…" else "فحص وإضافة") }
                    if (vm.addMsg.isNotEmpty()) {
                        Text(vm.addMsg, fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
            val customKeys = vm.custom.map { it.key() }.toHashSet()
            items(vm.allSources.filter { s ->
                val k = s.key()
                s.category in vm.interests && ((vm.health[k]?.let { it.count <= 0 } == true) || k in vm.disabled || k in customKeys)
            }) { s ->
                val k = s.key()
                val cat = CATEGORIES.firstOrNull { it.id == s.category }?.label ?: ""
                val h = vm.health[k]
                val status = when {
                    h == null -> ""
                    h.count > 0 -> "  ✓ ${h.count} خبر" + if (h.viaFallback) " (عبر البديل)" else ""
                    else -> "  ✗ لا يعمل"
                }
                val n = counts[k] ?: 0
                val stat = if (k in vm.disabled) "  •  معطّل" else "  •  في التطبيق: $n"
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface).padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(s.name, fontWeight = FontWeight.SemiBold)
                        Text(cat + (if (k in customKeys) "  •  أضفته أنت" else "") + status + stat, fontSize = 12.sp, color = if (h != null && h.count <= 0) Color(0xFFE5484D) else cs.onSurfaceVariant)
                        if (h != null && h.count <= 0 && h.notes.isNotBlank()) {
                            Text(h.notes, fontSize = 11.sp, color = Color(0xFFE5484D))
                        }
                    }
                    if (k in customKeys) {
                        TextButton(onClick = { vm.removeSource(s) }) { Text("حذف", color = Color(0xFFE5484D)) }
                    }
                    Switch(checked = k !in vm.disabled, onCheckedChange = { vm.toggle(s) })
                }
            }
            item {
                val ctxF = LocalContext.current
                val fontFile = remember {
                    try {
                        ctxF.assets.list("fonts")?.firstOrNull { it.endsWith(".ttf", true) || it.endsWith(".otf", true) }
                    } catch (_: Exception) { null }
                }
                Text(
                    "الخط: " + (fontFile?.substringBeforeLast('.')?.substringBefore('-') ?: "خط النظام (لم يُعثر على ملفات الخط)"),
                    color = cs.onSurfaceVariant, fontSize = 11.sp,
                    modifier = Modifier.padding(top = 10.dp).fillMaxWidth(), textAlign = TextAlign.Center
                )
                Text(
                    "سعر الدولار: Rates By Exchange Rate API",
                    color = cs.onSurfaceVariant, fontSize = 11.sp,
                    modifier = Modifier.padding(top = 4.dp).fillMaxWidth(), textAlign = TextAlign.Center
                )
            }
        }
    }
}

/** شريط العملات في سطر واحد: رمز العملة بالإنجليزية ثم السعر بالجنيه، موزّعان بالتساوي، وفي الطرف وقت آخر تحديث. السهم يُخفى عند عدم التغيّر */
@Composable
fun UsdBar(u: Usd, updated: Long) {
    val cs = MaterialTheme.colorScheme
    @Composable
    fun Rate(code: String, rate: Double, prev: Double) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(code, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1)
            Spacer(Modifier.width(5.dp))
            Text(String.format(Locale.US, "%.2f", rate) + " ج", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = cs.primary, maxLines = 1)
            if (prev > 0.0) {
                val pct = (rate - prev) / prev * 100.0
                if (abs(pct) >= 0.005) {
                    Spacer(Modifier.width(4.dp))
                    Text((if (pct > 0) "▲" else "▼") + String.format(Locale.US, "%.2f", abs(pct)) + "%", fontSize = 10.sp, color = cs.onSurfaceVariant, maxLines = 1)
                }
            }
        }
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(cs.primary.copy(alpha = 0.10f))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Rate("USD", u.rate, u.prev) }
        if (u.qar > 0.0) {
            Box(Modifier.width(1.dp).height(16.dp).background(cs.onSurfaceVariant.copy(alpha = 0.35f)))
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Rate("QAR", u.qar, u.qarPrev) }
        }
        Text(ago(if (updated > 0L) updated else u.fetched), color = cs.onSurfaceVariant, fontSize = 10.sp, maxLines = 1, modifier = Modifier.padding(start = 6.dp))
    }
}

@Composable
fun Feed(vm: MainVM, onSettings: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var filter by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) } // 0 الكل، 1 مصر، 2 العالم
    val list = remember(vm.articles, vm.interests, vm.disabled, filter, tab, vm.sortMode) {
        val base = vm.articles.filter {
            it.category in vm.interests &&
                (if (filter == null) it.category != "analysis" else it.category == filter) &&
                (it.category + "|" + it.source) !in vm.disabled && Quality.keep(it)
        }
        // التحليلات (أسبوعية) تُرتَّب بالأحدث دائماً، ولا تظهر في "الكل" بل في تبويبها فقط
        Stories.order(
            Stories.build(base).filter { st -> tab == 0 || (tab == 1) == st.egypt },
            vm.sortMode == 1 && filter != "analysis"
        )
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        // صف واحد: النطاق (الكل/مصر/العالم) ثم فاصل ثم التصنيفات. النطاق والتصنيف يعملان معاً (مثلاً مصر + اقتصاد)
        // التحديث بالسحب للأسفل (بدل الزر) فيتسع الصف للتصنيفات
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            val rowState = rememberLazyListState()
            Box(Modifier.weight(1f)) {
                LazyRow(state = rowState, horizontalArrangement = Arrangement.spacedBy(0.dp), verticalAlignment = Alignment.CenterVertically) {
                    item { TabChip("الكل", filter == null && tab == 0) { filter = null; tab = 0 } }
                    item { TabChip("مصر", tab == 1) { tab = if (tab == 1) 0 else 1 } }
                    item { TabChip("العالم", tab == 2) { tab = if (tab == 2) 0 else 2 } }
                    item {
                        Box(Modifier.padding(horizontal = 4.dp).width(1.dp).height(18.dp).background(cs.onSurfaceVariant.copy(alpha = 0.35f)))
                    }
                    items(CATEGORIES.filter { it.id in vm.interests }) { c ->
                        TabChip(c.label, filter == c.id) { filter = if (filter == c.id) null else c.id }
                    }
                }
                // تدرّج على الطرف يوحي بوجود تبويبات أخرى عند التمرير
                if (rowState.canScrollForward) {
                    Box(
                        Modifier.align(Alignment.CenterEnd).width(28.dp).height(36.dp)
                            .background(Brush.horizontalGradient(listOf(cs.background, Color.Transparent)))
                    )
                }
            }
            IconText("⚙", onSettings)
        }
        // سحب للتحديث بدون مكتبات إضافية: السحب للأسفل وأنت في أعلى القائمة ثم الإفلات بعد تجاوز العتبة
        val density = LocalDensity.current
        val thresholdPx = with(density) { 72.dp.toPx() }
        var pullPx by remember { mutableFloatStateOf(0f) }
        val pullConn = remember {
            object : NestedScrollConnection {
                override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                    if (source == NestedScrollSource.Drag && pullPx > 0f && available.y < 0f) {
                        val c = maxOf(available.y, -pullPx)
                        pullPx += c
                        return Offset(0f, c)
                    }
                    return Offset.Zero
                }
                override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                    if (source == NestedScrollSource.Drag && available.y > 0f && !vm.loading) {
                        pullPx = (pullPx + available.y * 0.5f).coerceAtMost(thresholdPx * 1.4f)
                        return Offset(0f, available.y)
                    }
                    return Offset.Zero
                }
                override suspend fun onPreFling(available: androidx.compose.ui.unit.Velocity): androidx.compose.ui.unit.Velocity {
                    if (pullPx >= thresholdPx) vm.refresh()
                    pullPx = 0f
                    return androidx.compose.ui.unit.Velocity.Zero
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().nestedScroll(pullConn)) {
            when {
                list.isEmpty() && vm.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                list.isEmpty() -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (vm.failed) "تعذّر جلب الأخبار، تحقق من الاتصال" else if (tab != 0) "لا توجد أخبار في هذا التبويب بعد" else "لا توجد أخبار بعد", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { vm.refresh() }) { Text("إعادة المحاولة") }
                }
                else -> key(filter, tab) {
                    val ls = rememberLazyListState()
                    val scope = rememberCoroutineScope()
                    LazyColumn(
                        state = ls,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // عنصر علوي ثابت: يجعل الأخبار الجديدة تظهر مباشرة إن كنت في الأعلى، وتبقى مكانك إن كنت تقرأ في الأسفل
                        item(key = "top") {
                            val u = vm.usd
                            if (u != null) UsdBar(u, vm.lastUpdate) else Spacer(Modifier.height(0.dp))
                        }
                        items(list, key = { it.lead.link }) { st ->
                            val full: (() -> Unit)? =
                                if (st.sources.size > 1) ({ vm.viewing = StoryView(st, Stories.related(st, list)) }) else null
                            NewsItem(
                                st.lead, vm.perPage, st.sources,
                                isNew = st.items.any { it.link in vm.newLinks },
                                onRead = { vm.openReader(st.lead, st.items) },
                                breaking = st.breaking,
                                onFull = full
                            )
                        }
                        item { Spacer(Modifier.navigationBarsPadding()) }
                    }
                    // الخبر الذي بقي ظاهراً ثانيتين يُعتبر مقروءاً فتختفي نقطة "جديد"
                    LaunchedEffect(ls, list) {
                        snapshotFlow { ls.layoutInfo.visibleItemsInfo.filter { it.offset >= 0 }.map { it.key } }
                            .collectLatest { keys ->
                                delay(2000)
                                val vis: Set<Any> = keys.toHashSet()
                                val seen = list.filter { it.lead.link in vis }.flatMap { st -> st.items.map { it.link } }
                                if (seen.isNotEmpty()) vm.markSeen(seen)
                            }
                    }
                    LaunchedEffect(vm.focusLink, list) {
                        val l = vm.focusLink
                        if (l != null) {
                            val idx = list.indexOfFirst { st -> st.items.any { it.link == l } }
                            if (idx >= 0) {
                                ls.scrollToItem(idx + 1) // +1 للعنصر العلوي
                                vm.focusLink = null
                            } else if (filter != null || tab != 0) { filter = null; tab = 0 }
                            else vm.focusLink = null
                        }
                    }
                    // زر عائم للعودة للأعلى عند التمرير الطويل
                    val showTop by remember { derivedStateOf { ls.firstVisibleItemIndex > 6 } }
                    if (showTop) {
                        Box(
                            Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(16.dp).size(46.dp)
                                .clip(CircleShape).background(cs.primary)
                                .clickable { scope.launch { ls.animateScrollToItem(0) } },
                            contentAlignment = Alignment.Center
                        ) { Text("↑", color = cs.onPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                    }
                    // نعدّ فقط الأخبار الجديدة التي فوق موضعك الحالي، فيطابق الرقم ما ستجده عند الصعود
                    val aboveNew by remember(list) {
                        derivedStateOf {
                            val f = ls.firstVisibleItemIndex // 0 = العنصر العلوي (الدولار)
                            // البطاقة الظاهر جزؤها السفلي فقط (رأسها مع علامة "جديد" خارج الشاشة) تُحسب فوق موضعك
                            val n = (f - 1 + (if (ls.firstVisibleItemScrollOffset > 0) 1 else 0)).coerceAtLeast(0)
                            list.take(n).count { st -> st.items.any { it.link in vm.newLinks } }
                        }
                    }
                    if (vm.badgeOn && aboveNew > 0) {
                        Box(
                            Modifier.align(Alignment.TopCenter).padding(top = 8.dp)
                                .clip(RoundedCornerShape(50)).background(cs.primary)
                                .clickable {
                                    vm.badgeOn = false
                                    scope.launch { ls.animateScrollToItem(0) }
                                }
                                .padding(horizontal = 16.dp, vertical = 9.dp)
                        ) {
                            Text(aboveNew.toString(), color = cs.onPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
            if (vm.loading && list.isNotEmpty()) {
                LinearProgressIndicator(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(2.dp))
            }
            if (pullPx > 0f) {
                val progress = (pullPx / thresholdPx).coerceIn(0f, 1f)
                Box(
                    Modifier.align(Alignment.TopCenter)
                        .offset { IntOffset(0, (pullPx - 44.dp.toPx()).roundToInt()) }
                        .size(36.dp).clip(CircleShape).background(cs.surface),
                    contentAlignment = Alignment.Center
                ) {
                    Text("↻", fontSize = 20.sp, color = if (progress >= 1f) cs.primary else cs.onSurfaceVariant, modifier = Modifier.rotate(progress * 270f))
                }
            }
        }
    }
}

fun agoShort(t: Long, now: Long): String {
    val m = ((now - t) / 60000).coerceAtLeast(0)
    return when {
        m < 1 -> "الآن"
        m < 60 -> "منذ $m د"
        m < 1440 -> "منذ ${m / 60} س"
        else -> "منذ ${m / 1440} يوم"
    }
}

/** زر التحديث، وتحته وقت آخر تحديث ناجح (يتجدد كل نصف دقيقة) */
@Composable
fun RefreshButton(last: Long, loading: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            tick = System.currentTimeMillis()
        }
    }
    val label = when {
        loading -> "…"
        last <= 0L -> ""
        else -> agoShort(last, tick)
    }
    Column(
        Modifier.width(54.dp).height(44.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("↻", fontSize = 19.sp)
        if (label.isNotEmpty()) Text(label, fontSize = 9.sp, color = cs.onSurfaceVariant, maxLines = 1)
    }
}

/** وضع القراءة: نص الخبر فقط. إن تعذّر استخراج النص تُفتح الصفحة الأصلية في المتصفح تلقائياً */
@Composable
fun ReaderScreen(req: ReadReq, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    BackHandler(onBack = onClose)
    val a = req.article
    var blocks by remember { mutableStateOf<List<Block>?>(null) }
    LaunchedEffect(a.link) {
        var got: List<Block>? = null
        for (u in req.urls) {
            got = Reader.load(u, a.title)
            if (got != null) break
        }
        if (got != null) {
            blocks = got
        } else {
            Toast.makeText(ctx, "تعذّر وضع القراءة، فُتحت الصفحة الأصلية", Toast.LENGTH_SHORT).show()
            try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.link))) } catch (_: Exception) {}
            onClose()
        }
    }
    Surface(Modifier.fillMaxSize(), color = cs.background) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconText("→", onClose)
                Spacer(Modifier.weight(1f))
                Text(
                    "الصفحة الأصلية ↗", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp))
                        .clickable { try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.link))) } catch (_: Exception) {} }
                        .padding(horizontal = 8.dp, vertical = 8.dp)
                )
            }
            val b = blocks
            if (b == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Column {
                            Row {
                                Text(a.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("  •  ${ago(a.time)}", color = cs.onSurfaceVariant, fontSize = 13.sp)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(a.title, fontSize = 24.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    items(b) { blk ->
                        if (blk.heading) Text(blk.text, fontSize = 19.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold)
                        else Text(blk.text, fontSize = 17.sp, lineHeight = 30.sp)
                    }
                }
            }
        }
    }
}

fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "الآن"
        m < 60 -> "منذ $m د"
        m < 1440 -> "منذ ${m / 60} س"
        else -> "منذ ${m / 1440} يوم"
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NewsItem(
    a: Article, size: Int, sources: List<String> = emptyList(),
    isNew: Boolean = false, onRead: (() -> Unit)? = null,
    breaking: Boolean = false, onFull: (() -> Unit)? = null
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val tSize = when (size) { 1 -> 24.sp; 2 -> 20.sp; else -> 17.sp }
    val tLine = when (size) { 1 -> 34.sp; 2 -> 29.sp; else -> 25.sp }
    val tMax = when (size) { 1 -> 6; 2 -> 4; else -> 3 }
    val sSize = when (size) { 1 -> 16.sp; 2 -> 15.sp; else -> 13.5.sp }
    val sLine = when (size) { 1 -> 26.sp; 2 -> 22.sp; else -> 20.sp }
    val sMax = when (size) { 1 -> 8; 2 -> 4; else -> 2 }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surface)
            .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (isNew) {
                Text(
                    "جديد", color = cs.onPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                    modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(cs.primary)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
                Spacer(Modifier.width(6.dp))
            }
            if (breaking) {
                Text(
                    "عاجل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                    modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFFE5484D))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
                Spacer(Modifier.width(6.dp))
            }
            Text(a.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            Text("  •  ${ago(a.time)}", color = cs.onSurfaceVariant, fontSize = 12.5.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            a.title, fontSize = tSize, lineHeight = tLine, fontWeight = FontWeight.Bold,
            maxLines = tMax, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth()
        )
        if (a.summary.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                a.summary, fontSize = sSize, lineHeight = sLine, color = cs.onSurfaceVariant,
                maxLines = sMax, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "قراءة الخبر ↗", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
                    .background(cs.primary.copy(alpha = 0.16f))
                    .clickable {
                        if (onRead != null) onRead()
                        else try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.link))) } catch (_: Exception) {}
                    }
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            )
            if (onFull != null) {
                Spacer(Modifier.width(8.dp))
                Text(
                    "الصورة الكاملة · " + Stories.sourcesLabel(sources.size), color = cs.primary, fontWeight = FontWeight.Medium, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onFull() }
                        .padding(horizontal = 6.dp, vertical = 8.dp)
                )
            }
        }
    }
}


/** الصورة الكاملة: ما نشرته كل جهة عن الخبر مرتباً من الأقدم للأحدث (كيف تطوّر)، ثم أخبار ذات صلة كخلفية */
@Composable
fun StoryScreen(vm: MainVM, sv: StoryView, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    BackHandler(onBack = onClose)
    val st = sv.story
    val timeline = remember(st) { st.items.sortedBy { it.time } }
    Surface(Modifier.fillMaxSize(), color = cs.background) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconText("→", onClose)
                Spacer(Modifier.width(4.dp))
                Text("الصورة الكاملة", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Column {
                        Text(st.lead.title, fontSize = 22.sp, lineHeight = 33.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            Stories.coverText(st.sources.size) + "  •  أول ظهور " + ago(timeline.first().time) +
                                "  •  آخر تحديث " + ago(timeline.last().time),
                            color = cs.onSurfaceVariant, fontSize = 12.5.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Text("كيف تناولته المصادر", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
                items(timeline, key = { it.link }) { a ->
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface)
                            .clickable { vm.openReader(a, st.items) }.padding(14.dp)
                    ) {
                        Row {
                            Text(a.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            Text("  •  ${ago(a.time)}", color = cs.onSurfaceVariant, fontSize = 12.5.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(a.title, fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Bold)
                        if (a.summary.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                a.summary, fontSize = 13.5.sp, lineHeight = 20.sp, color = cs.onSurfaceVariant,
                                maxLines = 4, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                if (sv.related.isNotEmpty()) {
                    item {
                        Text(
                            "خلفية وأخبار ذات صلة", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                            modifier = Modifier.padding(top = 10.dp)
                        )
                    }
                    items(sv.related, key = { "r" + it.lead.link }) { r ->
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface)
                                .clickable { vm.openReader(r.lead, r.items) }.padding(14.dp)
                        ) {
                            Row {
                                Text(r.lead.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                                Text("  •  ${ago(r.lead.time)}", color = cs.onSurfaceVariant, fontSize = 12.5.sp)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(r.lead.title, fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}


/** تقرير فحص المصادر كنص قابل للنسخ (لإرساله للمطوّر): الحالة وسبب الفشل وعنوان خبر نموذجي لكل مصدر */
fun sourcesReport(all: List<Source>, health: Map<String, Health>, interests: Set<String>): String {
    val sb = StringBuilder("تقرير فحص المصادر (لمحة)\n")
    for (s in all.filter { it.category in interests }) {
        val h = health[s.key()] ?: continue
        val cat = CATEGORIES.firstOrNull { it.id == s.category }?.label ?: ""
        sb.append(if (h.count > 0) "✓ " else "✗ ").append(s.name).append(" [").append(cat).append("] ")
        if (h.count > 0) sb.append(h.count).append(" خبر").append(if (h.viaFallback) " (عبر البديل)" else "")
        else sb.append("لا يعمل")
        if (h.notes.isNotBlank()) sb.append(" | ").append(h.notes)
        if (h.sample.isNotBlank()) sb.append(" | مثال: ").append(h.sample.take(70))
        sb.append('\n')
    }
    return sb.toString()
}

fun copyReport(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("lamha", text))
    Toast.makeText(ctx, "نُسخ التقرير، الصقه في المحادثة", Toast.LENGTH_SHORT).show()
}
