package com.lamha.news

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.snapshots.SnapshotStateMap

class MainActivity : ComponentActivity() {
    private val vm: MainVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handle(intent)
        setContent { LamhaApp(vm) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        val l = i?.getStringExtra("link") ?: return
        i.removeExtra("link")
        vm.openLink(l)
    }

    override fun onStart() {
        super.onStart()
        vm.refreshIfStale()
    }
}

class MainVM(private val app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    var interests by mutableStateOf(repo.interests)
    var onboarded by mutableStateOf(repo.onboarded)
    var articles by mutableStateOf<List<Article>>(emptyList()) // يُحمَّل من الكاش في الخلفية
    var loading by mutableStateOf(repo.onboarded) // true حتى يجهز الكاش فلا تظهر شاشة فارغة
    var failed by mutableStateOf(false)
    var alertMin by mutableStateOf(repo.alertMin)
    var disabled by mutableStateOf(repo.disabled)
    var perPage by mutableStateOf(repo.perPage)
    var health by mutableStateOf<Map<String, Int>>(emptyMap())
    var testing by mutableStateOf(false)
    var foreignOn by mutableStateOf(repo.foreignOn)
    var alertForeign by mutableStateOf(repo.alertForeign)
    var focusLink by mutableStateOf<String?>(null)
    var deeplKey by mutableStateOf(repo.deeplKey)
    var deeplMsg by mutableStateOf("")
    var transStatus by mutableStateOf(0) // 0 متوقف، 1 تنزيل، 2 جاهز، 3 فشل
    val translations: SnapshotStateMap<String, Pair<String, String>> = mutableStateMapOf()
    private val store = TransStore(app)
    private val pending = HashSet<String>()
    private var saveJob: Job? = null

    init {
        if (foreignOn) prepareModel()
        val wasOnboarded = onboarded
        if (wasOnboarded) Alerts.schedule(app, alertMin)
        viewModelScope.launch {
            val (cached, saved) = withContext(Dispatchers.IO) { repo.loadCache() to store.load() }
            translations.putAll(saved)
            if (articles.isEmpty()) articles = cached
            if (wasOnboarded) {
                loading = false
                if (articles.isEmpty() || System.currentTimeMillis() - repo.lastRefresh > 10 * 60_000L) refresh()
            }
        }
    }

    // حفظ مؤجل على خيط الإدخال والإخراج: دفعة واحدة بعد انتهاء ترجمة الأخبار الظاهرة
    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(1500)
            val keep = articles.map { it.link }.toHashSet()
            val snapshot = translations.filterKeys { it in keep }
            withContext(Dispatchers.IO) { store.save(snapshot) }
        }
    }

    fun refreshIfStale() {
        if (onboarded && System.currentTimeMillis() - repo.lastRefresh > 10 * 60_000L) refresh()
    }

    fun refresh() {
        if (loading) return
        viewModelScope.launch {
            loading = true
            val r = repo.refresh(interests)
            failed = r.none { it.category in interests }
            articles = r
            loading = false
        }
    }

    fun save(s: Set<String>) {
        val first = !onboarded
        interests = s; repo.interests = s
        onboarded = true; repo.onboarded = true
        if (first) Alerts.schedule(app, alertMin)
        refresh()
    }

    fun setAlert(min: Int) {
        alertMin = min; repo.alertMin = min
        Alerts.schedule(app, min)
    }

    fun setForeign(on: Boolean) {
        foreignOn = on; repo.foreignOn = on
        if (on) {
            prepareModel(); refresh()
        } else transStatus = 0
    }

    fun prepareModel() {
        if (transStatus == 1) return
        viewModelScope.launch {
            transStatus = 1
            transStatus = if (Translator.ensureModel()) 2 else 3
        }
    }

    fun translateIfNeeded(items: List<Article>) {
        if (!foreignOn || (transStatus != 2 && deeplKey.isBlank())) return
        for (a in items) {
            if (a.lang != "en" || a.link in translations || !pending.add(a.link)) continue
            viewModelScope.launch {
                try {
                    translations[a.link] = Translator.translateArticle(a.title, a.summary, deeplKey, transStatus == 2)
                    scheduleSave()
                } catch (_: Exception) {
                } finally {
                    pending.remove(a.link)
                }
            }
        }
    }

    fun saveDeeplKey(k: String) {
        deeplKey = k.trim(); repo.deeplKey = deeplKey
        translations.clear() // لإعادة الترجمة بالمحرك الجديد
        saveJob?.cancel()
        viewModelScope.launch(Dispatchers.IO) { store.save(emptyMap()) }
        deeplMsg = ""
    }

    fun testDeepl() {
        if (deeplKey.isBlank()) return
        viewModelScope.launch {
            deeplMsg = "جارٍ الاختبار…"
            deeplMsg = try {
                val r = Translator.deepl(deeplKey, listOf("Hello, this is a test."))
                "✓ المفتاح يعمل: " + r[0]
            } catch (e: Translator.DeeplException) {
                when (e.code) {
                    403 -> "✗ المفتاح غير صحيح"
                    456 -> "✗ انتهت الحصة الشهرية (ستُستخدم الترجمة المحلية)"
                    else -> "✗ خطأ ${e.code}"
                }
            } catch (e: Exception) {
                "✗ تعذّر الاتصال"
            }
        }
    }

    fun openLink(l: String) {
        viewModelScope.launch {
            val c = withContext(Dispatchers.IO) { repo.loadCache() } // قد يكون العامل الخلفي حدّث الكاش
            if (c.isNotEmpty()) articles = c
            focusLink = l
        }
    }

    fun changeAlertForeign(on: Boolean) {
        alertForeign = on; repo.alertForeign = on
    }

    fun changePerPage(n: Int) {
        perPage = n; repo.perPage = n
    }

    fun toggle(s: Source) {
        val k = s.key()
        disabled = if (k in disabled) disabled - k else disabled + k
        repo.disabled = disabled
    }

    fun testSources() {
        if (testing) return
        viewModelScope.launch {
            testing = true
            health = repo.test(SOURCES.filter { it.category in interests && (it.lang == "ar" || foreignOn) })
            testing = false
        }
    }
}

// يبحث عن خطوط .ttf داخل assets/fonts؛ إن لم يجدها يستخدم خط النظام
fun loadFont(ctx: Context): FontFamily {
    return try {
        val am = ctx.assets
        val files = (am.list("fonts") ?: emptyArray()).filter { it.endsWith(".ttf", true) || it.endsWith(".otf", true) }
        if (files.isEmpty()) return FontFamily.Default
        val reg = files.firstOrNull { it.contains("regular", true) } ?: files.first()
        val bold = files.firstOrNull { it.contains("bold", true) } ?: reg
        FontFamily(
            Font("fonts/$reg", am, FontWeight.Normal),
            Font("fonts/$bold", am, FontWeight.Bold)
        )
    } catch (e: Exception) {
        FontFamily.Default
    }
}

fun Typography.withFont(f: FontFamily) = Typography(
    displayLarge = displayLarge.copy(fontFamily = f), displayMedium = displayMedium.copy(fontFamily = f),
    displaySmall = displaySmall.copy(fontFamily = f), headlineLarge = headlineLarge.copy(fontFamily = f),
    headlineMedium = headlineMedium.copy(fontFamily = f), headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f), titleMedium = titleMedium.copy(fontFamily = f),
    titleSmall = titleSmall.copy(fontFamily = f), bodyLarge = bodyLarge.copy(fontFamily = f),
    bodyMedium = bodyMedium.copy(fontFamily = f), bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f), labelMedium = labelMedium.copy(fontFamily = f),
    labelSmall = labelSmall.copy(fontFamily = f)
)

@Composable
fun LamhaTheme(dark: Boolean, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val family = remember { loadFont(ctx) }
    val cs = if (dark) darkColorScheme(
        primary = Color(0xFF34D3A5), onPrimary = Color(0xFF04271D),
        background = Color(0xFF0D0F12), surface = Color(0xFF16191E),
        onBackground = Color(0xFFECEFF1), onSurface = Color(0xFFECEFF1),
        surfaceVariant = Color(0xFF1F242B), onSurfaceVariant = Color(0xFF9AA4AF)
    ) else lightColorScheme(
        primary = Color(0xFF0E7C66), onPrimary = Color.White,
        background = Color(0xFFF6F7F4), surface = Color.White,
        onBackground = Color(0xFF111418), onSurface = Color(0xFF111418),
        surfaceVariant = Color(0xFFE6E9E4), onSurfaceVariant = Color(0xFF5B6570)
    )
    MaterialTheme(colorScheme = cs, typography = Typography().withFont(family), content = content)
}

@Composable
fun LamhaApp(vm: MainVM = viewModel()) {
    val ctx = LocalContext.current
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(vm.onboarded) {
        if (vm.onboarded && Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LamhaTheme(isSystemInDarkTheme()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                var screen by remember { mutableIntStateOf(0) } // 0 أخبار، 1 إعدادات، 2 اهتمامات
                when {
                    !vm.onboarded -> Onboarding(vm.interests, false, { vm.save(it) }, {})
                    screen == 2 -> {
                        BackHandler { screen = 1 }
                        Onboarding(vm.interests, true, { vm.save(it); screen = 1 }, { screen = 1 })
                    }
                    screen == 1 -> SettingsScreen(vm, { screen = 0 }, { screen = 2 })
                    else -> Feed(vm) { screen = 1 }
                }
            }
        }
    }
}

@Composable
fun Onboarding(initial: Set<String>, isEdit: Boolean, onDone: (Set<String>) -> Unit, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var sel by remember { mutableStateOf(initial) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp)) {
        Text(if (isEdit) "اهتماماتك" else "ما الذي يهمّك؟", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "اختر موضوعاً واحداً على الأقل، ويمكنك التغيير لاحقاً",
            color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(Modifier.height(24.dp))
        LazyVerticalGrid(
            GridCells.Fixed(2), Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(CATEGORIES) { c ->
                val on = c.id in sel
                val shape = RoundedCornerShape(20.dp)
                Box(
                    Modifier.height(110.dp).clip(shape)
                        .background(if (on) cs.primary.copy(alpha = 0.16f) else cs.surface)
                        .border(2.dp, if (on) cs.primary else Color.Transparent, shape)
                        .clickable { sel = if (on) sel - c.id else sel + c.id },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(c.emoji, fontSize = 32.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(c.label, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onDone(sel) }, enabled = sel.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)
        ) { Text(if (isEdit) "حفظ" else "ابدأ", fontSize = 16.sp) }
        if (isEdit) TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
    }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) cs.primary else cs.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 14.sp, color = if (selected) cs.onPrimary else cs.onSurface, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun IconText(text: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, fontSize = 20.sp)
    }
}

@Composable
fun SettingsScreen(vm: MainVM, onBack: () -> Unit, onInterests: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconText("→", onBack)
            Spacer(Modifier.width(8.dp))
            Text("الإعدادات", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface)
                        .clickable(onClick = onInterests).padding(16.dp)
                ) { Text("تعديل الاهتمامات  ‹", fontWeight = FontWeight.SemiBold) }
            }
            item {
                Text("التنبيهات الدورية", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "إيقاف", 30 to "كل 30 دقيقة", 60 to "كل ساعة", 180 to "كل 3 ساعات").forEach { (m, label) ->
                        Pill(label, vm.alertMin == m) { vm.setAlert(m) }
                    }
                }
                Text(
                    "قد يؤخر أندرويد التنبيهات قليلاً لتوفير البطارية",
                    color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
            item {
                Text("حجم البطاقات", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "كبير", 2 to "متوسط", 3 to "مضغوط").forEach { (n, label) ->
                        Pill(label, vm.perPage == n) { vm.changePerPage(n) }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("الأخبار الأجنبية (مترجمة)", fontWeight = FontWeight.Bold)
                        Text(
                            when {
                                !vm.foreignOn -> "أخبار إنجليزية من وكالات ومواقع عالمية، تُترجم إلى العربية على جهازك"
                                vm.transStatus == 1 -> "جارٍ تنزيل نموذج الترجمة (حوالي 30 ميغابايت، يحتاج Wi-Fi)"
                                vm.transStatus == 2 -> "الترجمة جاهزة وتعمل بدون إنترنت"
                                else -> "تعذّر تنزيل نموذج الترجمة، اتصل بـ Wi-Fi ثم أعد المحاولة"
                            },
                            color = cs.onSurfaceVariant, fontSize = 12.sp
                        )
                        if (vm.foreignOn && vm.transStatus == 3) {
                            TextButton(onClick = { vm.prepareModel() }) { Text("إعادة المحاولة") }
                        }
                    }
                    Switch(checked = vm.foreignOn, onCheckedChange = { vm.setForeign(it) })
                }
            }
            if (vm.foreignOn) {
                item { DeeplBox(vm) }
            }
            if (vm.foreignOn) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("تنبيهات الأخبار الأجنبية", fontWeight = FontWeight.Bold)
                            Text(
                                "من أهم الوكالات فقط (Reuters وAP وBBC والجزيرة الإنجليزية وSky) بلغتها الأصلية، وتُترجم عند فتحها",
                                color = cs.onSurfaceVariant, fontSize = 12.sp
                            )
                        }
                        Switch(checked = vm.alertForeign, onCheckedChange = { vm.changeAlertForeign(it) })
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("المصادر", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(onClick = { vm.testSources() }, enabled = !vm.testing, shape = RoundedCornerShape(12.dp)) {
                        Text(if (vm.testing) "جارٍ الفحص…" else "فحص المصادر")
                    }
                }
            }
            items(SOURCES.filter { it.category in vm.interests && (it.lang == "ar" || vm.foreignOn) }) { s ->
                val k = s.key()
                val cat = CATEGORIES.firstOrNull { it.id == s.category }?.label ?: ""
                val h = vm.health[k]
                val status = when {
                    h == null -> ""
                    h > 0 -> "  ✓ $h خبر"
                    else -> "  ✗ لا يعمل"
                }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface).padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(s.name, fontWeight = FontWeight.SemiBold)
                        Text(cat + (if (s.lang == "en") " · إنجليزي" else "") + status, fontSize = 12.sp, color = if (h != null && h <= 0) Color(0xFFE5484D) else cs.onSurfaceVariant)
                    }
                    Switch(checked = k !in vm.disabled, onCheckedChange = { vm.toggle(s) })
                }
            }
        }
    }
}

@Composable
fun DeeplBox(vm: MainVM) {
    val cs = MaterialTheme.colorScheme
    var text by remember { mutableStateOf(vm.deeplKey) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surface).padding(16.dp)) {
        Text("ترجمة DeepL (اختياري)", fontWeight = FontWeight.Bold)
        Text(
            "جودة أعلى بكثير من الترجمة المحلية. الصق مفتاحك المجاني، وإن تركته فارغاً تبقى الترجمة المحلية.",
            color = cs.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
        )
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                label = { Text("DeepL API key") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
        }
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.saveDeeplKey(text); vm.testDeepl() }, shape = RoundedCornerShape(12.dp)) { Text("حفظ واختبار") }
            if (vm.deeplKey.isNotBlank()) {
                TextButton(onClick = { text = ""; vm.saveDeeplKey("") }) { Text("حذف المفتاح") }
            }
        }
        if (vm.deeplMsg.isNotBlank()) Text(vm.deeplMsg, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun Feed(vm: MainVM, onSettings: () -> Unit) {
    var filter by remember { mutableStateOf<String?>(null) }
    val list = remember(vm.articles, vm.interests, vm.disabled, vm.foreignOn, filter) {
        vm.articles.filter {
            it.category in vm.interests && (filter == null || it.category == filter) &&
                (it.category + "|" + it.source) !in vm.disabled && (it.lang == "ar" || vm.foreignOn)
        }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Pill("الكل", filter == null) { filter = null } }
                items(CATEGORIES.filter { it.id in vm.interests }) { c ->
                    Pill("${c.emoji} ${c.label}", filter == c.id) { filter = c.id }
                }
            }
            IconText("↻") { vm.refresh() }
            IconText("⚙", onSettings)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                list.isEmpty() && vm.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                list.isEmpty() -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (vm.failed) "تعذّر جلب الأخبار، تحقق من الاتصال" else "لا توجد أخبار بعد", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { vm.refresh() }) { Text("إعادة المحاولة") }
                }
                else -> key(filter) {
                    val ls = rememberLazyListState()
                    LazyColumn(
                        state = ls,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(list, key = { it.link }) { a -> NewsItem(a, vm.translations, vm.perPage) }
                        item { Spacer(Modifier.navigationBarsPadding()) }
                    }
                    LaunchedEffect(list, vm.transStatus, vm.deeplKey) {
                        snapshotFlow { ls.firstVisibleItemIndex }.collect { i ->
                            val from = i.coerceAtMost(list.size)
                            vm.translateIfNeeded(list.subList(from, (from + 8).coerceAtMost(list.size)))
                        }
                    }
                    LaunchedEffect(vm.focusLink, list) {
                        val l = vm.focusLink
                        if (l != null) {
                            val idx = list.indexOfFirst { it.link == l }
                            if (idx >= 0) {
                                ls.scrollToItem(idx)
                                vm.focusLink = null
                            } else if (filter != null) filter = null
                            else vm.focusLink = null
                        }
                    }
                }
            }
            if (vm.loading && list.isNotEmpty()) {
                LinearProgressIndicator(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(2.dp))
            }
        }
    }
}

fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "الآن"
        m < 60 -> "منذ $m د"
        m < 1440 -> "منذ ${m / 60} س"
        else -> "منذ ${m / 1440} يوم"
    }
}

@Composable
fun TransBadge(a: Article, tr: Pair<String, String>?, showOrig: Boolean, onToggle: () -> Unit) {
    if (a.lang != "en") return
    val txt = when {
        tr == null -> "جارٍ الترجمة…"
        showOrig -> "عرض الترجمة"
        else -> "مترجم تلقائياً · عرض الأصل"
    }
    Text(
        txt, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(enabled = tr != null, onClick = onToggle)
            .padding(vertical = 4.dp)
    )
}

@Composable
fun NewsItem(a: Article, translations: SnapshotStateMap<String, Pair<String, String>>, size: Int) {
    // derivedStateOf: لا تُعاد رسم البطاقة إلا إذا تغيّرت ترجمتها هي
    val tr by remember(a.link) { derivedStateOf { translations[a.link] } }
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val cat = CATEGORIES.firstOrNull { it.id == a.category }
    var showOrig by remember(a.link) { mutableStateOf(false) }
    val useTr = a.lang == "en" && tr != null && !showOrig
    val title = if (useTr) (tr?.first ?: a.title) else a.title
    val summary = if (useTr) (tr?.second ?: a.summary) else a.summary
    val al = if (a.lang == "en" && !useTr) TextAlign.Left else TextAlign.Start
    val tSize = when (size) { 1 -> 24.sp; 2 -> 20.sp; else -> 17.sp }
    val tLine = when (size) { 1 -> 34.sp; 2 -> 29.sp; else -> 25.sp }
    val tMax = when (size) { 1 -> 6; 2 -> 4; else -> 3 }
    val sSize = when (size) { 1 -> 16.sp; 2 -> 15.sp; else -> 13.5.sp }
    val sLine = when (size) { 1 -> 26.sp; 2 -> 22.sp; else -> 20.sp }
    val sMax = when (size) { 1 -> 8; 2 -> 4; else -> 2 }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surface).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(a.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
            Text("  •  ${ago(a.time)}", color = cs.onSurfaceVariant, fontSize = 12.5.sp)
            Spacer(Modifier.weight(1f))
            if (a.lang == "en") {
                TransBadge(a, tr, showOrig) { showOrig = !showOrig }
                Spacer(Modifier.width(8.dp))
            }
            if (cat != null) Text(cat.emoji, fontSize = 15.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            title, fontSize = tSize, lineHeight = tLine, fontWeight = FontWeight.Bold,
            maxLines = tMax, overflow = TextOverflow.Ellipsis, textAlign = al, modifier = Modifier.fillMaxWidth()
        )
        if (summary.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(
                summary, fontSize = sSize, lineHeight = sLine, color = cs.onSurfaceVariant,
                maxLines = sMax, overflow = TextOverflow.Ellipsis, textAlign = al, modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "فتح الخبر الأصلي ↗", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            modifier = Modifier.clip(RoundedCornerShape(10.dp))
                .clickable {
                    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.link))) } catch (_: Exception) {}
                }
                .padding(horizontal = 4.dp, vertical = 6.dp)
        )
    }
}
