package com.lamha.news

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LamhaApp() }
    }
}

class MainVM(app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    var interests by mutableStateOf(repo.interests)
    var onboarded by mutableStateOf(repo.onboarded)
    var articles by mutableStateOf(repo.loadCache())
    var loading by mutableStateOf(false)
    var failed by mutableStateOf(false)

    init {
        if (onboarded && (articles.isEmpty() || System.currentTimeMillis() - repo.lastRefresh > 10 * 60_000L)) refresh()
    }

    fun refresh() {
        if (loading) return
        viewModelScope.launch {
            loading = true
            val r = repo.refresh(interests)
            failed = r.none { it.category in interests }
            articles = r
            loading = false
        }
    }

    fun save(s: Set<String>) {
        interests = s; repo.interests = s
        onboarded = true; repo.onboarded = true
        refresh()
    }
}

@Composable
fun LamhaTheme(dark: Boolean, content: @Composable () -> Unit) {
    val cs = if (dark) darkColorScheme(
        primary = Color(0xFF34D3A5), onPrimary = Color(0xFF04271D),
        background = Color(0xFF0D0F12), surface = Color(0xFF16191E),
        onBackground = Color(0xFFECEFF1), onSurface = Color(0xFFECEFF1),
        surfaceVariant = Color(0xFF1F242B), onSurfaceVariant = Color(0xFF9AA4AF)
    ) else lightColorScheme(
        primary = Color(0xFF0E7C66), onPrimary = Color.White,
        background = Color(0xFFF6F7F4), surface = Color.White,
        onBackground = Color(0xFF111418), onSurface = Color(0xFF111418),
        surfaceVariant = Color(0xFFE6E9E4), onSurfaceVariant = Color(0xFF5B6570)
    )
    MaterialTheme(colorScheme = cs, content = content)
}

@Composable
fun LamhaApp(vm: MainVM = viewModel()) {
    LamhaTheme(isSystemInDarkTheme()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                var settings by remember { mutableStateOf(false) }
                BackHandler(settings) { settings = false }
                if (!vm.onboarded || settings) {
                    Onboarding(vm.interests, vm.onboarded, { vm.save(it); settings = false }, { settings = false })
                } else {
                    Feed(vm) { settings = true }
                }
            }
        }
    }
}

@Composable
fun Onboarding(initial: Set<String>, isEdit: Boolean, onDone: (Set<String>) -> Unit, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var sel by remember { mutableStateOf(initial) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp)) {
        Text(if (isEdit) "اهتماماتك" else "ما الذي يهمّك؟", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "اختر موضوعاً واحداً على الأقل، ويمكنك التغيير لاحقاً",
            color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp)
        )
        Spacer(Modifier.height(24.dp))
        LazyVerticalGrid(
            GridCells.Fixed(2), Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(CATEGORIES) { c ->
                val on = c.id in sel
                val shape = RoundedCornerShape(20.dp)
                Box(
                    Modifier.height(110.dp).clip(shape)
                        .background(if (on) cs.primary.copy(alpha = 0.16f) else cs.surface)
                        .border(2.dp, if (on) cs.primary else Color.Transparent, shape)
                        .clickable { sel = if (on) sel - c.id else sel + c.id },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(c.emoji, fontSize = 32.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(c.label, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onDone(sel) }, enabled = sel.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)
        ) { Text(if (isEdit) "حفظ" else "ابدأ", fontSize = 16.sp) }
        if (isEdit) TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
    }
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) cs.primary else cs.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, fontSize = 14.sp, color = if (selected) cs.onPrimary else cs.onSurface, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun IconText(text: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(text, fontSize = 20.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Feed(vm: MainVM, onSettings: () -> Unit) {
    var filter by remember { mutableStateOf<String?>(null) }
    val list = remember(vm.articles, vm.interests, filter) {
        vm.articles.filter { it.category in vm.interests && (filter == null || it.category == filter) }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Pill("الكل", filter == null) { filter = null } }
                items(CATEGORIES.filter { it.id in vm.interests }) { c ->
                    Pill("${c.emoji} ${c.label}", filter == c.id) { filter = c.id }
                }
            }
            IconText("↻") { vm.refresh() }
            IconText("⚙", onSettings)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                list.isEmpty() && vm.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                list.isEmpty() -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (vm.failed) "تعذّر جلب الأخبار، تحقق من الاتصال" else "لا توجد أخبار بعد", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { vm.refresh() }) { Text("إعادة المحاولة") }
                }
                else -> key(filter) {
                    val ps = rememberPagerState { list.size }
                    VerticalPager(ps, Modifier.fillMaxSize()) { i -> NewsCard(list[i], Modifier.fillMaxSize()) }
                }
            }
            if (vm.loading && list.isNotEmpty()) {
                LinearProgressIndicator(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(2.dp))
            }
        }
    }
}

fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "الآن"
        m < 60 -> "منذ $m د"
        m < 1440 -> "منذ ${m / 60} س"
        else -> "منذ ${m / 1440} يوم"
    }
}

@Composable
fun NewsCard(a: Article, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val cat = CATEGORIES.firstOrNull { it.id == a.category }
    Column(modifier.padding(horizontal = 14.dp).padding(bottom = 14.dp).navigationBarsPadding()) {
        Box(
            Modifier.fillMaxWidth().fillMaxHeight(0.40f)
                .clip(RoundedCornerShape(24.dp)).background(cs.surfaceVariant)
        ) {
            if (a.image != null) {
                AsyncImage(model = a.image, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Text(cat?.emoji ?: "📰", fontSize = 56.sp, modifier = Modifier.align(Alignment.Center))
            }
            if (cat != null) {
                Text(
                    cat.label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                        .clip(RoundedCornerShape(50)).background(Color(0x99000000))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(a.source, color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("  •  ${ago(a.time)}", color = cs.onSurfaceVariant, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(a.title, fontSize = 22.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold, maxLines = 5, overflow = TextOverflow.Ellipsis)
        if (a.summary.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(a.summary, fontSize = 15.sp, lineHeight = 24.sp, color = cs.onSurfaceVariant, maxLines = 6, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.weight(1f))
        Button(
            onClick = {
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.link))) } catch (_: Exception) {}
            },
            modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)
        ) { Text("فتح الخبر الأصلي  ↗", fontSize = 16.sp) }
    }
}
