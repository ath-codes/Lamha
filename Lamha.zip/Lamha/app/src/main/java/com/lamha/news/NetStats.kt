package com.lamha.news

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * إحصاء تقريبي لاستهلاك الإنترنت لكل نوع نشاط ولكل يوم (آخر 14 يوماً). الأحجام بعد فك الضغط فالفعلي أقل غالباً،
 * ولا يشمل المتصفح المخفي (WebView) ولا طلبات فك روابط Google. الغرض: أن نقرر بالأرقام (مثل رفع الجلب المسبق)
 */
object NetStats {
    private val LOCK = Any()
    private var prefs: SharedPreferences? = null
    @Volatile private var total = 0L

    /** النوع ← الاسم المعروض */
    val BUCKETS = listOf("feed" to "تحديث الأخبار", "read" to "فتح الأخبار", "prefetch" to "الجلب المسبق", "diag" to "الفحوصات")

    fun init(ctx: Context) {
        synchronized(LOCK) {
            if (prefs != null) return
            val p = ctx.applicationContext.getSharedPreferences("lamha_net", Context.MODE_PRIVATE)
            prefs = p
            try {
                val keep = (0 until 14).map { day(it) }.toSet()
                val old = p.all.keys.filter { k -> keep.none { k.startsWith("$it|") } }
                if (old.isNotEmpty()) { val e = p.edit(); old.forEach { e.remove(it) }; e.apply() }
            } catch (_: Exception) {}
        }
    }

    private fun day(back: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -back)
        return SimpleDateFormat("yyyyMMdd", Locale.US).format(c.time)
    }

    fun add(bucket: String, bytes: Long) {
        if (bytes <= 0L) return
        total += bytes
        synchronized(LOCK) {
            val p = prefs ?: return
            val k = day(0) + "|" + bucket
            p.edit().putLong(k, p.getLong(k, 0L) + bytes).apply()
        }
    }

    /** مجموع ما عُدّ منذ بدء العملية (لقياس استهلاك فحص معيّن بالفرق) */
    fun session(): Long = total

    /** مجموع نوع معيّن في آخر days يوماً (اليوم = 1) */
    fun sum(bucket: String, days: Int): Long = synchronized(LOCK) {
        val p = prefs ?: return 0L
        (0 until days).sumOf { p.getLong(day(it) + "|" + bucket, 0L) }
    }

    /** مجموع كل الأنواع ما عدا الفحوصات: الاستهلاك الحقيقي للاستخدام العادي */
    fun sumUsage(days: Int): Long = BUCKETS.filter { it.first != "diag" }.sumOf { sum(it.first, days) }

    fun sumAll(days: Int): Long = BUCKETS.sumOf { sum(it.first, days) }

    fun fmt(b: Long): String = when {
        b < 1024L -> "$b بايت"
        b < 1024L * 1024L -> String.format(Locale.US, "%.0f ك.ب", b / 1024.0)
        else -> String.format(Locale.US, "%.1f م.ب", b / 1048576.0)
    }

    /** سطر مختصر للإعدادات (الاستخدام العادي بلا الفحوصات) */
    fun summary(): String = "اليوم: " + fmt(sumUsage(1)) + " · آخر 7 أيام: " + fmt(sumUsage(7)) + " (متوسط يومي " + fmt(sumUsage(7) / 7) + ")"

    fun report(): String {
        val sb = StringBuilder("استهلاك الإنترنت التقريبي (بعد فك الضغط، بلا المتصفح المخفي)\n")
        sb.append("اليوم / آخر 7 أيام:\n")
        for ((id, label) in BUCKETS) sb.append("• ").append(label).append(": ").append(fmt(sum(id, 1))).append(" / ").append(fmt(sum(id, 7))).append('\n')
        sb.append("الاستخدام العادي بلا الفحوصات: ").append(fmt(sumUsage(1))).append(" / ").append(fmt(sumUsage(7))).append('\n')
        sb.append("المتوسط اليومي للاستخدام العادي (7 أيام): ").append(fmt(sumUsage(7) / 7)).append('\n')
        sb.append("الأيام السبعة الأخيرة (الأحدث أولاً): ")
        sb.append((0 until 7).joinToString("، ") { d ->
            fmt(synchronized(LOCK) { BUCKETS.filter { it.first != "diag" }.sumOf { b -> prefs?.getLong(day(d) + "|" + b.first, 0L) ?: 0L } })
        })
        sb.append('\n')
        return sb.toString()
    }
}
