package com.lamha.news

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Repo(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("lamha", Context.MODE_PRIVATE)
    private val file = File(ctx.filesDir, "cache.json")

    var interests: Set<String>
        get() = prefs.getStringSet("interests", emptySet())!!.toSet()
        set(v) = prefs.edit().putStringSet("interests", v).apply()

    var onboarded: Boolean
        get() = prefs.getBoolean("onboarded", false)
        set(v) = prefs.edit().putBoolean("onboarded", v).apply()

    var alertMin: Int
        get() = prefs.getInt("alertMin", 60)
        set(v) = prefs.edit().putInt("alertMin", v).apply()

    var foreignOn: Boolean
        get() = prefs.getBoolean("foreign", false)
        set(v) = prefs.edit().putBoolean("foreign", v).apply()

    var alertForeign: Boolean
        get() = prefs.getBoolean("alertForeign", true)
        set(v) = prefs.edit().putBoolean("alertForeign", v).apply()

    var deeplKey: String
        get() = prefs.getString("deeplKey", "") ?: ""
        set(v) = prefs.edit().putString("deeplKey", v).apply()

    var perPage: Int
        get() = prefs.getInt("perPage", 3)
        set(v) = prefs.edit().putInt("perPage", v).apply()

    var disabled: Set<String>
        get() = prefs.getStringSet("disabled", emptySet())!!.toSet()
        set(v) = prefs.edit().putStringSet("disabled", v).apply()

    var lastRefresh: Long
        get() = prefs.getLong("last", 0L)
        set(v) = prefs.edit().putLong("last", v).apply()

    fun loadCache(): List<Article> = try {
        val a = JSONArray(file.readText())
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Article(
                o.getString("id"), o.getString("title"), o.getString("summary"),
                o.getString("link"), o.getString("source"), o.getString("category"), o.getLong("time"), o.optString("lang", "ar")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun save(list: List<Article>) {
        try {
            val a = JSONArray()
            list.forEach {
                a.put(JSONObject().apply {
                    put("id", it.id); put("title", it.title); put("summary", it.summary)
                    put("link", it.link); put("source", it.source)
                    put("category", it.category); put("time", it.time); put("lang", it.lang)
                })
            }
            file.writeText(a.toString())
        } catch (_: Exception) {
        }
    }

    // حد أقصى 8 اتصالات متزامنة لتخفيف الضغط على المعالج والشبكة
    private val gate = Semaphore(8)

    suspend fun test(list: List<Source>): Map<String, Int> = withContext(Dispatchers.IO) {
        coroutineScope {
            list.map { s -> async { gate.withPermit { s.key() to runCatching { Rss.fetch(s).size }.getOrDefault(-1) } } }
                .awaitAll().toMap()
        }
    }

    suspend fun refresh(interests: Set<String>): List<Article> = withContext(Dispatchers.IO) {
        val fetched = coroutineScope {
            SOURCES.filter { it.category in interests && it.key() !in disabled && (it.lang == "ar" || foreignOn) }
                .map { s -> async { gate.withPermit { runCatching { Rss.fetch(s) }.getOrDefault(emptyList()) } } }
                .awaitAll().flatten()
        }
        val now = System.currentTimeMillis()
        val merged = (fetched + loadCache())
            .distinctBy { it.link }
            .filter { now - it.time < 3 * 24 * 3600_000L }
            .groupBy { it.category + "|" + it.source }
            .values.flatMap { g -> g.sortedByDescending { it.time }.take(20) }
            .sortedByDescending { it.time }
            .take(300)
        save(merged)
        lastRefresh = now
        merged
    }
}
