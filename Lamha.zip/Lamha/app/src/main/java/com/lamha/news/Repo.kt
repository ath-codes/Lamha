package com.lamha.news

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class Repo(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("lamha", Context.MODE_PRIVATE)
    private val file = File(ctx.filesDir, "cache.json")
    private val savedFile = File(ctx.filesDir, "saved.json")

    var interests: Set<String>
        get() = prefs.getStringSet("interests", emptySet())!!.toSet()
        set(v) = prefs.edit().putStringSet("interests", v).apply()

    var onboarded: Boolean
        get() = prefs.getBoolean("onboarded", false)
        set(v) = prefs.edit().putBoolean("onboarded", v).apply()

    var alertMin: Int
        get() = prefs.getInt("alertMin", 60)
        set(v) = prefs.edit().putInt("alertMin", v).apply()

    var perPage: Int
        get() = prefs.getInt("perPage", 3)
        set(v) = prefs.edit().putInt("perPage", v).apply()

    var disabled: Set<String>
        get() = prefs.getStringSet("disabled", emptySet())!!.toSet()
        set(v) = prefs.edit().putStringSet("disabled", v).apply()

    // 0 = الأحدث، 1 = الأهم (عدد المصادر التي غطّت الخبر مع الحداثة)
    var sortMode: Int
        get() = prefs.getInt("sortMode", 0)
        set(v) = prefs.edit().putInt("sortMode", v).apply()

    var lastRefresh: Long
        get() = prefs.getLong("last", 0L)
        set(v) = prefs.edit().putLong("last", v).apply()

    // الأخبار المخفية بالسحب (روابط). تُنظَّف تلقائياً من الروابط التي لم تعد في الكاش
    var hidden: Set<String>
        get() = prefs.getStringSet("hidden", emptySet())!!.toSet()
        set(v) = prefs.edit().putStringSet("hidden", v).apply()

    // وقت آخر خروج من التطبيق: ما نُشر بعده يُعتبر جديداً عند الفتح التالي
    var lastClose: Long
        get() = prefs.getLong("lastClose", 0L)
        set(v) = prefs.edit().putLong("lastClose", v).apply()

    fun loadCache(): List<Article> = synchronized(LOCK) { readCache() }

    // الأخبار المحفوظة تبقى دائماً (لا تنتهي بعد 3 أيام كالكاش)، الأحدث حفظاً أولاً
    fun loadSaved(): List<Article> = synchronized(LOCK) {
        try {
            val a = JSONArray(savedFile.readText())
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Article(
                    o.getString("id"), o.getString("title"), o.getString("summary"),
                    o.getString("link"), o.getString("source"), o.getString("category"), o.getLong("time")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveSaved(list: List<Article>) = synchronized(LOCK) { writeAtomic(savedFile, toJson(list)) }

    private fun readCache(): List<Article> = try {
        val a = JSONArray(file.readText())
        (0 until a.length()).mapNotNull {
            val o = a.getJSONObject(it)
            if (o.optString("lang", "ar") == "en") null // كاش قديم من إصدار الأخبار الأجنبية
            else Article(
                o.getString("id"), o.getString("title"), o.getString("summary"),
                o.getString("link"), o.getString("source"), o.getString("category"), o.getLong("time")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun toJson(list: List<Article>): String {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().apply {
                put("id", it.id); put("title", it.title); put("summary", it.summary)
                put("link", it.link); put("source", it.source)
                put("category", it.category); put("time", it.time)
            })
        }
        return a.toString()
    }

    // كتابة ذرّية: ملف مؤقت ثم إعادة تسمية، فلا يتلف الملف لو توقفت العملية في المنتصف
    private fun writeAtomic(f: File, text: String) {
        try {
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(f)) {
                f.delete()
                tmp.renameTo(f)
            }
        } catch (_: Exception) {
        }
    }

    private fun save(list: List<Article>) = writeAtomic(file, toJson(list))

    // ---- سعر الدولار مقابل الجنيه (open.er-api.com: مجاني بلا مفتاح، يتحدث مرة يومياً، ويشترط ذكر المصدر) ----
    fun loadUsd(): Usd? {
        val cur = prefs.getString("usd_cur", null)?.toDoubleOrNull() ?: return null
        val prev = prefs.getString("usd_prev", null)?.toDoubleOrNull() ?: 0.0
        return Usd(cur, prev, prefs.getLong("usd_at", 0L))
    }

    // لا يتصل أكثر من مرة كل ساعة. السهم = المقارنة بسعر اليوم السابق المحفوظ محلياً (المصدر لا يوفر الأمس)
    suspend fun refreshUsd(): Usd? = withContext(Dispatchers.IO) {
        val old = loadUsd()
        val now = System.currentTimeMillis()
        if (old != null && now - old.fetched < 60 * 60_000L) return@withContext old
        try {
            val c = URL("https://open.er-api.com/v6/latest/USD").openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Lamha/1.0")
            try {
                if (c.responseCode != 200) return@withContext old
                val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                if (o.optString("result") != "success") return@withContext old
                val rate = o.getJSONObject("rates").getDouble("EGP")
                val day = o.optLong("time_last_update_unix", 0L) / 86400L
                val curDay = prefs.getLong("usd_day", 0L)
                var prev = prefs.getString("usd_prev", null)?.toDoubleOrNull() ?: 0.0
                if (old != null && day > curDay) prev = old.rate
                prefs.edit()
                    .putString("usd_cur", rate.toString())
                    .putString("usd_prev", prev.toString())
                    .putLong("usd_day", maxOf(day, curDay))
                    .putLong("usd_at", now)
                    .apply()
                Usd(rate, prev, now)
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
            old
        }
    }

    companion object {
        // قفل مشترك بين الواجهة والعامل الخلفي (كلاهما في نفس العملية)
        private val LOCK = Any()
    }

    // حد أقصى 8 اتصالات متزامنة لتخفيف الضغط على المعالج والشبكة
    private val gate = Semaphore(8)

    suspend fun test(list: List<Source>): Map<String, Health> = withContext(Dispatchers.IO) {
        coroutineScope {
            list.map { s ->
                async {
                    gate.withPermit {
                        s.key() to runCatching { Rss.fetchInfo(s).let { Health(it.first.size, it.second) } }
                            .getOrDefault(Health(0, false))
                    }
                }
            }.awaitAll().toMap()
        }
    }

    suspend fun refresh(interests: Set<String>): List<Article> = withContext(Dispatchers.IO) {
        val fetched = coroutineScope {
            SOURCES.filter { it.category in interests && it.key() !in disabled }
                .map { s -> async { gate.withPermit { runCatching { Rss.fetch(s) }.getOrDefault(emptyList()) } } }
                .awaitAll().flatten()
        }
        val now = System.currentTimeMillis()
        // القراءة والدمج والكتابة تتم تحت القفل حتى لا يضيع تحديث أحد الطرفين
        val merged = synchronized(LOCK) {
            val m = (readCache() + fetched)
                .distinctBy { it.link }
                .filter { now - it.time < 3 * 24 * 3600_000L }
                .groupBy { it.category + "|" + it.source }
                .values.flatMap { g -> g.sortedByDescending { it.time }.take(20) }
                .sortedByDescending { it.time }
                .take(300)
            save(m)
            m
        }
        lastRefresh = now
        merged
    }
}
