package com.lamha.news

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class Repo(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("lamha", Context.MODE_PRIVATE)
    private val file = File(ctx.filesDir, "cache.json")

    init { NetStats.init(ctx) }

    // الجلب المسبق: false = واي فاي فقط (الافتراضي)، true = دائماً (يستهلك بيانات الجوال)
    var prefetchAlways: Boolean
        get() = prefs.getBoolean("prefetchAlways", false)
        set(v) = prefs.edit().putBoolean("prefetchAlways", v).apply()

    var interests: Set<String>
        get() = prefs.getStringSet("interests", emptySet())!!.toSet()
        set(v) = prefs.edit().putStringSet("interests", v).apply()

    var onboarded: Boolean
        get() = prefs.getBoolean("onboarded", false)
        set(v) = prefs.edit().putBoolean("onboarded", v).apply()

    // قديم: كان التنبيه والتحديث الخلفي خيارًا واحدًا (alertMin). نقرؤه فقط لترحيل إعدادات من حدّثوا من نسخة سابقة
    private val legacyAlertMin: Int get() = prefs.getInt("alertMin", 0)

    /** فاصل التحديث الخلفي بالدقائق (0 = متوقف). افتراضياً كل 30 دقيقة */
    var bgMin: Int
        get() = if (prefs.contains("bgMin")) prefs.getInt("bgMin", 30) else if (legacyAlertMin > 0) legacyAlertMin else 30
        set(v) = prefs.edit().putInt("bgMin", v).apply()

    /** إشعار بالأخبار الجديدة بعد التحديث الخلفي، مستقل عن التحديث نفسه. افتراضياً مغلق إلا لمن كان تنبيهه مفعّلاً سابقاً */
    var notify: Boolean
        get() = if (prefs.contains("notify")) prefs.getBoolean("notify", false) else legacyAlertMin > 0
        set(v) = prefs.edit().putBoolean("notify", v).apply()

    var perPage: Int
        get() = prefs.getInt("perPage", 3)
        set(v) = prefs.edit().putInt("perPage", v).apply()

    var disabled: Set<String>
        get() = prefs.getStringSet("disabled", emptySet())!!.toSet()
        set(v) = prefs.edit().putStringSet("disabled", v).apply()

    // 0 = الأحدث، 1 = الأهم (الافتراضي): وزن المصادر وكلمات الأحداث الكبرى مع الحداثة
    var sortMode: Int
        get() = prefs.getInt("sortMode", 1)
        set(v) = prefs.edit().putInt("sortMode", v).apply()

    // مدة بقاء الأخبار بالأيام (1 أو 2 أو 3). الافتراضي يوم واحد
    var retainDays: Int
        get() = prefs.getInt("retainDays", 1)
        set(v) = prefs.edit().putInt("retainDays", v).apply()

    var lastRefresh: Long
        get() = prefs.getLong("last", 0L)
        set(v) = prefs.edit().putLong("last", v).apply()

    // الأخبار المخفية بالسحب (روابط). تُنظَّف تلقائياً من الروابط التي لم تعد في الكاش
    var hidden: Set<String>
        get() = prefs.getStringSet("hidden", emptySet())!!.toSet()
        set(v) = prefs.edit().putStringSet("hidden", v).apply()

    // وقت آخر خروج من التطبيق: ما نُشر بعده يُعتبر جديداً عند الفتح التالي
    var lastClose: Long
        get() = prefs.getLong("lastClose", 0L)
        set(v) = prefs.edit().putLong("lastClose", v).apply()

    fun loadCache(): List<Article> = synchronized(LOCK) {
        val now = System.currentTimeMillis()
        val valid = allSources().map { it.key() }.toHashSet()
        readCache().filter { it.category + "|" + it.source in valid && now - it.time < keepDays(it.category, retainDays) * 24L * 3600_000L }
    }


    private fun readCache(): List<Article> = try {
        val a = JSONArray(file.readText())
        (0 until a.length()).mapNotNull {
            val o = a.getJSONObject(it)
            if (o.optString("lang", "ar") == "en") null // كاش قديم من إصدار الأخبار الأجنبية
            else Article(
                o.getString("id"), o.getString("title"), o.getString("summary"),
                o.getString("link"), o.getString("source"), o.getString("category"), o.getLong("time")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun toJson(list: List<Article>): String {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().apply {
                put("id", it.id); put("title", it.title); put("summary", it.summary)
                put("link", it.link); put("source", it.source)
                put("category", it.category); put("time", it.time)
            })
        }
        return a.toString()
    }

    // كتابة ذرّية: ملف مؤقت ثم إعادة تسمية، فلا يتلف الملف لو توقفت العملية في المنتصف
    private fun writeAtomic(f: File, text: String) {
        try {
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(f)) {
                f.delete()
                tmp.renameTo(f)
            }
        } catch (_: Exception) {
        }
    }

    private fun save(list: List<Article>) = writeAtomic(file, toJson(list))

    // ---- سعر الدولار مقابل الجنيه (open.er-api.com: مجاني بلا مفتاح، يتحدث مرة يومياً، ويشترط ذكر المصدر) ----
    fun loadUsd(): Usd? {
        val cur = prefs.getString("usd_cur", null)?.toDoubleOrNull() ?: return null
        val prev = prefs.getString("usd_prev", null)?.toDoubleOrNull() ?: 0.0
        val qar = prefs.getString("qar_cur", null)?.toDoubleOrNull() ?: 0.0
        val qarPrev = prefs.getString("qar_prev", null)?.toDoubleOrNull() ?: 0.0
        return Usd(cur, prev, prefs.getLong("usd_at", 0L), qar, qarPrev)
    }

    // لا يتصل أكثر من مرة كل ساعة. السهم = المقارنة بسعر اليوم السابق المحفوظ محلياً (المصدر لا يوفر الأمس)
    suspend fun refreshUsd(): Usd? = withContext(Dispatchers.IO) {
        val old = loadUsd()
        val now = System.currentTimeMillis()
        if (old != null && old.qar > 0.0 && now - old.fetched < 60 * 60_000L) return@withContext old
        try {
            val c = URL("https://open.er-api.com/v6/latest/USD").openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Lamha/1.0")
            try {
                if (c.responseCode != 200) return@withContext old
                val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                if (o.optString("result") != "success") return@withContext old
                val rates = o.getJSONObject("rates")
                val rate = rates.getDouble("EGP")
                val qr = rates.optDouble("QAR", 0.0)
                val qar = if (qr > 0.0) rate / qr else 0.0 // جنيه لكل ريال قطري
                val day = o.optLong("time_last_update_unix", 0L) / 86400L
                val curDay = prefs.getLong("usd_day", 0L)
                var prev = prefs.getString("usd_prev", null)?.toDoubleOrNull() ?: 0.0
                var qarPrev = prefs.getString("qar_prev", null)?.toDoubleOrNull() ?: 0.0
                if (old != null && day > curDay) {
                    prev = old.rate
                    if (old.qar > 0.0) qarPrev = old.qar
                }
                prefs.edit()
                    .putString("usd_cur", rate.toString())
                    .putString("usd_prev", prev.toString())
                    .putString("qar_cur", qar.toString())
                    .putString("qar_prev", qarPrev.toString())
                    .putLong("usd_day", maxOf(day, curDay))
                    .putLong("usd_at", now)
                    .apply()
                Usd(rate, prev, now, qar, qarPrev)
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
            old
        }
    }

    companion object {
        // قفل مشترك بين الواجهة والعامل الخلفي (كلاهما في نفس العملية)
        private val LOCK = Any()
    }

    // 24 اتصالاً متزامناً: المصادر كثيرة (نحو 70) والانتظار فيها على الشبكة لا المعالج، فكانت 8 تعني تسع دفعات متتالية
    private val gate = Semaphore(24)

    // مصادر أضافها المستخدم من الإعدادات (JSON في التفضيلات). موقعها متخصص بتصنيفها فلا تُفلتر بالكلمات
    var custom: List<Source>
        get() = try {
            val a = JSONArray(prefs.getString("custom", "[]"))
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Source(o.getString("name"), o.getString("url"), o.getString("category"), focused = true)
            }
        } catch (_: Exception) { emptyList() }
        set(v) {
            val a = JSONArray()
            v.forEach { a.put(JSONObject().put("name", it.name).put("url", it.url).put("category", it.category)) }
            prefs.edit().putString("custom", a.toString()).apply()
        }

    fun allSources(): List<Source> = SOURCES + custom

    suspend fun test(list: List<Source>): Map<String, Health> = withContext(Dispatchers.IO) {
        coroutineScope {
            list.map { s ->
                async {
                    gate.withPermit {
                        s.key() to runCatching { Rss.probe(s).let { Health(it.articles.size, it.viaFallback, it.notes, it.articles.firstOrNull()?.title ?: "", it.ms, it.feedItems, it.feedFull, it.feedMax) } }
                            .getOrDefault(Health(0, false))
                    }
                }
            }.awaitAll().toMap()
        }
    }

    /**
     * deadlineMs: أقصى انتظار للتحديث. المصادر التي لم تردّ خلاله تُترك (يلتقطها التحديث التالي)
     * فلا يعطّل مصدر بطيء أو ميت التحديث كله. الواجهة تستخدم مهلة قصيرة والعامل الخلفي مهلة أطول.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    suspend fun refresh(interests: Set<String>, deadlineMs: Long = 9_000L): List<Article> = withContext(Dispatchers.IO) {
        // نطاق مستقل: coroutineScope كان سينتظر كل المصادر حتى البطيء، أما هنا فنقرأ ما وصل عند انتهاء المهلة
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        val jobs = allSources().filter { it.category in interests && it.key() !in disabled }
            .map { s -> scope.async { gate.withPermit { runCatching { Rss.fetch(s) }.getOrDefault(emptyList()) } } }
        withTimeoutOrNull(deadlineMs) { jobs.awaitAll() }
        val fetched = jobs.filter { it.isCompleted && !it.isCancelled }.flatMap { it.getCompleted() }
        scope.cancel()
        val now = System.currentTimeMillis()
        val valid = allSources().map { it.key() }.toHashSet() // أخبار مصدر حُذف لا تبقى في الكاش
        // القراءة والدمج والكتابة تتم تحت القفل حتى لا يضيع تحديث أحد الطرفين
        val merged = synchronized(LOCK) {
            val m = (readCache() + fetched)
                .distinctBy { it.link }
                .filter { it.category + "|" + it.source in valid }
                .filter { now - it.time < keepDays(it.category, retainDays) * 24L * 3600_000L }
                .groupBy { it.category + "|" + it.source }
                .values.flatMap { g -> g.sortedByDescending { it.time }.take(20) }
            // التحليلات أقدم عادة من الأخبار، فلا يزاحمها سقف الأخبار
            val news = m.filter { it.category != "analysis" }.sortedByDescending { it.time }.take(500)
            val analysis = m.filter { it.category == "analysis" }.sortedByDescending { it.time }.take(150)
            val all = (news + analysis).sortedByDescending { it.time }
            save(all)
            all
        }
        // لا نعتبره تحديثاً ناجحاً إن فشلت كل المصادر (لا إنترنت مثلاً)، فيظهر وقت آخر تحديث حقيقي ويُعاد المحاولة
        if (fetched.isNotEmpty()) lastRefresh = now
        merged
    }
}
