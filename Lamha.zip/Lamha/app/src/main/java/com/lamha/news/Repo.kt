package com.lamha.news

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Repo(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("lamha", Context.MODE_PRIVATE)
    private val file = File(ctx.filesDir, "cache.json")

    var interests: Set<String>
        get() = prefs.getStringSet("interests", emptySet())!!.toSet()
        set(v) = prefs.edit().putStringSet("interests", v).apply()

    var onboarded: Boolean
        get() = prefs.getBoolean("onboarded", false)
        set(v) = prefs.edit().putBoolean("onboarded", v).apply()

    var lastRefresh: Long
        get() = prefs.getLong("last", 0L)
        set(v) = prefs.edit().putLong("last", v).apply()

    fun loadCache(): List<Article> = try {
        val a = JSONArray(file.readText())
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Article(
                o.getString("id"), o.getString("title"), o.getString("summary"),
                o.optString("image").ifBlank { null },
                o.getString("link"), o.getString("source"), o.getString("category"), o.getLong("time")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun save(list: List<Article>) {
        try {
            val a = JSONArray()
            list.forEach {
                a.put(JSONObject().apply {
                    put("id", it.id); put("title", it.title); put("summary", it.summary)
                    put("image", it.image ?: ""); put("link", it.link); put("source", it.source)
                    put("category", it.category); put("time", it.time)
                })
            }
            file.writeText(a.toString())
        } catch (_: Exception) {
        }
    }

    suspend fun refresh(interests: Set<String>): List<Article> = withContext(Dispatchers.IO) {
        val fetched = coroutineScope {
            SOURCES.filter { it.category in interests }
                .map { s -> async { runCatching { Rss.fetch(s) }.getOrDefault(emptyList()) } }
                .awaitAll().flatten()
        }
        val now = System.currentTimeMillis()
        val merged = (fetched + loadCache())
            .distinctBy { it.link }
            .filter { now - it.time < 3 * 24 * 3600_000L }
            .groupBy { it.category + "|" + it.source }
            .values.flatMap { g -> g.sortedByDescending { it.time }.take(20) }
            .sortedByDescending { it.time }
            .take(300)
        save(merged)
        lastRefresh = now
        merged
    }
}
