package com.lamha.news

object BuildInfo {
    const val VERSION = "0.45-فحص"
}
