package com.lamha.news

object BuildInfo {
    const val VERSION = "0.49-فلترة"
}
