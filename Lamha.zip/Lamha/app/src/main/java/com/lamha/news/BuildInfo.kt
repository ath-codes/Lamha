package com.lamha.news

object BuildInfo {
    const val VERSION = "0.48-فحص"
}
