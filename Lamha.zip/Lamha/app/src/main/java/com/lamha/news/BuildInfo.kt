package com.lamha.news

object BuildInfo {
    const val VERSION = "0.44-فحص"
}
