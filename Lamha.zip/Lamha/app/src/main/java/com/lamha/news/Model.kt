package com.lamha.news

data class Category(val id: String, val label: String, val emoji: String)
// fallback: رابط بديل يُجرَّب تلقائياً إذا لم يعطِ الرابط الأصلي أي أخبار
data class Source(val name: String, val url: String, val category: String, val fallback: String? = null)
// نتيجة فحص مصدر: عدد الأخبار، وهل جاءت من الرابط البديل
data class Health(val count: Int, val viaFallback: Boolean)
data class Article(
    val id: String,
    val title: String,
    val summary: String,
    val link: String,
    val source: String,
    val category: String,
    val time: Long
)
