package com.lamha.news

data class Category(val id: String, val label: String, val emoji: String)
data class Source(val name: String, val url: String, val category: String, val lang: String = "ar")
data class Article(
    val id: String,
    val title: String,
    val summary: String,
    val link: String,
    val source: String,
    val category: String,
    val time: Long,
    val lang: String = "ar"
)
