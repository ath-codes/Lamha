package com.lamha.news

data class Category(val id: String, val label: String, val emoji: String)
// fallback: رابط بديل يُجرَّب تلقائياً إذا لم يعطِ الرابط الأصلي أي أخبار
// broad: موقع عام (كل أخبار الموقع لا قسم واحد): يُفلتر بالكلمات الدالة كمصادر بحث Google
data class Source(
    val name: String, val url: String, val category: String,
    val fallback: String? = null, val broad: Boolean = false,
    // focused: موقع متخصص كله في تصنيفه (اقتصاد مثلاً): لا يُفلتر بالكلمات الدالة
    val focused: Boolean = false
)
// نتيجة فحص مصدر: عدد الأخبار، وهل جاءت من الرابط البديل
// notes: ما جرى في كل محاولة (رمز الخادم أو فارغ)، sample: عنوان خبر نموذجي. للتقرير المنسوخ
// feedItems/feedFull/feedMax: كم خبراً في الخلاصة، وكم منها يحمل نصاً كاملاً (600 حرف فأكثر)، وأطول نص (لا تُحسب خلاصات Google)
data class Health(
    val count: Int, val viaFallback: Boolean, val notes: String = "", val sample: String = "", val ms: Long = 0,
    val feedItems: Int = 0, val feedFull: Int = 0, val feedMax: Int = 0, val newest: Long = 0
)
class Probe(
    val articles: List<Article>, val viaFallback: Boolean, val notes: String, val ms: Long = 0,
    val feedItems: Int = 0, val feedFull: Int = 0, val feedMax: Int = 0
)
data class Article(
    val id: String,
    val title: String,
    val summary: String,
    val link: String,
    val source: String,
    val category: String,
    val time: Long
)

// سعر الدولار بالجنيه: السعر الحالي، وسعر اليوم السابق (0 إن لم يتوفر بعد)، ووقت آخر جلب
// qar/qarPrev: سعر الريال القطري بالجنيه وسعر اليوم السابق (0 إن لم يتوفر)
data class Usd(val rate: Double, val prev: Double, val fetched: Long, val qar: Double = 0.0, val qarPrev: Double = 0.0)
