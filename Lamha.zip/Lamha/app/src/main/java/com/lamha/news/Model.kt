package com.lamha.news

data class Category(val id: String, val label: String, val emoji: String)
// fallback: رابط بديل يُجرَّب تلقائياً إذا لم يعطِ الرابط الأصلي أي أخبار
data class Source(val name: String, val url: String, val category: String, val fallback: String? = null)
// نتيجة فحص مصدر: عدد الأخبار، وهل جاءت من الرابط البديل
data class Health(val count: Int, val viaFallback: Boolean)
data class Article(
    val id: String,
    val title: String,
    val summary: String,
    val link: String,
    val source: String,
    val category: String,
    val time: Long
)

// سعر الدولار بالجنيه: السعر الحالي، وسعر اليوم السابق (0 إن لم يتوفر بعد)، ووقت آخر جلب
data class Usd(val rate: Double, val prev: Double, val fetched: Long)
