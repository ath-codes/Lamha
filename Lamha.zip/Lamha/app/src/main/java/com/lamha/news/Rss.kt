package com.lamha.news

import android.text.Html
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

object Rss {
    private const val UA = "Mozilla/5.0 (Linux; Android 14) Lamha/1.0"
    private val SPACES = Regex("\\s+")
    private val DATE_FORMATS = listOf(
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "EEE, dd MMM yyyy HH:mm:ss zzz",
        "dd MMM yyyy HH:mm:ss Z",
        "yyyy-MM-dd'T'HH:mm:ssXXX",
        "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
    )

    fun https(u: String) = if (u.startsWith("http://")) "https://" + u.substring(7) else u

    fun fetch(src: Source): List<Article> = fetchInfo(src).first

    // يرجع الأخبار + هل جاءت من الرابط البديل (لشاشة فحص المصادر)
    fun fetchInfo(src: Source): Pair<List<Article>, Boolean> {
        var a = try { get(src.url, src) } catch (_: Exception) { emptyList() }
        if (a.isEmpty()) a = try { get(src.url, src, BROWSER_UA) } catch (_: Exception) { emptyList() }
        val fb = src.fallback
        // الخلاصة الأصلية قد تعطي أسماء صفحات لاتينية بدل العناوين (مركز المستقبل: ArticalDetails_Ar): نجرّب البديل
        if (fb == null || (a.isNotEmpty() && !mostlyPageNames(a))) return a to false
        val b = try { get(fb, src) } catch (_: Exception) { emptyList() }
        return if (b.isNotEmpty()) b to true else a to false
    }

    private val PAGE_NAME = Regex("^[A-Za-z0-9_\\-]+$")

    /** نصف العناوين أو أكثر أسماء صفحات لاتينية: الخلاصة لا تصلح للعرض */
    private fun mostlyPageNames(l: List<Article>) =
        l.isNotEmpty() && l.count { PAGE_NAME.matches(it.title.trim()) } * 2 >= l.size

    /** فحص مفصّل لشاشة فحص المصادر: نتيجة كل محاولة (الأصلي، بترويسة متصفح، البديل) */
    fun probe(src: Source): Probe {
        val notes = ArrayList<String>()
        var timedOut = false
        val t0 = System.currentTimeMillis()
        var shown = IntArray(3) // إحصاء نص الخلاصة لآخر محاولة أعطت أخباراً
        // زمن كل محاولة بالمللي ثانية يُلحق بالملاحظة (يشمل الاتصال والقراءة والتحليل)
        fun attempt(label: String, url: String, ua: String): List<Article> {
            val t = System.currentTimeMillis()
            return try {
                val st = IntArray(3)
                val (l, n) = getDiag(url, src, ua, st, "diag")
                if (l.isNotEmpty()) shown = st
                notes.add("$label: $n (${System.currentTimeMillis() - t}ms)")
                l
            } catch (e: Exception) {
                if (e is java.net.SocketTimeoutException) timedOut = true
                notes.add("$label: خطأ ${e.javaClass.simpleName} (${System.currentTimeMillis() - t}ms)")
                emptyList()
            }
        }
        fun done(l: List<Article>, via: Boolean) = Probe(l, via, notes.joinToString("؛ "), System.currentTimeMillis() - t0, if (l.isEmpty()) 0 else shown[0], shown[1], shown[2])
        var a = attempt("الأصلي", src.url, UA)
        // المهلة تعني أن الخادم بطيء لا أنه يرفض الترويسة، فلا نكرر المحاولة (توفّر 8 ثوانٍ) وننتقل للبديل
        if (a.isEmpty() && !timedOut) a = attempt("الأصلي بترويسة متصفح", src.url, BROWSER_UA)
        val fb = src.fallback
        if (fb == null || (a.isNotEmpty() && !mostlyPageNames(a))) return done(a, false)
        if (a.isNotEmpty()) notes.add("عناوين الأصلي أسماء صفحات لاتينية، جرّبنا البديل")
        val b = attempt("البديل", fb, UA)
        return if (b.isNotEmpty()) done(b, true) else done(a, false)
    }

    private const val BROWSER_UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    private fun get(url: String, src: Source, ua: String = UA): List<Article> = getDiag(url, src, ua).first

    // يرجع الأخبار مع وصف قصير للنتيجة (رمز الخادم أو "بلا أخبار")
    // stat (اختياري): [عدد الأخبار، ما فيه نص كامل، أطول نص] لخلاصات غير Google. bucket: نوع الاستهلاك في NetStats
    private fun getDiag(url: String, src: Source, ua: String = UA, stat: IntArray? = null, bucket: String = "feed"): Pair<List<Article>, String> {
        val c = URL(https(url)).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*")
        try {
            val code = c.responseCode
            if (code != 200) return emptyList<Article>() to "HTTP $code"
            val list = c.inputStream.use { raw ->
                val cs = CountingStream(raw)
                val r = parse(cs, src, url.contains("news.google.com"), stat)
                NetStats.add(bucket, cs.count)
                r
            }
            return list to (if (list.isEmpty()) "رد 200 لكن بلا أخبار (ربما ليست خلاصة RSS)" else "${list.size} خبر")
        } finally {
            c.disconnect()
        }
    }

    // يقرأ نص الوسم الحالي حتى نهايته، ويتجاوز أي وسوم داخلية (بدل nextText الذي يرمي خطأ معها)
    private fun text(p: XmlPullParser): String {
        val sb = StringBuilder()
        var depth = 1
        while (depth > 0) {
            when (p.next()) {
                XmlPullParser.TEXT, XmlPullParser.CDSECT -> sb.append(p.text)
                XmlPullParser.START_TAG -> depth++
                XmlPullParser.END_TAG -> depth--
                XmlPullParser.END_DOCUMENT -> return sb.toString()
            }
        }
        return sb.toString()
    }

    private fun parseDate(s: String): Long {
        val t = s.trim()
        for (f in DATE_FORMATS) {
            try {
                return SimpleDateFormat(f, Locale.ENGLISH).parse(t)!!.time
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    // بعض الخلاصات تضع المقال كاملاً في الوصف؛ نقص الخام قبل التحويل لأن Html.fromHtml بطيء مع النصوص الطويلة
    private const val MAX_RAW = 2500

    private fun clean(raw: String): String {
        if (raw.isBlank()) return ""
        val s = if (raw.length > MAX_RAW) raw.substring(0, MAX_RAW) else raw
        return Html.fromHtml(s, Html.FROM_HTML_MODE_COMPACT).toString()
            .replace('\uFFFC', ' ').replace(SPACES, " ").trim()
    }

    private val SEP = Regex("\\s[-|\u2013\u2014]\\s")

    /**
     * عناوين Google News تنتهي بـ " - اسم الناشر"، وبعض المواقع تضع اسمها ووصفها أيضاً في عنوانها فتتكرر اللواحق.
     * نحذف آخر قطعة دائماً، ثم نحذف القطع السابقة ما دامت تحوي اسم الناشر أو اسم مصدرنا، ونُبقي بداية العنوان دائماً
     */
    internal fun stripPublisher(title: String, vararg names: String): String {
        val keys = names.map { Arabic.clean(it) }.filter { it.length >= 3 }
        var t = title
        val i = t.lastIndexOf(" - ")
        if (i > 0) t = t.substring(0, i)
        while (true) {
            val m = SEP.findAll(t).lastOrNull() ?: break
            val head = t.substring(0, m.range.first)
            val seg = Arabic.clean(t.substring(m.range.last + 1))
            if (head.trim().split(' ').size < 2 || seg.length < 3) break
            if (keys.none { seg.contains(it) || it.contains(seg) }) break
            t = head
        }
        return t.trim()
    }

    private fun shorten(s: String, max: Int): String {
        if (s.length <= max) return s
        val cut = s.substring(0, max)
        val i = cut.lastIndexOf(' ')
        val base = if (i > max / 2) cut.substring(0, i) else cut
        return base.trimEnd('،', ',', '.', ' ', ':') + "…"
    }

    private class CountingStream(s: InputStream) : FilterInputStream(s) {
        var count = 0L
        override fun read(): Int { val b = super.read(); if (b >= 0) count++; return b }
        override fun read(b: ByteArray, off: Int, len: Int): Int { val n = super.read(b, off, len); if (n > 0) count += n; return n }
    }

    private val TAGS = Regex("<[^>]*>")
    private const val FULL_TEXT = 600 // نص الخبر في الخلاصة بهذا الطول فأكثر = خبر كامل لا ملخص

    private fun parse(input: InputStream, src: Source, gnews: Boolean, stat: IntArray? = null): List<Article> {
        val out = ArrayList<Article>()
        try {
            val p = Xml.newPullParser()
            p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            try {
                p.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true)
            } catch (_: Exception) {
            }
            p.setInput(input, null)
            var inItem = false
            var title = ""; var desc = ""; var content = ""; var link = ""; var pub = ""
            var date = 0L
            var ev = p.eventType
            val limit = if (gnews) 100 else 25
            while (ev != XmlPullParser.END_DOCUMENT && out.size < limit) {
                if (ev == XmlPullParser.START_TAG) {
                    val n = p.name
                    if (n == "item" || n == "entry") {
                        inItem = true
                        title = ""; desc = ""; content = ""; link = ""; pub = ""; date = 0L
                    } else if (inItem) {
                        when (n) {
                            // اسم الناشر كما يرسله Google News: نستعمله لتنظيف لاحقة العنوان فقط
                            "source" -> pub = text(p)
                            // عناصر لا نحتاجها وقد تحوي title/link داخلها
                            "author", "image" -> text(p)
                            "title" -> title = text(p)
                            "link" -> {
                                val h = p.getAttributeValue(null, "href")
                                val rel = p.getAttributeValue(null, "rel")
                                val t = text(p)
                                // في Atom نتجاهل روابط self/enclosure/replies ونأخذ رابط الخبر نفسه
                                val ok = rel == null || rel == "alternate"
                                if (ok && link.isBlank()) link = if (!h.isNullOrBlank()) h else t.trim()
                            }
                            "description", "summary" -> desc = text(p)
                            "content:encoded", "content" -> content = text(p)
                            "pubDate", "published", "updated", "dc:date" -> {
                                val d = parseDate(text(p))
                                if (d > 0 && date == 0L) date = d
                            }
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG && (p.name == "item" || p.name == "entry") && inItem) {
                    inItem = false
                    val t = clean(title).let { if (gnews) stripPublisher(it, src.name, clean(pub)) else it }
                    if (t.isNotBlank() && link.isNotBlank()) {
                        if (stat != null && !gnews) {
                            val fl = maxOf(content.replace(TAGS, "").trim().length, desc.replace(TAGS, "").trim().length)
                            stat[0]++
                            if (fl >= FULL_TEXT) stat[1]++
                            if (fl > stat[2]) stat[2] = fl
                        }
                        var s = clean(if (desc.isNotBlank()) desc else content)
                        if (s == t || gnews) s = ""
                        out.add(
                            Article(
                                id = link,
                                title = t,
                                summary = shorten(s, 240),
                                link = https(link.trim()),
                                source = src.name,
                                category = src.category,
                                time = if (date > 0) date else System.currentTimeMillis() - out.size * 60_000L
                            )
                        )
                    }
                }
                ev = p.next()
            }
        } catch (_: Exception) {
            // نرجع ما تم تحليله حتى الآن
        }
        return if (gnews) out.sortedByDescending { it.time }.take(25) else out
    }
}
