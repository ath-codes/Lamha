package com.lamha.news

import android.content.Context
import java.util.concurrent.ConcurrentHashMap

/**
 * جودة وصلة الأخبار بالتصنيف، بكلمات دالة (بلا ذكاء اصطناعي):
 * - يستبعد "العناوين الفارغة" (اسم كاتب أو قسم فقط، بلا ملخص).
 * - في تصنيف السياسة: يستبعد ما فيه كلمات رياضة/فن/حوادث/طقس ولا كلمة سياسية، وفي مصادر "بحث Google" (تجلب كل أخبار الموقع) يشترط وجود كلمة سياسية.
 * - في الاقتصاد: الشيء نفسه بكلمات اقتصادية.
 * - يعطي وزناً لأهمية الخبر (للترتيب): قوة المصدر وكلمات الأحداث الكبرى.
 * لتعديل القوائم: POL وECO وOFFTOPIC وHEAVY وSTRONG فقط.
 */
object Quality {
    private val POL = Lex(
        listOf(
            "رئيس", "رئاسة", "رئاسي", "وزير", "وزراء", "وزارة", "حكومة", "برلمان", "نواب", "نائب", "شيوخ",
            "انتخابات", "انتخابي", "ناخب", "حزب", "أحزاب", "سياسة", "سياسي", "سياسية", "دبلوماسي", "سفير", "خارجية",
            "دفاع", "جيش", "عسكري", "عسكرية", "حرب", "حروب", "هجوم", "هجمات", "غارات", "غارة", "قصف", "صواريخ",
            "صاروخ", "مسيرة", "مسيرات", "هدنة", "مفاوضات", "محادثات", "اتفاق", "اتفاقية", "معاهدة", "عقوبات",
            "قمة", "زيارة", "تصعيد", "توتر", "أزمة", "نزاع", "صراع", "احتلال", "استيطان", "لاجئين", "مهاجرين",
            "جمهوري", "دستور", "دستوري", "تشريع", "ملك", "أمير", "سلطان", "معارضة", "تظاهرات", "احتجاجات",
            "سيسي", "مدبولي"
        ),
        listOf("وقف إطلاق", "ولي العهد", "مجلس الوزراء", "مجلس النواب", "مجلس الشيوخ", "الحوار الوطني")
    )

    private val ECO = Lex(
        listOf(
            "اقتصاد", "اقتصادي", "اقتصادية", "سعر", "أسعار", "بورصة", "أسهم", "سهم", "دولار", "جنيه", "ريال", "درهم",
            "ذهب", "فضة", "نفط", "بترول", "خام", "برنت", "غاز", "طاقة", "بنك", "بنوك", "فائدة", "فوائد", "تضخم",
            "استثمار", "استثمارات", "مستثمر", "صادرات", "واردات", "موازنة", "ميزانية", "دين", "ديون", "قرض", "قروض",
            "احتياطي", "عجز", "نمو", "ناتج", "تجارة", "تجاري", "ضرائب", "ضريبة", "جمارك", "عملة", "عملات", "تمويل",
            "شركة", "شركات", "صناعة", "صناعي", "سوق", "أسواق", "أرباح", "خسائر", "إيرادات", "مبيعات", "رواتب",
            "أجور", "مرتبات", "مالية", "معاشات", "دعم", "تموين", "سلع", "عقارات", "عقار", "أسمنت", "حديد", "سياحة", "سياحي", "مليار"
        ),
        listOf("صندوق النقد", "البنك المركزي", "البنك الدولي")
    )

    // رياضة، فن، حوادث وجرائم، طقس، حياة اجتماعية: لا تنتمي للسياسة ولا للاقتصاد
    private val OFFTOPIC = Lex(
        listOf(
            "مباراة", "مباريات", "دوري", "كأس", "لاعب", "لاعبين", "لاعبة", "مدرب", "منتخب", "ملعب", "كرة", "جول",
            "ركلة", "برشلونة", "ليفربول", "أرسنال", "بطولة", "بطولات", "تنس",
            "فنان", "فنانة", "فنانين", "مسلسل", "مسلسلات", "فيلم", "أفلام", "مهرجان", "حفل", "أغنية", "مطرب",
            "ممثل", "ممثلة", "نجمة", "دراما", "سينما", "سينمائي", "مذيعة",
            "حادث", "حوادث", "مصرع", "جريمة", "جرائم", "تصادم", "حريق", "غرق", "سرقة", "مخدرات", "طعن", "جثة",
            "طقس", "أمطار", "شبورة", "أبراج", "برج", "وصفة", "رجيم", "دعاء", "إفطار", "طلاق", "زواج", "عروس", "زوجة", "أعراض"
        ),
        listOf("ريال مدريد", "كأس العالم")
    )

    // كلمات الأحداث الكبرى (ترفع ترتيب الخبر)
    private val HEAVY = Lex(
        listOf(
            "حرب", "هجوم", "غارات", "قصف", "انفجار", "زلزال", "اغتيال", "هدنة", "قمة", "عقوبات", "انتخابات",
            "استقالة", "اتفاق", "رئيس", "تضخم", "فائدة", "بورصة", "نفط", "دولار", "ذهب"
        ),
        listOf("وقف إطلاق", "صندوق النقد", "البنك المركزي", "سعر الفائدة")
    )

    // مصادر أقوى (وكالات وقنوات وصحف كبرى) تزيد وزن الخبر عند الترتيب
    private val STRONG = setOf(
        "BBC عربي", "سكاي نيوز عربية", "فرانس 24", "CNN بالعربية", "الجزيرة نت", "الجزيرة عاجل", "DW عربية", "RFI عربية",
        "الشرق الأوسط", "أ ش أ (وكالة أنباء الشرق الأوسط)", "الأهرام", "الشرق للأخبار", "العربية عاجل",
        "CNN اقتصاد", "الشرق بلومبرغ", "CNBC عربية", "يورونيوز"
    )

    // مصادر تُجلب عبر بحث أخبار Google: تأتي بكل أخبار الموقع لا بقسم واحد
    private val BROAD: Set<String> =
        SOURCES.filter { (it.url.contains("news.google.com") || it.broad) && !it.focused }.map { it.category + "|" + it.name }.toSet()

    private val cache = ConcurrentHashMap<String, Boolean>()

    fun keep(a: Article): Boolean = cache.getOrPut(a.link) { why(a) == null }

    /** سبب استبعاد الخبر من العرض، أو null إن بقي */
    fun why(a: Article): String? {
        if (isVideo(a)) return "حلقة أو فيديو"
        val t = a.title + " " + a.summary
        val words = a.title.trim().split(Regex("\\s+")).size
        val topical = POL.any(t) || ECO.any(t) || Locality.FOREIGN.any(t)
        // اسم كاتب أو قسم فقط: عنوان قصير بلا ملخص ولا كلمة دالة
        if (a.category == "analysis") {
            // التحليلات: العناوين القصيرة مشروعة (كتاب، مقال)، فلا نطبّق قاعدة الطول. نستبعد فقط أسماء الصفحات اللاتينية مثل ArticalDetails_Ar
            if (Regex("^[A-Za-z0-9_\\-]+$").matches(a.title.trim())) return "عنوان لاتيني (اسم صفحة)"
        } else if (words <= 1 || (words <= 3 && a.summary.length < 40 && !topical)) return "عنوان فارغ أو قصير"
        val broad = (a.category + "|" + a.source) in BROAD
        val off = OFFTOPIC.any(t)
        when (a.category) {
            "politics" -> {
                val pol = POL.any(t)
                // رياضة أو فن أو حوادث بلا كلمة سياسية صريحة تُستبعد حتى لو ذُكرت دولة (مباراة فرنسا وتركيا)
                if (!pol && off) return "السياسة: رياضة/فن/حوادث بلا كلمة سياسية"
                if (!pol && broad && !Locality.FOREIGN.any(t)) return "السياسة: مصدر عام بلا كلمة سياسية"
            }
            "economy" -> {
                if (!ECO.any(t) && (off || broad)) return "الاقتصاد: بلا كلمة اقتصادية"
            }
        }
        return null
    }

    // ---------- حلقات الفيديو والبرامج المصوّرة: تُحذف من القائمة كلياً (لا نص خبر فيها) ----------
    private val VIDEO_PATH = Regex("(?i)/(videos?|vid|vod|tv-shows?|emissions?|programmes?)(/|$|\\?)")
    private val VIDEO_TITLE = Regex("^(فيديو|بالفيديو)\\s*[:：|\\-–—]|[|\\-–—:]\\s*(فيديو|بالفيديو)\\s*$|[(\\[]\\s*(فيديو|بالفيديو)\\s*[)\\]]")
    private val VIDEO_SUMMARY = listOf("تستعرض هذه الحلقة", "تستعرض هذه النشرة", "لعرض هذا المحتوى من اليوتيوب")
    // عناوين حلقات اكتُشفت عند القراءة (صفحة فهرس أو مشغّل فيديو بلا نص خبر)، محفوظة على الجهاز
    private val videoTitles = LinkedHashSet<String>()
    private fun nt(t: String) = t.trim().replace(Regex("\\s+"), " ")
    private fun vprefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("lamha_reader", Context.MODE_PRIVATE)

    fun warm(ctx: Context) {
        val saved = (vprefs(ctx).getString("videoTitles", "") ?: "").split('\n').filter { it.isNotEmpty() }
        synchronized(videoTitles) { videoTitles.addAll(saved) }
        cache.clear()
    }

    /** يُستدعى من وضع القراءة حين تتبيّن أن الصفحة حلقة فيديو: تختفي من القائمة عند أول إعادة عرض */
    fun markVideo(ctx: Context, title: String) {
        val snap = synchronized(videoTitles) {
            if (!videoTitles.add(nt(title))) return
            videoTitles.toList().takeLast(300)
        }
        cache.clear()
        try { vprefs(ctx).edit().putString("videoTitles", snap.joinToString("\n")).apply() } catch (_: Exception) {}
    }

    fun isVideo(a: Article): Boolean {
        if (VIDEO_PATH.containsMatchIn(a.link)) return true
        if (VIDEO_TITLE.containsMatchIn(a.title.trim())) return true
        if (VIDEO_SUMMARY.any { a.summary.contains(it) }) return true
        return synchronized(videoTitles) { nt(a.title) in videoTitles }
    }

    /** تقرير الفلترة: كم خبراً بقي وكم استُبعد ولماذا، مع أمثلة لكل سبب لتعديل القوائم من أمثلة حقيقية */
    fun report(list: List<Article>): String {
        val drops = LinkedHashMap<String, MutableList<Article>>()
        var kept = 0
        for (a in list) {
            val r = why(a)
            if (r == null) kept++ else drops.getOrPut(r) { ArrayList() }.add(a)
        }
        val sb = StringBuilder("تقرير فلترة الأخبار (لمحة)\n")
        sb.append("الأخبار المحفوظة: ").append(list.size).append("، بقي: ").append(kept).append("، استُبعد: ").append(list.size - kept).append('\n')
        for ((r, l) in drops.entries.sortedByDescending { it.value.size }) {
            sb.append("\n• ").append(r).append(": ").append(l.size).append('\n')
            for (a in l.take(5)) sb.append("   ").append(a.source).append(": ").append(a.title.take(70)).append('\n')
        }
        return sb.toString()
    }

    // نشرات دورية: "أسعار السمك اليوم"، "سعر الدولار اليوم الاثنين 16 نوفمبر"... تُنشر يومياً بقالب ثابت من عشرات المواقع.
    // شرطها: كلمة سعر/أسعار/عيار + تاريخ صريح أو "اليوم" بعد "سعر X"، وليس فيها لغة قرار (رفع، لجنة، وزير...)
    // فالخبر الحقيقي مثل "الحكومة ترفع أسعار البنزين اليوم الجمعة" لا يُعدّ نشرة. للتعديل: PRICE وNEWSY
    private val PRICE = Lex(listOf("سعر", "أسعار", "عيار"))
    private val NEWSY = Lex(
        listOf(
            "قرار", "قرارات", "رسميا", "رفع", "ترفع", "يرفع", "خفض", "تخفض", "يخفض", "لجنة", "مجلس", "وزير", "وزراء",
            "حكومة", "رئيس", "تعلن", "يعلن", "إعلان", "تقرر", "يقرر", "تثبيت", "يثبت", "تثبت"
        )
    )
    private val routineCache = ConcurrentHashMap<String, Boolean>()

    fun isRoutine(a: Article): Boolean = routineCache.getOrPut(a.link) {
        val t = a.title
        !NEWSY.any(t) && PRICE.any(t) && (Stories.isStamped(t) || Stories.isTodayPrice(t))
    }

    fun sourceWeight(name: String): Double = if (name in STRONG) 1.5 else 1.0

    fun heavyHits(a: Article): Int = minOf(HEAVY.hits(a.title + " " + a.summary), 3)
}
