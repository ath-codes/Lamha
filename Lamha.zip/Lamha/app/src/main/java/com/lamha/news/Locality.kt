package com.lamha.news

import java.util.concurrent.ConcurrentHashMap

/**
 * هل الخبر عن مصر؟ يُحكم بمحتوى الخبر (العنوان + الملخص) لا بمصدره، بكلمات دالة على مصر (بلا ذكاء اصطناعي).
 * أي خبر لا يذكر شيئاً منها يُعدّ من أخبار العالم. لتعديل القائمة عدّل WORDS وPHRASES فقط.
 */
object Locality {
    private val DIACRITICS = Regex("[\\u064B-\\u065F\\u0670\\u0640]")
    private val NON_WORD = Regex("[^\\p{L}\\p{N}\\s]")
    private val SPACES = Regex("\\s+")

    private fun norm(s: String): String = s
        .replace(DIACRITICS, "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ة', 'ه')
        .lowercase()

    // كلمات مفردة (بدون "ال" التعريف؛ تُقارن بعد حذفها وحذف الحروف الملتصقة مثل و/ب/ل)
    private val WORDS: Set<String> = listOf(
        "مصر", "مصري", "مصرية", "مصريين", "مصريون", "مصريات",
        "قاهرة", "جيزة", "إسكندرية", "أقصر", "أسوان", "أسيوط", "منيا", "سوهاج", "قنا", "دقهلية",
        "منوفية", "قليوبية", "سويس", "إسماعيلية", "دمياط", "فيوم", "مطروح", "سيناء", "حلوان", "شبرا",
        "بورسعيد", "صعيد", "غردقة", "علمين",
        "سيسي", "مدبولي", "أزهر", "زمالك", "بيراميدز", "فراعنة"
    ).map { norm(it) }.toSet()

    // عبارات من أكثر من كلمة (تُطابق كما هي)
    private val PHRASES: List<String> = listOf(
        "كفر الشيخ", "بني سويف", "شرم الشيخ", "بور سعيد", "شمال سيناء", "جنوب سيناء",
        "الوادي الجديد", "العاصمة الإدارية", "الساحل الشمالي", "محمد صلاح"
    ).map { norm(it) }

    private val PREFIXES = listOf("وال", "بال", "لل", "ال", "و", "ب", "ل")
    private val cache = ConcurrentHashMap<String, Boolean>()

    fun isEgypt(a: Article): Boolean = cache.getOrPut(a.link) { check(a.title + " " + a.summary) }

    private fun check(raw: String): Boolean {
        val text = norm(raw).replace(NON_WORD, " ").replace(SPACES, " ").trim()
        val padded = " $text "
        if (PHRASES.any { padded.contains(" $it ") }) return true
        for (tok in text.split(' ')) {
            if (tok.length < 3) continue
            if (tok in WORDS) return true
            for (p in PREFIXES) {
                if (tok.startsWith(p) && tok.length - p.length >= 3 && tok.substring(p.length) in WORDS) return true
            }
        }
        return false
    }
}
