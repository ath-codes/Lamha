package com.lamha.news

import android.content.Context

/**
 * الفحص الشامل (نسخة التشخيص): تقرير واحد قابل للنسخ يجمع كل ما نحتاجه لنقرر بالأرقام:
 * 1) الخلاصات: هل تعمل، وكم خبراً فيها يحمل نصاً كاملاً (يصلح بديلاً حين تفشل الصفحة)
 * 2) وضع القراءة: خبران من كل مصدر، وسبب كل فشل مصنّفاً، وهل تنقذه نسخة AMP أو تخفيف شرط العنوان أو نص الخلاصة
 * 3) الفلاتر: ما استُبعد اليوم، وما ستحذفه القواعد المقترحة (بلا تطبيق)، وأنماط الروابط الفاشلة المتكررة
 * 4) الإنترنت: استهلاك كل نشاط، وكلفة الفحص نفسه
 */
object FullDiag {
    private fun classify(i: ReadItem): String {
        val n = i.note
        return when {
            n.contains(Reader.VIDEO_NOTE) -> "فيديو"
            n.contains(Reader.HUB_NOTE) -> "صفحة وسم/قسم"
            n.contains("تعذّر فك رابط Google") -> "رابط Google لم يُفك"
            n.contains("لا يطابق") -> "عنوان لا يطابق"
            n.contains("HTTP 403") || n.contains("HTTP 401") || n.contains("HTTP 406") || n.contains("HTTP 429") || n.contains("يرفض القراءة") -> "حظر (403 وأشباهه)"
            n.contains("HTTP 404") || n.contains("HTTP 410") -> "الصفحة محذوفة"
            n.contains("انتهت المهلة") -> "مهلة المتصفح"
            n.contains("خطأ") || n.contains("Exception") || n.contains("Timeout") -> "خطأ اتصال"
            else -> "لا نص كافٍ / أخرى"
        }
    }

    suspend fun run(
        ctx: Context, repo: Repo, articles: List<Article>, sources: List<Source>, interests: Set<String>,
        progress: (String) -> Unit
    ): String {
        val net0 = NetStats.session()
        val t0 = System.currentTimeMillis()
        val mine = sources.filter { it.category in interests }

        progress("1/3 فحص الخلاصات…")
        val health = repo.test(mine)

        progress("2/3 فحص القراءة (قد يستغرق عدة دقائق)…")
        val arts = articles.filter { it.category in interests && Quality.keep(it) }
        val items = ReadCheck.checkAll(ctx, arts, deep = true, perSource = 2, maxSources = 80) { d, n ->
            progress("2/3 فحص القراءة $d من $n…")
        }

        progress("3/3 تجميع التقرير…")
        val sb = StringBuilder()
        val ok = items.filter { it.ok }
        val bad = items.filter { !it.ok }
        val hOk = mine.count { (health[it.key()]?.count ?: 0) > 0 }
        sb.append("تقرير الفحص الشامل (لمحة ").append(BuildInfo.VERSION).append(")\n")
        sb.append("المدة: ").append((System.currentTimeMillis() - t0) / 1000).append("ث · الأخبار المحمّلة: ").append(articles.size)
            .append(" · بعد الفلتر: ").append(arts.size).append('\n')

        // ---------- أ. ملخص ----------
        sb.append("\n== أ. الملخص ==\n")
        sb.append("الخلاصات تعمل: ").append(hOk).append(" من ").append(mine.size).append('\n')
        sb.append("قراءة الأخبار (نجحت/المفحوصة): ").append(ok.size).append(" من ").append(items.size).append('\n')
        val real = bad.filter { classify(it) != "فيديو" && classify(it) != "صفحة وسم/قسم" }
        val ampSaved = real.count { it.deep?.ampOk == true }
        val looseSaved = real.count { it.deep?.looseOk == true && it.note.contains("لا يطابق") }
        val feedSaved = real.count { i -> mine.any { it.name == i.source && (health[it.key()]?.feedFull ?: 0) > 0 } }
        sb.append("فشل حقيقي (بلا الفيديو والأقسام): ").append(real.size).append('\n')
        sb.append("  • تنقذه نسخة AMP: ").append(ampSaved).append('\n')
        sb.append("  • ينجح لو خُفّف شرط العنوان (فشل بسببه): ").append(looseSaved).append('\n')
        sb.append("  • مصدره يرسل نصاً كاملاً في الخلاصة (يُنقذ بالفكرة 1): ").append(feedSaved).append('\n')
        sb.append("الفشل حسب السبب:\n")
        for ((k, v) in bad.groupBy { classify(it) }.entries.sortedByDescending { it.value.size }) sb.append("  • ").append(k).append(": ").append(v.size).append('\n')
        val fullSources = mine.filter { (health[it.key()]?.feedFull ?: 0) > 0 }
        sb.append("مصادر خلاصتها تحمل نصاً كاملاً: ").append(fullSources.size).append(" من ").append(mine.size).append('\n')

        // ---------- ب. المصادر ----------
        sb.append("\n== ب. كل مصدر ==\n")
        sb.append("الرمز: خ = الخلاصة، ق = القراءة (خبران)، ن = نص الخلاصة الكامل (أخبار/المجموع، أطول نص)\n")
        for (s in mine) {
            val h = health[s.key()]
            val its = items.filter { it.source == s.name }
            sb.append(if ((h?.count ?: 0) > 0) "✓ " else "✗ ").append(s.name)
            sb.append(" | خ: ").append(if ((h?.count ?: 0) > 0) "${h?.count} خبر" else "لا يعمل")
            if (h != null && h.ms > 0) sb.append(" ").append(fmtSecs(h.ms))
            if (h != null && h.feedItems > 0) sb.append(" | ن: ").append(h.feedFull).append('/').append(h.feedItems).append(" (").append(h.feedMax).append(" حرف)")
            else if (s.url.contains("news.google.com")) sb.append(" | ن: غير متاح (Google)")
            if (its.isNotEmpty()) {
                sb.append(" | ق: ").append(its.joinToString(" ") { if (it.ok) "✓${it.chars}" else "✗" })
                for (i in its.filter { !it.ok }) {
                    sb.append("\n    ✗ ").append(classify(i)).append(" [").append(i.where).append("] ").append(i.title.take(45))
                    sb.append("\n      ").append(i.note.take(160))
                    i.deep?.let { sb.append("\n      عميق: ").append(it.text.take(300)) }
                }
            } else sb.append(" | ق: لم يُفحص (لا أخبار محفوظة)")
            if (h != null && (h.count == 0 || h.notes.isNotBlank() && h.count == 0)) sb.append("\n    ").append(h.notes.take(200))
            sb.append('\n')
        }

        // ---------- ج. أنماط الفشل المتكررة (أساس فكرة التعلّم من الفشل) ----------
        sb.append("\n== ج. أنماط الروابط الفاشلة (نطاق/أول جزء) ==\n")
        val pat = real.groupBy { it.where }.entries.sortedByDescending { it.value.size }.take(15)
        if (pat.isEmpty()) sb.append("لا شيء\n")
        for ((w, l) in pat) sb.append("• ").append(w).append(": ").append(l.size).append(" (").append(l.map { classify(it) }.distinct().joinToString("، ")).append(")\n")

        // ---------- د. الفلاتر ----------
        sb.append("\n== د. الفلاتر ==\n")
        sb.append(Quality.report(articles)).append('\n')
        sb.append(Quality.proposedReport(articles)).append('\n')

        // ---------- هـ. الروابط والدمج ----------
        sb.append("== هـ. روابط Google والدمج ==\n")
        val g = articles.filter { GoogleLink.isGoogle(it.link) }
        sb.append("أخبار برابط Google: ").append(g.size).append("، لم تُفك بعد: ").append(g.count { GoogleLink.canonicalOf(it.link) == null }).append('\n')
        Stories.lastStats?.let { sb.append("الدمج: من ${it.items} خبراً صارت ${it.stories} قصة (بالرابط ${it.byLink}، بالعنوان ${it.byTitle})\n") }

        // ---------- و. الإنترنت ----------
        sb.append("\n== و. الإنترنت ==\n")
        sb.append(NetStats.report())
        sb.append("كلفة هذا الفحص نفسه: ").append(NetStats.fmt(NetStats.session() - net0)).append(" (تقريبي)\n")
        sb.append("الجلب المسبق: ").append(if (repo.prefetchAlways) "دائماً" else "واي فاي فقط").append('\n')
        return sb.toString()
    }
}
