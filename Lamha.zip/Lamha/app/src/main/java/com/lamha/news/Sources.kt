package com.lamha.news

val CATEGORIES = listOf(
    Category("politics", "سياسة", "🌍"),
    Category("economy", "اقتصاد", "💹"),
    Category("sports", "رياضة", "⚽"),
    Category("tech", "تقنية", "💻"),
    Category("health", "صحة", "🩺"),
    Category("arts", "فن وثقافة", "🎬"),
)

// أي رابط لا يعمل يتم تجاهله بصمت. تعديل المصادر يتم من هذا الملف فقط.
val SOURCES = listOf(
    // سياسة
    Source("BBC عربي", "https://feeds.bbci.co.uk/arabic/rss.xml", "politics"),
    Source("سكاي نيوز عربية", "https://www.skynewsarabia.com/web/rss", "politics"),
    Source("فرانس 24", "https://www.france24.com/ar/rss", "politics"),
    Source("CNN بالعربية", "https://arabic.cnn.com/api/v1/rss/world/rss.xml", "politics"),
    Source("الجزيرة نت", "https://www.aljazeera.net/aljazeerarss/a7c186be-1baa-4bd4-9d80-a84db769f779/73d0e1b4-532f-45ef-b135-bfdff8b8cab9", "politics"),
    // اقتصاد
    Source("CNN اقتصاد", "https://arabic.cnn.com/api/v1/rss/business/rss.xml", "economy"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=business", "economy"),
    // رياضة
    Source("CNN رياضة", "https://arabic.cnn.com/api/v1/rss/sport/rss.xml", "sports"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=sport", "sports"),
    Source("BBC رياضة", "https://feeds.bbci.co.uk/arabic/sports/rss.xml", "sports"),
    Source("اليوم السابع", "https://www.youm7.com/rss/SectionRss?SectionID=298", "sports"),
    // تقنية
    Source("عالم التقنية", "https://www.tech-wd.com/wd/feed/", "tech"),
    Source("آي تي نيوز", "https://aitnews.com/feed/", "tech"),
    Source("عرب هاردوير", "https://arabhardware.net/feed", "tech"),
    Source("CNN تقنية", "https://arabic.cnn.com/api/v1/rss/scitech/rss.xml", "tech"),
    // صحة
    Source("CNN صحة", "https://arabic.cnn.com/api/v1/rss/health/rss.xml", "health"),
    // فن وثقافة
    Source("CNN ترفيه", "https://arabic.cnn.com/api/v1/rss/entertainment/rss.xml", "arts"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=culture", "arts"),
)
