package com.lamha.news

fun Source.key() = category + "|" + name

val CATEGORIES = listOf(
    Category("politics", "سياسة", "🌍"),
    Category("economy", "اقتصاد", "💹"),
    Category("sports", "رياضة", "⚽"),
    Category("tech", "تقنية", "💻"),
    Category("health", "صحة", "🩺"),
    Category("arts", "فن وثقافة", "🎬"),
)

// بحث أخبار Google عن موقع معيّن (يعمل حتى لو لم يوفر الموقع خلاصة RSS مستقرة)
private fun gn(query: String, gl: String = "EG") =
    "https://news.google.com/rss/search?q=$query+when:1d&hl=ar&gl=$gl&ceid=$gl:ar"

// أي رابط لا يعمل يتم تجاهله بصمت. تعديل المصادر يتم من هذا الملف فقط.
val SOURCES = listOf(
    // سياسة
    Source("BBC عربي", "https://feeds.bbci.co.uk/arabic/rss.xml", "politics"),
    Source("سكاي نيوز عربية", "https://www.skynewsarabia.com/web/rss", "politics"),
    Source("فرانس 24", "https://www.france24.com/ar/rss", "politics", fallback = gn("site:france24.com/ar")),
    Source("CNN بالعربية", "https://arabic.cnn.com/api/v1/rss/world/rss.xml", "politics"),
    Source("روسيا اليوم", "http://arabic.rt.com/rss/", "politics"),
    // هذه المصادر لا تقدم خلاصة مباشرة مستقرة، فتُجلب عبر بحث أخبار Google (الروابط تعيد التوجيه إلى الخبر الأصلي)
    Source("إندبندنت عربية", "https://news.google.com/rss/search?q=site:independentarabia.com+when:1d&hl=ar&gl=SA&ceid=SA:ar", "politics"),
    Source("العربية عاجل", "https://news.google.com/rss/search?q=site:alarabiya.net+%D8%B9%D8%A7%D8%AC%D9%84+when:1d&hl=ar&gl=SA&ceid=SA:ar", "politics"),
    Source("CGTN العربية", "https://news.google.com/rss/search?q=site:arabic.cgtn.com+when:1d&hl=ar&gl=SA&ceid=SA:ar", "politics", fallback = gn("site:arabic.cgtn.com", "US")),
    // الرابط الأصلي صحيح (الخلاصة الرسمية)، لكن إن رفضه الخادم أو رجع فارغاً يُستعمل البديل تلقائياً
    Source(
        "الجزيرة نت",
        "https://www.aljazeera.net/aljazeerarss/a7c186be-1baa-4bd4-9d80-a84db769f779/73d0e1b4-532f-45ef-b135-bfdff8b8cab9",
        "politics",
        fallback = gn("site:aljazeera.net")
    ),
    Source("الجزيرة عاجل", gn("site:aljazeera.net+%D8%B9%D8%A7%D8%AC%D9%84"), "politics"),
    // مصادر مصرية
    Source("اليوم السابع", "https://www.youm7.com/rss/SectionRss?SectionID=319", "politics", fallback = gn("site:youm7.com")),
    Source("أ ش أ (وكالة أنباء الشرق الأوسط)", gn("site:mena.org.eg"), "politics"),
    Source("المصري اليوم", gn("site:almasryalyoum.com"), "politics"),
    Source("الأهرام", gn("site:ahram.org.eg"), "politics"),
    Source("الشروق", gn("site:shorouknews.com"), "politics"),
    Source("مصراوي", gn("site:masrawy.com"), "politics"),
    // مصادر دولية وعربية إضافية (كلها بالعربية). لكل منها بديل عبر بحث أخبار Google إن رفض الخادم الخلاصة
    Source("DW عربية", "https://rss.dw.com/xml/rss-ar-all", "politics", fallback = gn("site:dw.com/ar")),
    Source("RFI عربية", "https://www.rfi.fr/ar/rss", "politics", fallback = gn("site:rfi.fr/ar")),
    Source("الشرق الأوسط", "https://aawsat.com/feed", "politics", fallback = gn("site:aawsat.com")),
    Source("أخبار الأمم المتحدة", "https://news.un.org/feed/subscribe/ar/news/all/rss.xml", "politics", fallback = gn("site:news.un.org/ar")),
    Source("TRT عربي", gn("site:trtarabi.com"), "politics"),
    Source("العربي الجديد", gn("site:alaraby.co.uk"), "politics"),
    Source("الشرق للأخبار", gn("site:asharq.com"), "politics"),
    Source("الوطن", gn("site:elwatannews.com"), "politics"),
    Source("القاهرة 24", gn("site:cairo24.com"), "politics"),
    // مصادر إضافية بروابط مرشّحة لم تُجرَّب بعد: افحصها من الإعدادات. لكل خلاصة بديل عبر Google، وbroad = موقع عام يُفلتر بالكلمات الدالة
    Source("يورونيوز دولي", "https://arabic.euronews.com/rss?level=theme&name=news", "politics", fallback = gn("site:arabic.euronews.com")),
    Source("شينخوا العربية", "http://arabic.news.cn/rss/world.xml", "politics", fallback = gn("site:arabic.news.cn")),
    Source("إرنا العربية", "https://ar.irna.ir/rss", "politics", fallback = gn("site:ar.irna.ir"), broad = true),
    Source("تسنيم العربية", gn("site:tasnimnews.com/ar"), "politics"),
    Source("القدس العربي", "https://www.alquds.co.uk/feed/", "politics", fallback = gn("site:alquds.co.uk"), broad = true),
    Source("العرب القطرية", "https://alarab.qa/feed", "politics", fallback = gn("site:alarab.qa"), broad = true),
    Source("موقع 24", "https://24.ae/rss", "politics", fallback = gn("site:24.ae"), broad = true),
    Source("اليوم السابع عاجل", "https://www.youm7.com/rss/SectionRss?SectionID=65", "politics", fallback = gn("site:youm7.com+%D8%B9%D8%A7%D8%AC%D9%84"), broad = true),
    Source("اليوم السابع دولي", "https://www.youm7.com/rss/SectionRss?SectionID=286", "politics"),
    // اقتصاد
    Source("CNN اقتصاد", "https://arabic.cnn.com/api/v1/rss/business/rss.xml", "economy"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=business", "economy"),
    Source("اليوم السابع", "https://www.youm7.com/rss/SectionRss?SectionID=297", "economy", fallback = gn("site:youm7.com+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF")),
    Source("الجزيرة نت", gn("site:aljazeera.net/ebusiness"), "economy"),
    Source("المصري اليوم", gn("site:almasryalyoum.com+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF"), "economy"),
    Source("الشرق بلومبرغ", gn("site:asharqbusiness.com"), "economy"),
    Source("CNBC عربية", gn("site:cnbcarabia.com"), "economy"),
    Source("أرقام", gn("site:argaam.com"), "economy"),
    Source("الأهرام", gn("site:ahram.org.eg+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF"), "economy"),
    Source("الشروق", gn("site:shorouknews.com+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF"), "economy"),
    Source("مصراوي", gn("site:masrawy.com+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF"), "economy"),
    Source("إنتربرايز اقتصاد", "https://enterprise.press/ar/feed/", "economy", fallback = gn("site:enterprise.press"), broad = true),
    Source("جريدة البورصة", "https://alborsaanews.com/feed", "economy", fallback = gn("site:alborsaanews.com"), broad = true),
    Source("جريدة المال", "https://almalnews.com/feed/", "economy", fallback = gn("site:almalnews.com"), broad = true),
    Source("الأمم المتحدة اقتصاد", "https://news.un.org/feed/subscribe/ar/news/topic/economic-development/feed/rss.xml", "economy"),
    // رياضة
    Source("CNN رياضة", "https://arabic.cnn.com/api/v1/rss/sport/rss.xml", "sports"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=sport", "sports"),
    Source("BBC رياضة", "https://feeds.bbci.co.uk/arabic/sports/rss.xml", "sports"),
    Source("اليوم السابع", "https://www.youm7.com/rss/SectionRss?SectionID=298", "sports"),
    // تقنية
    Source("عالم التقنية", "https://www.tech-wd.com/wd/feed/", "tech"),
    Source("آي تي نيوز", "https://aitnews.com/feed/", "tech"),
    Source("عرب هاردوير", "https://arabhardware.net/feed", "tech"),
    Source("CNN تقنية", "https://arabic.cnn.com/api/v1/rss/scitech/rss.xml", "tech"),
    // صحة
    Source("CNN صحة", "https://arabic.cnn.com/api/v1/rss/health/rss.xml", "health"),
    // فن وثقافة
    Source("CNN ترفيه", "https://arabic.cnn.com/api/v1/rss/entertainment/rss.xml", "arts"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=culture", "arts"),
)
