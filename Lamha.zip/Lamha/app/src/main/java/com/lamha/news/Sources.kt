package com.lamha.news

fun en(name: String, url: String, cat: String) = Source(name, url, cat, "en")

fun Source.key() = category + "|" + name

val CATEGORIES = listOf(
    Category("politics", "سياسة", "🌍"),
    Category("economy", "اقتصاد", "💹"),
    Category("sports", "رياضة", "⚽"),
    Category("tech", "تقنية", "💻"),
    Category("health", "صحة", "🩺"),
    Category("arts", "فن وثقافة", "🎬"),
)

// أي رابط لا يعمل يتم تجاهله بصمت. تعديل المصادر يتم من هذا الملف فقط.
val SOURCES = listOf(
    // سياسة
    Source("BBC عربي", "https://feeds.bbci.co.uk/arabic/rss.xml", "politics"),
    Source("سكاي نيوز عربية", "https://www.skynewsarabia.com/web/rss", "politics"),
    Source("فرانس 24", "https://www.france24.com/ar/rss", "politics"),
    Source("CNN بالعربية", "https://arabic.cnn.com/api/v1/rss/world/rss.xml", "politics"),
    Source("الجزيرة نت", "https://www.aljazeera.net/aljazeerarss/a7c186be-1baa-4bd4-9d80-a84db769f779/73d0e1b4-532f-45ef-b135-bfdff8b8cab9", "politics"),
    // اقتصاد
    Source("CNN اقتصاد", "https://arabic.cnn.com/api/v1/rss/business/rss.xml", "economy"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=business", "economy"),
    // رياضة
    Source("CNN رياضة", "https://arabic.cnn.com/api/v1/rss/sport/rss.xml", "sports"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=sport", "sports"),
    Source("BBC رياضة", "https://feeds.bbci.co.uk/arabic/sports/rss.xml", "sports"),
    Source("اليوم السابع", "https://www.youm7.com/rss/SectionRss?SectionID=298", "sports"),
    // تقنية
    Source("عالم التقنية", "https://www.tech-wd.com/wd/feed/", "tech"),
    Source("آي تي نيوز", "https://aitnews.com/feed/", "tech"),
    Source("عرب هاردوير", "https://arabhardware.net/feed", "tech"),
    Source("CNN تقنية", "https://arabic.cnn.com/api/v1/rss/scitech/rss.xml", "tech"),
    // صحة
    Source("CNN صحة", "https://arabic.cnn.com/api/v1/rss/health/rss.xml", "health"),
    // فن وثقافة
    Source("CNN ترفيه", "https://arabic.cnn.com/api/v1/rss/entertainment/rss.xml", "arts"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=culture", "arts"),

    // ===== مصادر إنجليزية (تظهر عند تفعيل الأخبار الأجنبية، وتُترجم على الجهاز) =====
    // سياسة / عالم
    en("Reuters", "https://news.google.com/rss/search?q=site:reuters.com+when:1d&hl=en-US&gl=US&ceid=US:en", "politics"),
    en("Associated Press", "https://news.google.com/rss/search?q=site:apnews.com+when:1d&hl=en-US&gl=US&ceid=US:en", "politics"),
    en("BBC News", "https://feeds.bbci.co.uk/news/world/rss.xml", "politics"),
    en("Al Jazeera English", "https://www.aljazeera.com/xml/rss/all.xml", "politics"),
    en("The Guardian", "https://www.theguardian.com/world/rss", "politics"),
    en("The New York Times", "https://rss.nytimes.com/services/xml/rss/nyt/World.xml", "politics"),
    en("Sky News", "https://feeds.skynews.com/feeds/rss/world.xml", "politics"),
    en("DW", "https://rss.dw.com/xml/rss-en-all", "politics"),
    // اقتصاد
    en("Reuters", "https://news.google.com/rss/search?q=site:reuters.com/business+when:1d&hl=en-US&gl=US&ceid=US:en", "economy"),
    en("CNBC", "https://www.cnbc.com/id/10001147/device/rss/rss.html", "economy"),
    en("BBC News", "https://feeds.bbci.co.uk/news/business/rss.xml", "economy"),
    en("The Guardian", "https://www.theguardian.com/business/rss", "economy"),
    en("The New York Times", "https://rss.nytimes.com/services/xml/rss/nyt/Business.xml", "economy"),
    // رياضة
    en("BBC Sport", "https://feeds.bbci.co.uk/sport/rss.xml", "sports"),
    en("ESPN", "https://www.espn.com/espn/rss/news", "sports"),
    en("The Guardian", "https://www.theguardian.com/football/rss", "sports"),
    en("Sky Sports", "https://www.skysports.com/rss/12040", "sports"),
    // تقنية
    en("TechCrunch", "https://techcrunch.com/feed/", "tech"),
    en("The Verge", "https://www.theverge.com/rss/index.xml", "tech"),
    en("BBC News", "https://feeds.bbci.co.uk/news/technology/rss.xml", "tech"),
    en("Ars Technica", "https://feeds.arstechnica.com/arstechnica/index", "tech"),
    en("Wired", "https://www.wired.com/feed/rss", "tech"),
    // صحة
    en("BBC News", "https://feeds.bbci.co.uk/news/health/rss.xml", "health"),
    en("The New York Times", "https://rss.nytimes.com/services/xml/rss/nyt/Health.xml", "health"),
    // فن وثقافة
    en("BBC News", "https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml", "arts"),
    en("The Guardian", "https://www.theguardian.com/culture/rss", "arts"),
    en("Variety", "https://variety.com/feed/", "arts"),
)
