package com.lamha.news

fun Source.key() = category + "|" + name

val CATEGORIES = listOf(
    Category("politics", "سياسة", "🌍"),
    Category("economy", "اقتصاد", "💹"),
    Category("sports", "رياضة", "⚽"),
    Category("tech", "تقنية", "💻"),
    Category("health", "صحة", "🩺"),
    Category("arts", "فن وثقافة", "🎬"),
)

// بحث أخبار Google عن موقع معيّن (يعمل حتى لو لم يوفر الموقع خلاصة RSS مستقرة)
private fun gn(query: String, gl: String = "EG") =
    "https://news.google.com/rss/search?q=$query+when:1d&hl=ar&gl=$gl&ceid=$gl:ar"

// أي رابط لا يعمل يتم تجاهله بصمت. تعديل المصادر يتم من هذا الملف فقط.
val SOURCES = listOf(
    // سياسة
    Source("BBC عربي", "https://feeds.bbci.co.uk/arabic/rss.xml", "politics"),
    Source("سكاي نيوز عربية", "https://www.skynewsarabia.com/web/rss", "politics"),
    Source("فرانس 24", "https://www.france24.com/ar/rss", "politics"),
    Source("CNN بالعربية", "https://arabic.cnn.com/api/v1/rss/world/rss.xml", "politics"),
    Source("روسيا اليوم", "http://arabic.rt.com/rss/", "politics"),
    // هذه المصادر لا تقدم خلاصة مباشرة مستقرة، فتُجلب عبر بحث أخبار Google (الروابط تعيد التوجيه إلى الخبر الأصلي)
    Source("إندبندنت عربية", "https://news.google.com/rss/search?q=site:independentarabia.com+when:1d&hl=ar&gl=SA&ceid=SA:ar", "politics"),
    Source("العربية عاجل", "https://news.google.com/rss/search?q=site:alarabiya.net+%D8%B9%D8%A7%D8%AC%D9%84+when:1d&hl=ar&gl=SA&ceid=SA:ar", "politics"),
    Source("CGTN العربية", "https://news.google.com/rss/search?q=site:arabic.cgtn.com+when:1d&hl=ar&gl=SA&ceid=SA:ar", "politics"),
    // الرابط الأصلي صحيح (الخلاصة الرسمية)، لكن إن رفضه الخادم أو رجع فارغاً يُستعمل البديل تلقائياً
    Source(
        "الجزيرة نت",
        "https://www.aljazeera.net/aljazeerarss/a7c186be-1baa-4bd4-9d80-a84db769f779/73d0e1b4-532f-45ef-b135-bfdff8b8cab9",
        "politics",
        fallback = gn("site:aljazeera.net")
    ),
    Source("الجزيرة عاجل", gn("site:aljazeera.net+%D8%B9%D8%A7%D8%AC%D9%84"), "politics"),
    // مصادر مصرية
    Source("اليوم السابع", "https://www.youm7.com/rss/SectionRss?SectionID=319", "politics", fallback = gn("site:youm7.com")),
    Source("أ ش أ (وكالة أنباء الشرق الأوسط)", gn("site:mena.org.eg"), "politics"),
    Source("المصري اليوم", gn("site:almasryalyoum.com"), "politics"),
    Source("الأهرام", gn("site:ahram.org.eg"), "politics"),
    Source("الشروق", gn("site:shorouknews.com"), "politics"),
    Source("مصراوي", gn("site:masrawy.com"), "politics"),
    // اقتصاد
    Source("CNN اقتصاد", "https://arabic.cnn.com/api/v1/rss/business/rss.xml", "economy"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=business", "economy"),
    Source("اليوم السابع", "https://www.youm7.com/rss/SectionRss?SectionID=297", "economy", fallback = gn("site:youm7.com+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF")),
    Source("الجزيرة نت", gn("site:aljazeera.net/ebusiness"), "economy"),
    Source("المصري اليوم", gn("site:almasryalyoum.com+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF"), "economy"),
    // رياضة
    Source("CNN رياضة", "https://arabic.cnn.com/api/v1/rss/sport/rss.xml", "sports"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=sport", "sports"),
    Source("BBC رياضة", "https://feeds.bbci.co.uk/arabic/sports/rss.xml", "sports"),
    Source("اليوم السابع", "https://www.youm7.com/rss/SectionRss?SectionID=298", "sports"),
    // تقنية
    Source("عالم التقنية", "https://www.tech-wd.com/wd/feed/", "tech"),
    Source("آي تي نيوز", "https://aitnews.com/feed/", "tech"),
    Source("عرب هاردوير", "https://arabhardware.net/feed", "tech"),
    Source("CNN تقنية", "https://arabic.cnn.com/api/v1/rss/scitech/rss.xml", "tech"),
    // صحة
    Source("CNN صحة", "https://arabic.cnn.com/api/v1/rss/health/rss.xml", "health"),
    // فن وثقافة
    Source("CNN ترفيه", "https://arabic.cnn.com/api/v1/rss/entertainment/rss.xml", "arts"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=culture", "arts"),
)
