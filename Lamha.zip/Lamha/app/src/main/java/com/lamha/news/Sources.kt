package com.lamha.news

fun Source.key() = category + "|" + name

val CATEGORIES = listOf(
    Category("politics", "سياسة", "🌍"),
    Category("economy", "اقتصاد", "💹"),
    Category("analysis", "تحليلات", "🔍"),
    Category("sports", "رياضة", "⚽"),
    Category("tech", "تقنية", "💻"),
    Category("health", "صحة", "🩺"),
    Category("arts", "فن وثقافة", "🎬"),
)

// بحث أخبار Google عن موقع معيّن (يعمل حتى لو لم يوفر الموقع خلاصة RSS مستقرة)
// days: نافذة البحث بالأيام (يوم واحد للأخبار، وأسبوع لمراكز الأبحاث لأنها تنشر قليلاً)
private fun gn(query: String, gl: String = "EG", days: Int = 1) =
    "https://news.google.com/rss/search?q=$query+when:${days}d&hl=ar&gl=$gl&ceid=$gl:ar"

/** مدة بقاء الخبر بالأيام: التحليلات أسبوع دائماً، والباقي حسب إعداد المستخدم */
fun keepDays(category: String, retain: Int): Int = if (category == "analysis") 7 else retain

// أي رابط لا يعمل يتم تجاهله بصمت. تعديل المصادر يتم من هذا الملف فقط.
val SOURCES = listOf(
    // سياسة
    Source("BBC عربي", "https://feeds.bbci.co.uk/arabic/rss.xml", "politics"),
    Source("سكاي نيوز عربية", "https://www.skynewsarabia.com/web/rss", "politics"),
    Source("فرانس 24", "https://www.france24.com/ar/rss", "politics", fallback = gn("site:france24.com/ar")),
    Source("CNN بالعربية", "https://arabic.cnn.com/api/v1/rss/world/rss.xml", "politics"),
    Source("روسيا اليوم", "http://arabic.rt.com/rss/", "politics"),
    // هذه المصادر لا تقدم خلاصة مباشرة مستقرة، فتُجلب عبر بحث أخبار Google (الروابط تعيد التوجيه إلى الخبر الأصلي)
    Source("إندبندنت عربية", "https://news.google.com/rss/search?q=site:independentarabia.com+when:1d&hl=ar&gl=SA&ceid=SA:ar", "politics"),
    Source("العربية عاجل", "https://news.google.com/rss/search?q=site:alarabiya.net+%D8%B9%D8%A7%D8%AC%D9%84+when:1d&hl=ar&gl=SA&ceid=SA:ar", "politics"),
    // الرابط الأصلي صحيح (الخلاصة الرسمية)، لكن إن رفضه الخادم أو رجع فارغاً يُستعمل البديل تلقائياً
    Source(
        "الجزيرة نت",
        "https://www.aljazeera.net/aljazeerarss/a7c186be-1baa-4bd4-9d80-a84db769f779/73d0e1b4-532f-45ef-b135-bfdff8b8cab9",
        "politics",
        fallback = gn("site:aljazeera.net")
    ),
    Source("الجزيرة عاجل", gn("site:aljazeera.net+%D8%B9%D8%A7%D8%AC%D9%84"), "politics"),
    // مصادر مصرية
    Source("اليوم السابع", "https://www.youm7.com/rss/SectionRss?SectionID=319", "politics", fallback = gn("site:youm7.com")),
    Source("أ ش أ (وكالة أنباء الشرق الأوسط)", gn("site:mena.org.eg"), "politics"),
    Source("المصري اليوم", gn("site:almasryalyoum.com"), "politics"),
    Source("الأهرام", gn("site:ahram.org.eg"), "politics"),
    Source("الشروق", gn("site:shorouknews.com"), "politics"),
    Source("مصراوي", gn("site:masrawy.com"), "politics"),
    // مصادر دولية وعربية إضافية (كلها بالعربية). لكل منها بديل عبر بحث أخبار Google إن رفض الخادم الخلاصة
    Source("DW عربية", "https://rss.dw.com/xml/rss-ar-all", "politics", fallback = gn("site:dw.com/ar")),
    Source("الشرق الأوسط", "https://aawsat.com/feed", "politics", fallback = gn("site:aawsat.com"), broad = true),
    Source("أخبار الأمم المتحدة", "https://news.un.org/feed/subscribe/ar/news/all/rss.xml", "politics", fallback = gn("site:news.un.org/ar")),
    Source("TRT عربي", gn("site:trtarabi.com"), "politics"),
    Source("العربي الجديد", gn("site:alaraby.co.uk"), "politics"),
    Source("الشرق للأخبار", gn("site:asharq.com"), "politics"),
    Source("الوطن", gn("site:elwatannews.com"), "politics"),
    Source("القاهرة 24", gn("site:cairo24.com"), "politics"),
    // مصادر إضافية بروابط مرشّحة لم تُجرَّب بعد: افحصها من الإعدادات. لكل خلاصة بديل عبر Google، وbroad = موقع عام يُفلتر بالكلمات الدالة
    Source("يورونيوز دولي", "https://arabic.euronews.com/rss?level=theme&name=news", "politics", fallback = gn("site:arabic.euronews.com")),
    Source("شينخوا العربية", gn("site:arabic.news.cn"), "politics"),
    Source("إرنا العربية", "https://ar.irna.ir/rss", "politics", fallback = gn("site:ar.irna.ir"), broad = true),
    Source("القدس العربي", "https://www.alquds.co.uk/feed/", "politics", fallback = gn("site:alquds.co.uk"), broad = true),
    Source("العرب القطرية", gn("site:alarab.qa"), "politics"),
    Source("موقع 24", gn("site:24.ae"), "politics"),
    Source("اليوم السابع عاجل", gn("site:youm7.com+%D8%B9%D8%A7%D8%AC%D9%84"), "politics"),
    Source("اليوم السابع دولي", "https://www.youm7.com/rss/SectionRss?SectionID=286", "politics"),
    // اقتصاد
    Source("CNN اقتصاد", "https://arabic.cnn.com/api/v1/rss/business/rss.xml", "economy"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=business", "economy"),
    Source("اليوم السابع", gn("site:youm7.com+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF"), "economy"),
    Source("الجزيرة نت", gn("site:aljazeera.net/ebusiness"), "economy"),
    Source("المصري اليوم", gn("site:almasryalyoum.com+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF"), "economy"),
    Source("الشرق بلومبرغ", gn("site:asharqbusiness.com"), "economy", focused = true),
    Source("CNBC عربية", gn("site:cnbcarabia.com"), "economy", focused = true),
    Source("أرقام", gn("site:argaam.com"), "economy", focused = true),
    Source("الأهرام", gn("site:ahram.org.eg+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF"), "economy"),
    Source("الشروق", gn("site:shorouknews.com+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF"), "economy"),
    Source("مصراوي", gn("site:masrawy.com+%D8%A7%D9%82%D8%AA%D8%B5%D8%A7%D8%AF"), "economy"),
    Source("جريدة البورصة", "https://alborsaanews.com/feed", "economy", fallback = gn("site:alborsaanews.com"), broad = true),
    Source("جريدة المال", gn("site:almalnews.com"), "economy", focused = true),
    Source("الأمم المتحدة اقتصاد", "https://news.un.org/feed/subscribe/ar/news/topic/economic-development/feed/rss.xml", "economy"),
    // رياضة
    Source("CNN رياضة", "https://arabic.cnn.com/api/v1/rss/sport/rss.xml", "sports"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=sport", "sports"),
    Source("BBC رياضة", "https://feeds.bbci.co.uk/arabic/sports/rss.xml", "sports"),
    Source("اليوم السابع", "https://www.youm7.com/rss/SectionRss?SectionID=298", "sports"),
    // تقنية
    Source("عالم التقنية", "https://www.tech-wd.com/wd/feed/", "tech"),
    Source("آي تي نيوز", "https://aitnews.com/feed/", "tech"),
    Source("عرب هاردوير", "https://arabhardware.net/feed", "tech"),
    Source("CNN تقنية", "https://arabic.cnn.com/api/v1/rss/scitech/rss.xml", "tech"),
    // صحة
    Source("CNN صحة", "https://arabic.cnn.com/api/v1/rss/health/rss.xml", "health"),
    // فن وثقافة
    Source("CNN ترفيه", "https://arabic.cnn.com/api/v1/rss/entertainment/rss.xml", "arts"),
    Source("يورونيوز", "https://arabic.euronews.com/rss?level=theme&name=culture", "arts"),
    // تحليلات: مراكز أبحاث ودوريات (روابط مرشّحة عبر بحث جوجل لأسبوع، تُجرَّب من فحص المصادر). تظهر في تبويبها فقط وتبقى 7 أيام
    Source("المركز العربي للأبحاث", gn("site:dohainstitute.org", days = 7), "analysis"),
    Source("مركز الجزيرة للدراسات", gn("site:studies.aljazeera.net", days = 7), "analysis"),
    Source("مركز الأهرام للدراسات", gn("site:acpss.ahram.org.eg", days = 7), "analysis"),
    Source("مركز المستقبل", "https://futureuae.com/ar/rss", "analysis", fallback = gn("site:futureuae.com", days = 7)),
    Source("المعهد المصري للدراسات", gn("site:eipss-eg.org", days = 7), "analysis"),
    Source("رصانة", gn("site:rasanah-iiis.org", days = 7), "analysis"),
    Source("المجلة", gn("site:majalla.com", days = 7), "analysis"),
    Source("مركز دراسات الوحدة العربية", gn("site:caus.org.lb", days = 7), "analysis"),
    // روابط مباشرة أكّد المستخدم أنها تعمل
    Source("مركز الحضارة للدراسات", "https://hadaracenter.com/feed/", "analysis"),
    Source("المركز المصري للفكر والدراسات", "https://ecss.com.eg/feed/", "analysis"),
    Source("مركز البيان للدراسات", "https://www.bayancenter.org/feed/", "analysis", fallback = gn("site:bayancenter.org", days = 7)),
    Source("العربي الجديد: آراء", "https://www.alaraby.co.uk/rss/opinion", "analysis"),
    Source("تريندز للبحوث", "https://trendsresearch.org/ar/category/economy/feed/", "analysis", fallback = "https://trendsresearch.org/ar/feed/"),
    Source("عربي21: آراء", gn("site:arabi21.com آراء", days = 3), "analysis"),
    Source("مركز الإمارات للدراسات والبحوث", gn("site:ecssr.ae", gl = "AE", days = 7), "analysis"),
)
