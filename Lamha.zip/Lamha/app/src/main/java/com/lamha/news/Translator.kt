package com.lamha.news

import android.content.Context
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Translator {
    private val TAGS = Regex("<[^>]*>")
    private val AGENCY_PREFIX = Regex("^\\(?(Reuters|AP|AFP)\\)?\\s*[-–—:]\\s*", RegexOption.IGNORE_CASE)
    private val SPACES = Regex("\\s+")
    private val SOURCE_SUFFIX = Regex("\\s[-–—|]\\s(Reuters|Associated Press|AP News|BBC News|The Guardian|Sky News)$")
    private val SENTENCE_END = Regex("(?<=[.!?])\\s+(?=[A-Z0-9“\"'‘])")

    private val client by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.ARABIC)
                .build()
        )
    }

    suspend fun ensureModel(): Boolean = try {
        client.downloadModelIfNeeded(DownloadConditions.Builder().requireWifi().build()).await()
        true
    } catch (e: Exception) {
        false
    }

    suspend fun mlkit(text: String): String = client.translate(text).await()

    // تنظيف النص قبل الترجمة: وسوم HTML، بادئات الوكالات، لواحق المصدر، العناوين بحروف كبيرة
    fun clean(raw: String, isTitle: Boolean): String {
        var s = raw.replace(TAGS, " ")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"")
            .replace("&#39;", "'").replace("&#8217;", "’").replace("&lt;", "<").replace("&gt;", ">")
        s = s.replace(AGENCY_PREFIX, "")
        s = s.replace(SPACES, " ").trim()
        if (isTitle) s = s.replace(SOURCE_SUFFIX, "")
        val letters = s.filter { it.isLetter() }
        if (letters.length > 8 && letters.count { it.isUpperCase() } > letters.length * 0.7) {
            s = s.lowercase().replaceFirstChar { it.uppercase() }
        }
        return s
    }

    // الملخص: أول جملتين فقط، وكل جملة تُترجم وحدها (النموذج الصغير يتعثر في الفقرات الطويلة)
    fun sentences(s: String, max: Int): List<String> =
        s.split(SENTENCE_END).map { it.trim() }.filter { it.length > 3 }.take(max)

    class DeeplException(val code: Int) : Exception("DeepL $code")

    suspend fun deepl(key: String, texts: List<String>): List<String> = withContext(Dispatchers.IO) {
        val host = if (key.trim().endsWith(":fx")) "api-free.deepl.com" else "api.deepl.com"
        val c = URL("https://$host/v2/translate").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 8000; c.readTimeout = 12000
            c.doOutput = true
            c.setRequestProperty("Authorization", "DeepL-Auth-Key ${key.trim()}")
            c.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().put("text", JSONArray(texts)).put("source_lang", "EN").put("target_lang", "AR")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (c.responseCode != 200) throw DeeplException(c.responseCode)
            val arr = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("translations")
            (0 until arr.length()).map { arr.getJSONObject(it).getString("text") }
        } finally {
            c.disconnect()
        }
    }

    // يرجع (العنوان، الملخص). DeepL إن وُجد المفتاح، وإلا أو عند فشله ML Kit (إن كان النموذج جاهزاً)
    suspend fun translateArticle(title: String, summary: String, key: String, mlReady: Boolean): Pair<String, String> {
        val t = clean(title, true)
        val ss = sentences(clean(summary, false), 2)
        if (key.isNotBlank()) {
            try {
                val r = deepl(key, listOf(t) + ss)
                return r[0] to r.drop(1).joinToString(" ")
            } catch (e: Exception) {
                if (!mlReady) throw e
            }
        }
        val tt = mlkit(t)
        val parts = ArrayList<String>()
        for (x in ss) parts.add(mlkit(x))
        val st = parts.joinToString(" ")
        return tt to st
    }
}

class TransStore(ctx: Context) {
    private val file = File(ctx.filesDir, "translations_v2.json")

    fun load(): Map<String, Pair<String, String>> = try {
        val o = JSONObject(file.readText())
        o.keys().asSequence().associateWith { k ->
            val a = o.getJSONArray(k)
            a.getString(0) to a.getString(1)
        }
    } catch (e: Exception) {
        emptyMap()
    }

    fun save(m: Map<String, Pair<String, String>>) {
        try {
            val o = JSONObject()
            m.forEach { (k, v) -> o.put(k, JSONArray().put(v.first).put(v.second)) }
            file.writeText(o.toString())
        } catch (_: Exception) {
        }
    }
}
