package com.lamha.news

import android.content.Context
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Translator {
    private val client by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.ARABIC)
                .build()
        )
    }

    suspend fun ensureModel(): Boolean = try {
        client.downloadModelIfNeeded(DownloadConditions.Builder().requireWifi().build()).await()
        true
    } catch (e: Exception) {
        false
    }

    suspend fun translate(text: String): String = client.translate(text).await()
}

class TransStore(ctx: Context) {
    private val file = File(ctx.filesDir, "translations.json")

    fun load(): Map<String, Pair<String, String>> = try {
        val o = JSONObject(file.readText())
        o.keys().asSequence().associateWith { k ->
            val a = o.getJSONArray(k)
            a.getString(0) to a.getString(1)
        }
    } catch (e: Exception) {
        emptyMap()
    }

    fun save(m: Map<String, Pair<String, String>>) {
        try {
            val o = JSONObject()
            m.forEach { (k, v) -> o.put(k, JSONArray().put(v.first).put(v.second)) }
            file.writeText(o.toString())
        } catch (_: Exception) {
        }
    }
}
