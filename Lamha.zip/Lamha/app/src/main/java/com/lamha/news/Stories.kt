package com.lamha.news

import kotlin.math.min
import kotlin.math.pow

/** خبر واحد قد تغطيه عدة مصادر. lead هو الأنسب للعرض، وitems كل النسخ من المصادر المختلفة. */
class Story(val lead: Article, val items: List<Article>) {
    // المصادر المستقلة: نسخ الناشر نفسه (اليوم السابع واليوم السابع عاجل مثلاً، ويُعرف بنطاق الرابط الأصلي) تُحسب مصدراً واحداً
    val sources: List<String> = items.distinctBy { Stories.publisher(it) }.map { it.source }

    /** قصة عن مصر: إن ذكرتها أي نسخة من نسخها (العنوان أو الملخص) */
    val egypt: Boolean by lazy { items.any { Locality.isEgypt(it) } }

    /**
     * نشرة دورية (أسعار اليوم...): تتكرر يومياً بقالب واحد من عشرات المواقع، فتعدد مصادرها لا يدل على أهميتها.
     * لا تُعدّ قصة مهمة ولا عاجلة، ويُحسب وزنها بمصدر واحد. القصة المختلطة (فيها خبر حقيقي) لا تُعدّ نشرة.
     */
    val routine: Boolean by lazy { items.all { Quality.isRoutine(it) } }

    /** علامة "عاجل": العنوان فيه كلمة عاجل ونُشر خلال الساعة الأخيرة (ليست للنشرات الدورية) */
    val breaking: Boolean get() = !routine && Stories.isBreaking(items)

    /**
     * الأهمية = وزن المصادر المستقلة (الكبرى أثقل) × كلمات الأحداث الكبرى × عاجل × تلاشي زمني (النصف كل 8 ساعات)،
     * مع خفض الخبر الوحيد بلا ملخص (غالباً عنوان ضعيف)
     */
    val score: Double by lazy {
        val ageH = ((System.currentTimeMillis() - lead.time) / 3_600_000.0).coerceAtLeast(0.0)
        val weight = if (routine) 1.0 else sources.sumOf { Quality.sourceWeight(it) }
        val heavy = if (routine) 1.0 else 1.0 + 0.3 * items.maxOf { Quality.heavyHits(it) }
        val brk = if (breaking) 1.5 else 1.0
        val thin = if (sources.size == 1 && lead.summary.isBlank()) 0.7 else 1.0
        val low = if (routine) 0.3 else 1.0
        weight * heavy * brk * thin * low * 0.5.pow(ageH / 8.0)
    }
}

/** شاشة "الصورة الكاملة": القصة وما يتصل بها من أخبار */
class StoryView(val story: Story, val related: List<Story>)

object Stories {
    private val DIACRITICS = Regex("[\\u064B-\\u065F\\u0670\\u0640]")
    private val NON_WORD = Regex("[^\\p{L}\\p{N}\\s]")
    private val SPACES = Regex("\\s+")

    private fun norm(s: String): String = s
        .replace(DIACRITICS, "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ة', 'ه')
        .lowercase()

    // كلمات شائعة لا تدل على الخبر نفسه
    private val STOP: Set<String> = listOf(
        "في", "من", "على", "إلى", "الى", "عن", "مع", "بعد", "قبل", "أن", "إن", "هل", "ما", "لا", "كل",
        "بين", "عند", "حتى", "هذا", "هذه", "ذلك", "التي", "الذي", "هو", "هي", "قال", "تقرير", "عاجل",
        "فيديو", "صور", "خلال", "ضد", "أمام", "وسط", "اليوم", "بعدما", "قبيل"
    ).map { norm(it) }.toSet()

    // حذف "ال" التعريف (و"وال") من أول الكلمة
    private fun stem(w: String): String {
        var x = w
        if (x.startsWith("وال") && x.length > 5) x = x.substring(1)
        if (x.startsWith("ال") && x.length > 4) x = x.substring(2)
        return x
    }

    // توحيد المرادفات وصيغ الدول (اسمها ونسبتها وعاصمتها) إلى كلمة واحدة قبل حساب التشابه
    private val CANON = HashMap<String, String>()
    private val COUNTRIES = HashSet<String>()

    private fun syn(to: String, vararg words: String) {
        val t = norm(to)
        for (w in words) CANON[stem(norm(w))] = t
    }

    private fun country(to: String, vararg words: String) {
        syn(to, *words)
        COUNTRIES.add(norm(to))
    }

    init {
        country("امريكا", "أمريكا", "أميركا", "أمريكي", "أميركي", "أمريكية", "أميركية", "واشنطن")
        country("فرنسا", "فرنسا", "فرنسي", "فرنسية", "باريس")
        country("بريطانيا", "بريطانيا", "بريطاني", "بريطانية", "لندن")
        country("المانيا", "ألمانيا", "ألماني", "ألمانية", "برلين")
        country("روسيا", "روسيا", "روسي", "روسية", "موسكو", "الكرملين")
        country("اوكرانيا", "أوكرانيا", "أوكراني", "أوكرانية", "كييف")
        country("الصين", "الصين", "صيني", "صينية", "بكين")
        country("ايران", "إيران", "إيراني", "إيرانية", "طهران")
        country("اسرائيل", "إسرائيل", "إسرائيلي", "إسرائيلية", "أبيب")
        country("فلسطين", "فلسطين", "فلسطيني", "فلسطينية")
        country("تركيا", "تركيا", "تركي", "تركية", "أنقرة")
        country("سوريا", "سوريا", "سوري", "سورية", "دمشق")
        country("لبنان", "لبنان", "لبناني", "لبنانية", "بيروت")
        country("العراق", "العراق", "عراقي", "عراقية", "بغداد")
        country("اليمن", "اليمن", "يمني", "يمنية", "صنعاء")
        country("السعودية", "السعودية", "سعودي", "سعودية")
        country("الامارات", "الإمارات", "إماراتي", "إماراتية", "أبوظبي")
        country("قطر", "قطر", "قطري", "قطرية", "الدوحة")
        country("مصر", "مصر", "مصري", "مصرية", "القاهرة")
        country("السودان", "السودان", "سوداني", "سودانية", "الخرطوم")
        country("ليبيا", "ليبيا", "ليبي", "ليبية", "طرابلس")
        country("الاردن", "الأردن", "أردني", "أردنية")
        country("الكويت", "الكويت", "كويتي", "كويتية")
        country("الهند", "الهند", "هندي", "هندية", "دلهي")
        country("باكستان", "باكستان", "باكستاني", "باكستانية")
        country("اليابان", "اليابان", "ياباني", "يابانية", "طوكيو")
        country("كوريا", "كوريا", "كوري", "كورية", "سيول")
        country("ايطاليا", "إيطاليا", "إيطالي", "إيطالية", "روما")
        country("اسبانيا", "إسبانيا", "إسباني", "إسبانية", "مدريد")
        syn("بنك", "بنوك", "مصرف", "مصارف")
        syn("انخفاض", "تراجع", "هبوط", "انخفض", "انخفضت", "تراجعت", "هبطت", "هبط", "ينخفض", "يتراجع", "يهبط", "تنخفض", "تتراجع", "تهبط")
        syn("ارتفاع", "صعود", "ارتفع", "ارتفعت", "يرتفع", "ترتفع", "صعد", "صعدت", "يصعد", "تصعد")
        syn("مقتل", "قتيل", "قتلى", "مصرع")
        syn("اصابه", "جرحى", "اصابات", "مصابين", "إصابة")
        syn("فرض", "فرضت", "تفرض", "يفرض")
        syn("اسعار", "سعر")
        syn("عقوبات", "عقوبة")
        syn("هجوم", "هجمات", "هجمة", "هجوما")
        syn("اتفاق", "اتفاقية", "اتفاقا")
    }

    // كلمة ملتصقة بحرف جر (بفرنسا، لفرنسا، للصين، وفرنسا)
    private fun attached(x: String): String? {
        if (x.length >= 5 && x.startsWith("لل")) CANON[stem("ال" + x.substring(2))]?.let { return it }
        if (x.length >= 4 && x[0] in "بلفكو") CANON[stem(x.substring(1))]?.let { return it }
        return null
    }

    // كلمات لا تدل على الخبر نفسه: أيام الأسبوع والشهور (ميلادية وشامية) وقوالب العناوين الدورية.
    // كانت تُحسب كلمات مشتركة فتدمج "أسعار السمك" مع "سعر الريال" لمجرد أن كليهما "اليوم الاثنين 16 نوفمبر 2026"
    private val NOISE: Set<String> = listOf(
        "السبت", "الأحد", "الاثنين", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة",
        "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يونيه", "يوليو", "يوليه", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
        "كانون", "شباط", "آذار", "نيسان", "أيار", "حزيران", "تموز", "أيلول", "تشرين",
        "أسعار", "الآن", "حاليا", "تعرف", "اعرف", "كيف", "ماذا", "لماذا", "كم", "سجل", "تحرك", "تفاصيل", "مستجدات", "ننشر", "شاهد", "بالفيديو"
    ).flatMap { val n = norm(it); listOf(n, stem(n)) }.toSet()

    private val YEAR = Regex("^(19|20)\\d{2}$")
    private val WEEKDAY = Regex("^(السبت|الاحد|الاثنين|الثلاثاء|الاربعاء|الخميس|الجمعه)$")
    private const val MONTHS = "يناير|فبراير|مارس|ابريل|مايو|يونيو|يونيه|يوليو|يوليه|اغسطس|سبتمبر|اكتوبر|نوفمبر|ديسمبر|كانون|شباط|اذار|نيسان|ايار|حزيران|تموز|ايلول|تشرين"
    private val DMY = Regex("(?<!\\d)(\\d{1,2})\\s*[/.\\-]\\s*(\\d{1,2})\\s*[/.\\-]\\s*(\\d{4})")
    private val YMD = Regex("(\\d{4})\\s*[/.\\-]\\s*(\\d{1,2})\\s*[/.\\-]\\s*(\\d{1,2})(?!\\d)")
    private val DAY_MONTH = Regex("(?<!\\d)(\\d{1,2})\\s+(?:$MONTHS)")

    // ما يُقارن به الخبر الدوري: ما يُباع/يُسعَّر (عملة أو سلعة). نشرتان بموضوعين مختلفين (دولار / ريال / سمك) خبران مختلفان
    private val SUBJECTS: Set<String> = listOf(
        "دولار", "ريال", "دينار", "يورو", "درهم", "إسترليني", "ذهب", "فضة", "عيار", "سمك", "لحوم", "لحمة", "دواجن", "فراخ",
        "بيض", "خضار", "خضروات", "فاكهة", "طماطم", "سيارات", "أسمنت", "حديد", "بنزين", "سولار", "نفط", "برنت", "عملات", "عملة", "أرز"
    ).map { stem(norm(it)) }.toSet()

    /** بصمة العنوان: كلماته الدالة، وتاريخه (أيام الأسبوع وأرقام الأيام) إن كان مؤرَّخاً، وهل هو نشرة دورية */
    private class Sig(
        val tokens: Set<String>, val weekdays: Set<String>, val days: Set<String>,
        val routine: Boolean, val subjects: Set<String>
    )

    private fun words(title: String): List<String> = norm(title).replace(NON_WORD, " ").split(SPACES).filter { it.isNotEmpty() }

    private fun tokens(title: String): Set<String> =
        words(title)
            .map { w ->
                val x = stem(w)
                CANON[x] ?: attached(x) ?: x
            }
            .filter { it.length >= 3 && it !in STOP && it !in NOISE && !YEAR.matches(it) }
            .toSet()

    /** الكلمات الدالة في عنوان (تستعملها وضع القراءة للتحقق أن الصفحة المجلوبة هي الخبر المطلوب) */
    fun keyTokens(title: String): Set<String> = tokens(title)

    /** (أيام الأسبوع، أرقام الأيام) المذكورة في العنوان */
    private fun stamp(title: String): Pair<Set<String>, Set<String>> {
        val n = norm(title)
        val wk = words(title).filter { WEEKDAY.matches(it) }.toSet()
        val days = HashSet<String>()
        DMY.findAll(n).forEach { m -> m.groupValues[1].toIntOrNull()?.let { days.add(it.toString()) } }
        YMD.findAll(n).forEach { m -> m.groupValues[3].toIntOrNull()?.let { days.add(it.toString()) } }
        DAY_MONTH.findAll(n).forEach { m -> m.groupValues[1].toIntOrNull()?.let { days.add(it.toString()) } }
        return wk to days
    }

    /** العنوان مؤرَّخ كنشرة: فيه تاريخ صريح، أو يوم أسبوع مع كلمة "اليوم" */
    fun isStamped(title: String): Boolean {
        val (wk, days) = stamp(title)
        return days.isNotEmpty() || (wk.isNotEmpty() && "اليوم" in words(title))
    }

    private val TODAY_PRICE = Regex("(^| )(سعر|اسعار) \\S+( \\S+){0,2} اليوم( |$)")

    /** صيغة "سعر X اليوم" دون تاريخ */
    fun isTodayPrice(title: String): Boolean = TODAY_PRICE.containsMatchIn(words(title).joinToString(" "))

    private fun sig(a: Article): Sig {
        val t = tokens(a.title)
        val (wk, days) = stamp(a.title)
        return Sig(t, wk, days, Quality.isRoutine(a), t.filter { it in SUBJECTS }.toSet())
    }

    // تشابه الأخبار العادية: 3 كلمات دالة مشتركة على الأقل (بعد حذف التاريخ وكلمات القوالب)، وتمثل 60% من كلمات العنوان الأقصر
    // قاعدة الدول: إن ذكر كل عنوان دولة ليست في الآخر (فرنسي مقابل تركي) فهما خبران مختلفان مهما تشابهت بقية الكلمات
    // النشرات الدورية (أسعار اليوم): تندمج فقط إن اتفق موضوعهما (دولار مع دولار) ولم يتعارض تاريخهما ولا فاصل زمني كبير
    private fun similar(a: Sig, b: Sig, gapMs: Long): Boolean {
        if (a.tokens.any { it in COUNTRIES && it !in b.tokens } && b.tokens.any { it in COUNTRIES && it !in a.tokens }) return false
        if (a.routine && b.routine && a.subjects.isNotEmpty() && b.subjects.isNotEmpty()) {
            if (gapMs > ROUTINE_GAP) return false
            if (a.subjects != b.subjects) return false
            if (a.weekdays.isNotEmpty() && b.weekdays.isNotEmpty() && a.weekdays.none { it in b.weekdays }) return false
            if (a.days.isNotEmpty() && b.days.isNotEmpty() && a.days.none { it in b.days }) return false
            return true
        }
        if (a.tokens.size < 3 || b.tokens.size < 3) return false
        val inter = a.tokens.count { it in b.tokens }
        return inter >= 3 && inter.toDouble() / min(a.tokens.size, b.tokens.size) >= 0.6
    }

    /** الناشر: نطاق الرابط الأصلي إن عُرف، وإلا اسم المصدر (روابط Google التي لم تُفك بعد) */
    fun publisher(a: Article): String =
        GoogleLink.canonicalOf(a.link)?.substringBefore('/') ?: ("s:" + a.source)

    /** هل الخبران عن الحدث نفسه؟ (للتأكد قبل استعارة نص أحدهما للآخر في وضع القراءة). الرابط الأصلي نفسه يكفي دليلاً */
    fun sameStory(a: Article, b: Article): Boolean {
        val ka = GoogleLink.canonicalOf(a.link)
        if (ka != null && ka == GoogleLink.canonicalOf(b.link)) return true
        return a.category == b.category && similar(sig(a), sig(b), Math.abs(a.time - b.time))
    }

    private const val HOUR_MS = 3_600_000L
    private const val ROUTINE_GAP = 18 * HOUR_MS     // نشرة اليوم لا تدمج بنشرة الأمس
    private const val NEWS_GAP = 36 * HOUR_MS        // خبران بينهما أكثر من يوم ونصف ليسا الحدث نفسه
    private const val ANALYSIS_GAP = 7 * 24 * HOUR_MS

    private class Cluster(val sig: Sig, val category: String, val items: MutableList<Article>, val keys: MutableSet<String>)

    /** يدمج الأخبار المتكررة (من مصادر مختلفة، ضمن التصنيف نفسه) في بطاقة واحدة */
    fun build(list: List<Article>): List<Story> {
        val clusters = ArrayList<Cluster>()
        for (a in list.sortedByDescending { it.time }) {
            val s = sig(a)
            val key = GoogleLink.canonicalOf(a.link)
            // items مرتبة من الأحدث، وa أقدم منها كلها: الفاصل الزمني عن أحدث خبر في المجموعة
            val c = clusters.firstOrNull {
                // الرابط الأصلي نفسه = الخبر نفسه، مهما اختلف العنوان أو التصنيف أو الوقت
                if (key != null && key in it.keys) return@firstOrNull true
                val gap = it.items.first().time - a.time
                it.category == a.category && gap <= (if (a.category == "analysis") ANALYSIS_GAP else NEWS_GAP) &&
                    similar(s, it.sig, gap)
            }
            if (c != null) {
                c.items.add(a)
                if (key != null) c.keys.add(key)
            } else {
                val ks = HashSet<String>()
                if (key != null) ks.add(key)
                clusters.add(Cluster(s, a.category, mutableListOf(a), ks))
            }
        }
        // نفضّل الأحدث الذي له ملخص
        return clusters.map { c -> Story(c.items.firstOrNull { it.summary.isNotBlank() } ?: c.items.first(), c.items) }
    }

    /** أخبار ذات صلة (خلفية): قصص أخرى تشترك مع القصة في 3 كلمات دالة على الأقل، الأكثر تشابهاً ثم الأحدث */
    fun related(target: Story, all: List<Story>, max: Int = 5): List<Story> {
        val t = target.items.flatMap { tokens(it.title) }.toSet()
        if (t.size < 3) return emptyList()
        return all.asSequence()
            .filter { it.lead.link != target.lead.link }
            .map { it to tokens(it.lead.title).count { w -> w in t } }
            .filter { it.second >= 3 }
            .sortedWith(compareByDescending<Pair<Story, Int>> { it.second }.thenByDescending { it.first.lead.time })
            .take(max).map { it.first }.toList()
    }

    private const val HOUR = 3_600_000L
    // كلمة "عاجل" وحدها (لا "عاجلة" ولا "مستعجل")
    private val BREAKING_WORD = Regex("(^|[^\\p{L}])عاجل([^\\p{L}]|$)")

    fun isBreaking(items: List<Article>, now: Long = System.currentTimeMillis()): Boolean =
        items.any { now - it.time < HOUR && BREAKING_WORD.containsMatchIn(it.title) }

    fun order(stories: List<Story>, important: Boolean): List<Story> =
        if (important) stories.sortedWith(compareByDescending<Story> { it.score }.thenByDescending { it.lead.time })
        else stories.sortedByDescending { it.lead.time }

    fun sourcesLabel(n: Int): String = when {
        n == 2 -> "مصدران"
        n in 3..10 -> "$n مصادر"
        else -> "$n مصدراً"
    }

    fun coverText(n: Int): String = when {
        n == 2 -> "غطّه مصدران"
        n in 3..10 -> "غطّته $n مصادر"
        else -> "غطّته $n مصدراً"
    }
}
