package com.lamha.news

import kotlin.math.min
import kotlin.math.pow

/** خبر واحد قد تغطيه عدة مصادر. lead هو الأنسب للعرض، وitems كل النسخ من المصادر المختلفة. */
class Story(val lead: Article, val items: List<Article>) {
    val sources: List<String> = items.map { it.source }.distinct()

    /** قصة عن مصر: إن ذكرتها أي نسخة من نسخها (العنوان أو الملخص) */
    val egypt: Boolean by lazy { items.any { Locality.isEgypt(it) } }

    /** علامة "عاجل": العنوان فيه كلمة عاجل، أو غطّاه 3 مصادر خلال ساعة، وفي الحالتين عمره أقل من ساعة */
    val breaking: Boolean get() = Stories.isBreaking(items)

    /**
     * الأهمية = وزن المصادر المستقلة (الكبرى أثقل) × كلمات الأحداث الكبرى × عاجل × تلاشي زمني (النصف كل 8 ساعات)،
     * مع خفض الخبر الوحيد بلا ملخص (غالباً عنوان ضعيف)
     */
    val score: Double by lazy {
        val ageH = ((System.currentTimeMillis() - lead.time) / 3_600_000.0).coerceAtLeast(0.0)
        val weight = sources.sumOf { Quality.sourceWeight(it) }
        val heavy = 1.0 + 0.3 * items.maxOf { Quality.heavyHits(it) }
        val brk = if (breaking) 1.5 else 1.0
        val thin = if (sources.size == 1 && lead.summary.isBlank()) 0.7 else 1.0
        weight * heavy * brk * thin * 0.5.pow(ageH / 8.0)
    }
}

/** شاشة "الصورة الكاملة": القصة وما يتصل بها من أخبار */
class StoryView(val story: Story, val related: List<Story>)

object Stories {
    private val DIACRITICS = Regex("[\\u064B-\\u065F\\u0670\\u0640]")
    private val NON_WORD = Regex("[^\\p{L}\\p{N}\\s]")
    private val SPACES = Regex("\\s+")

    private fun norm(s: String): String = s
        .replace(DIACRITICS, "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ة', 'ه')
        .lowercase()

    // كلمات شائعة لا تدل على الخبر نفسه
    private val STOP: Set<String> = listOf(
        "في", "من", "على", "إلى", "الى", "عن", "مع", "بعد", "قبل", "أن", "إن", "هل", "ما", "لا", "كل",
        "بين", "عند", "حتى", "هذا", "هذه", "ذلك", "التي", "الذي", "هو", "هي", "قال", "تقرير", "عاجل",
        "فيديو", "صور", "خلال", "ضد", "أمام", "وسط", "اليوم", "بعدما", "قبيل"
    ).map { norm(it) }.toSet()

    // حذف "ال" التعريف (و"وال") من أول الكلمة
    private fun stem(w: String): String {
        var x = w
        if (x.startsWith("وال") && x.length > 5) x = x.substring(1)
        if (x.startsWith("ال") && x.length > 4) x = x.substring(2)
        return x
    }

    // توحيد المرادفات وصيغ الدول (اسمها ونسبتها وعاصمتها) إلى كلمة واحدة قبل حساب التشابه
    private val CANON = HashMap<String, String>()
    private val COUNTRIES = HashSet<String>()

    private fun syn(to: String, vararg words: String) {
        val t = norm(to)
        for (w in words) CANON[stem(norm(w))] = t
    }

    private fun country(to: String, vararg words: String) {
        syn(to, *words)
        COUNTRIES.add(norm(to))
    }

    init {
        country("امريكا", "أمريكا", "أميركا", "أمريكي", "أميركي", "أمريكية", "أميركية", "واشنطن")
        country("فرنسا", "فرنسا", "فرنسي", "فرنسية", "باريس")
        country("بريطانيا", "بريطانيا", "بريطاني", "بريطانية", "لندن")
        country("المانيا", "ألمانيا", "ألماني", "ألمانية", "برلين")
        country("روسيا", "روسيا", "روسي", "روسية", "موسكو", "الكرملين")
        country("اوكرانيا", "أوكرانيا", "أوكراني", "أوكرانية", "كييف")
        country("الصين", "الصين", "صيني", "صينية", "بكين")
        country("ايران", "إيران", "إيراني", "إيرانية", "طهران")
        country("اسرائيل", "إسرائيل", "إسرائيلي", "إسرائيلية", "أبيب")
        country("فلسطين", "فلسطين", "فلسطيني", "فلسطينية")
        country("تركيا", "تركيا", "تركي", "تركية", "أنقرة")
        country("سوريا", "سوريا", "سوري", "سورية", "دمشق")
        country("لبنان", "لبنان", "لبناني", "لبنانية", "بيروت")
        country("العراق", "العراق", "عراقي", "عراقية", "بغداد")
        country("اليمن", "اليمن", "يمني", "يمنية", "صنعاء")
        country("السعودية", "السعودية", "سعودي", "سعودية")
        country("الامارات", "الإمارات", "إماراتي", "إماراتية", "أبوظبي")
        country("قطر", "قطر", "قطري", "قطرية", "الدوحة")
        country("مصر", "مصر", "مصري", "مصرية", "القاهرة")
        country("السودان", "السودان", "سوداني", "سودانية", "الخرطوم")
        country("ليبيا", "ليبيا", "ليبي", "ليبية", "طرابلس")
        country("الاردن", "الأردن", "أردني", "أردنية")
        country("الكويت", "الكويت", "كويتي", "كويتية")
        country("الهند", "الهند", "هندي", "هندية", "دلهي")
        country("باكستان", "باكستان", "باكستاني", "باكستانية")
        country("اليابان", "اليابان", "ياباني", "يابانية", "طوكيو")
        country("كوريا", "كوريا", "كوري", "كورية", "سيول")
        country("ايطاليا", "إيطاليا", "إيطالي", "إيطالية", "روما")
        country("اسبانيا", "إسبانيا", "إسباني", "إسبانية", "مدريد")
        syn("بنك", "بنوك", "مصرف", "مصارف")
        syn("انخفاض", "تراجع", "هبوط", "انخفض", "انخفضت", "تراجعت", "هبطت", "هبط", "ينخفض", "يتراجع", "يهبط", "تنخفض", "تتراجع", "تهبط")
        syn("ارتفاع", "صعود", "ارتفع", "ارتفعت", "يرتفع", "ترتفع", "صعد", "صعدت", "يصعد", "تصعد")
        syn("مقتل", "قتيل", "قتلى", "مصرع")
        syn("اصابه", "جرحى", "اصابات", "مصابين", "إصابة")
        syn("فرض", "فرضت", "تفرض", "يفرض")
        syn("اسعار", "سعر")
        syn("عقوبات", "عقوبة")
        syn("هجوم", "هجمات", "هجمة", "هجوما")
        syn("اتفاق", "اتفاقية", "اتفاقا")
    }

    // كلمة ملتصقة بحرف جر (بفرنسا، لفرنسا، للصين، وفرنسا)
    private fun attached(x: String): String? {
        if (x.length >= 5 && x.startsWith("لل")) CANON[stem("ال" + x.substring(2))]?.let { return it }
        if (x.length >= 4 && x[0] in "بلفكو") CANON[stem(x.substring(1))]?.let { return it }
        return null
    }

    private fun tokens(title: String): Set<String> =
        norm(title).replace(NON_WORD, " ").split(SPACES)
            .map { w ->
                val x = stem(w)
                CANON[x] ?: attached(x) ?: x
            }
            .filter { it.length >= 3 && it !in STOP }
            .toSet()

    // تشابه: 3 كلمات مشتركة على الأقل، وتمثل 60% من كلمات العنوان الأقصر
    // قاعدة الدول: إن ذكر كل عنوان دولة ليست في الآخر (فرنسي مقابل تركي) فهما خبران مختلفان مهما تشابهت بقية الكلمات
    private fun similar(a: Set<String>, b: Set<String>): Boolean {
        if (a.size < 3 || b.size < 3) return false
        if (a.any { it in COUNTRIES && it !in b } && b.any { it in COUNTRIES && it !in a }) return false
        val inter = a.count { it in b }
        return inter >= 3 && inter.toDouble() / min(a.size, b.size) >= 0.6
    }

    private class Cluster(val tokens: Set<String>, val category: String, val items: MutableList<Article>)

    /** يدمج الأخبار المتكررة (من مصادر مختلفة، ضمن التصنيف نفسه) في بطاقة واحدة */
    fun build(list: List<Article>): List<Story> {
        val clusters = ArrayList<Cluster>()
        for (a in list.sortedByDescending { it.time }) {
            val t = tokens(a.title)
            val c = clusters.firstOrNull { it.category == a.category && similar(t, it.tokens) }
            if (c != null) c.items.add(a) else clusters.add(Cluster(t, a.category, mutableListOf(a)))
        }
        // items مرتبة من الأحدث؛ نفضّل الأحدث الذي له ملخص
        return clusters.map { c -> Story(c.items.firstOrNull { it.summary.isNotBlank() } ?: c.items.first(), c.items) }
    }

    /** أخبار ذات صلة (خلفية): قصص أخرى تشترك مع القصة في 3 كلمات دالة على الأقل، الأكثر تشابهاً ثم الأحدث */
    fun related(target: Story, all: List<Story>, max: Int = 5): List<Story> {
        val t = target.items.flatMap { tokens(it.title) }.toSet()
        if (t.size < 3) return emptyList()
        return all.asSequence()
            .filter { it.lead.link != target.lead.link }
            .map { it to tokens(it.lead.title).count { w -> w in t } }
            .filter { it.second >= 3 }
            .sortedWith(compareByDescending<Pair<Story, Int>> { it.second }.thenByDescending { it.first.lead.time })
            .take(max).map { it.first }.toList()
    }

    private const val HOUR = 3_600_000L
    // كلمة "عاجل" وحدها (لا "عاجلة" ولا "مستعجل")
    private val BREAKING_WORD = Regex("(^|[^\\p{L}])عاجل([^\\p{L}]|$)")

    fun isBreaking(items: List<Article>, now: Long = System.currentTimeMillis()): Boolean {
        val newest = items.maxOfOrNull { it.time } ?: return false
        if (now - newest > HOUR) return false
        if (items.any { now - it.time < HOUR && BREAKING_WORD.containsMatchIn(it.title) }) return true
        for (a in items) {
            val srcs = items.filter { it.time <= a.time && a.time - it.time <= HOUR }.map { it.source }.toSet()
            if (srcs.size >= 3) return true
        }
        return false
    }

    fun order(stories: List<Story>, important: Boolean): List<Story> =
        if (important) stories.sortedWith(compareByDescending<Story> { it.score }.thenByDescending { it.lead.time })
        else stories.sortedByDescending { it.lead.time }

    fun sourcesLabel(n: Int): String = when {
        n == 2 -> "مصدران"
        n in 3..10 -> "$n مصادر"
        else -> "$n مصدراً"
    }

    fun coverText(n: Int): String = when {
        n == 2 -> "غطّه مصدران"
        n in 3..10 -> "غطّته $n مصادر"
        else -> "غطّته $n مصدراً"
    }
}
