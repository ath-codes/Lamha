package com.lamha.news

import android.text.Html
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

object Rss {
    private const val UA = "Mozilla/5.0 (Linux; Android 14) Lamha/1.0"
    private val SPACES = Regex("\\s+")
    private val DATE_FORMATS = listOf(
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "EEE, dd MMM yyyy HH:mm:ss zzz",
        "dd MMM yyyy HH:mm:ss Z",
        "yyyy-MM-dd'T'HH:mm:ssXXX",
        "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
    )

    fun https(u: String) = if (u.startsWith("http://")) "https://" + u.substring(7) else u

    fun fetch(src: Source): List<Article> = fetchInfo(src).first

    // يرجع الأخبار + هل جاءت من الرابط البديل (لشاشة فحص المصادر)
    fun fetchInfo(src: Source): Pair<List<Article>, Boolean> {
        val a = try { get(src.url, src) } catch (_: Exception) { emptyList() }
        val fb = src.fallback
        if (a.isNotEmpty() || fb == null) return a to false
        val b = try { get(fb, src) } catch (_: Exception) { emptyList() }
        return b to b.isNotEmpty()
    }

    private fun get(url: String, src: Source): List<Article> {
        val c = URL(https(url)).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*")
        try {
            if (c.responseCode != 200) return emptyList()
            return c.inputStream.use { parse(it, src, url.contains("news.google.com")) }
        } finally {
            c.disconnect()
        }
    }

    private fun parseDate(s: String): Long {
        val t = s.trim()
        for (f in DATE_FORMATS) {
            try {
                return SimpleDateFormat(f, Locale.ENGLISH).parse(t)!!.time
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    // بعض الخلاصات تضع المقال كاملاً في الوصف؛ نقص الخام قبل التحويل لأن Html.fromHtml بطيء مع النصوص الطويلة
    private const val MAX_RAW = 2500

    private fun clean(raw: String): String {
        if (raw.isBlank()) return ""
        val s = if (raw.length > MAX_RAW) raw.substring(0, MAX_RAW) else raw
        return Html.fromHtml(s, Html.FROM_HTML_MODE_COMPACT).toString()
            .replace('\uFFFC', ' ').replace(SPACES, " ").trim()
    }

    private fun shorten(s: String, max: Int): String {
        if (s.length <= max) return s
        val cut = s.substring(0, max)
        val i = cut.lastIndexOf(' ')
        val base = if (i > max / 2) cut.substring(0, i) else cut
        return base.trimEnd('،', ',', '.', ' ', ':') + "…"
    }

    private fun parse(input: InputStream, src: Source, gnews: Boolean): List<Article> {
        val out = ArrayList<Article>()
        try {
            val p = Xml.newPullParser()
            p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            try {
                p.setFeature("http://xmlpull.org/v1/doc/features.html#relaxed", true)
            } catch (_: Exception) {
            }
            p.setInput(input, null)
            var inItem = false
            var title = ""; var desc = ""; var content = ""; var link = ""
            var date = 0L
            var ev = p.eventType
            val limit = if (gnews) 100 else 25
            while (ev != XmlPullParser.END_DOCUMENT && out.size < limit) {
                if (ev == XmlPullParser.START_TAG) {
                    val n = p.name
                    if (n == "item" || n == "entry") {
                        inItem = true
                        title = ""; desc = ""; content = ""; link = ""; date = 0L
                    } else if (inItem) {
                        when (n) {
                            "title" -> title = p.nextText()
                            "link" -> {
                                val h = p.getAttributeValue(null, "href")
                                val t = p.nextText()
                                if (link.isBlank()) link = if (!h.isNullOrBlank()) h else t.trim()
                            }
                            "description", "summary" -> desc = p.nextText()
                            "content:encoded", "content" -> content = p.nextText()
                            "pubDate", "published", "updated", "dc:date" -> {
                                val d = parseDate(p.nextText())
                                if (d > 0 && date == 0L) date = d
                            }
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG && (p.name == "item" || p.name == "entry") && inItem) {
                    inItem = false
                    val t = clean(title).let { if (gnews) it.substringBeforeLast(" - ") else it }
                    if (t.isNotBlank() && link.isNotBlank()) {
                        var s = clean(if (desc.isNotBlank()) desc else content)
                        if (s == t || gnews) s = ""
                        out.add(
                            Article(
                                id = link,
                                title = t,
                                summary = shorten(s, 240),
                                link = https(link.trim()),
                                source = src.name,
                                category = src.category,
                                time = if (date > 0) date else System.currentTimeMillis() - out.size * 60_000L
                            )
                        )
                    }
                }
                ev = p.next()
            }
        } catch (_: Exception) {
            // نرجع ما تم تحليله حتى الآن
        }
        return if (gnews) out.sortedByDescending { it.time }.take(25) else out
    }
}
